#!/usr/bin/env python3
"""Compile a mock source file without retaining plaintext in the runtime kit.

The source is read from a caller-supplied path and compiled through a
short-lived temporary file. The development fallback machine code is removed
from the generated code object; the request's markcode remains authoritative.
"""

from __future__ import annotations

import os
import py_compile
import re
import sys
import tempfile
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3:
        print(f"usage: {sys.argv[0]} SOURCE.py OUTPUT.pyc", file=sys.stderr)
        return 2
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    text = source.read_text(encoding="utf-8")
    text = re.sub(
        r"(?m)^FALLBACK_MACHINE\s*=.*$",
        'FALLBACK_MACHINE = os.environ.get("MOCK_MACHINE", "")',
        text,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".py", delete=False
        ) as handle:
            handle.write(text)
            temp_path = Path(handle.name)
        py_compile.compile(str(temp_path), cfile=str(output), doraise=True)
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink()
            except FileNotFoundError:
                pass
    os.chmod(output, 0o600)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
