# Build on a Linux host with Docker. The source directory is supplied as the
# build context and is not part of the delivered runtime package. A separate
# builder stage is required: deleting a file in a later layer does not remove
# it from the image history.
FROM python:3.11-slim AS builder

WORKDIR /build
COPY mock_lovol_https.py /build/mock_lovol_https.py
RUN sed -E -i 's#^FALLBACK_MACHINE = .*#FALLBACK_MACHINE = os.environ.get("MOCK_MACHINE", "")#' /build/mock_lovol_https.py \
    && python3 -m py_compile /build/mock_lovol_https.py \
    && mkdir -p /out \
    && mv /build/__pycache__/mock_lovol_https.cpython-311.pyc /out/mock_lovol_https.pyc \
    && rm -rf /build/__pycache__ /build/mock_lovol_https.py

FROM python:3.11-slim

WORKDIR /opt/yjc-local
COPY --from=builder /out/mock_lovol_https.pyc /opt/yjc-local/mock_lovol_https.pyc
COPY server.crt /opt/yjc-local/server.crt
COPY server.key /opt/yjc-local/server.key
RUN mkdir -p /app \
    && chmod 600 /opt/yjc-local/server.key \
    && chmod 644 /opt/yjc-local/server.crt /opt/yjc-local/mock_lovol_https.pyc
COPY server.crt /app/server.crt
COPY server.key /app/server.key
RUN chmod 600 /app/server.key \
    && chmod 644 /app/server.crt

ENV MOCK_LOCAL_ONLY=1 \
    MOCK_MACHINE=

CMD ["python3", "-u", "/opt/yjc-local/mock_lovol_https.pyc"]
