#!/bin/sh
# Roll back the last local-auth-v2 change recorded by install.sh.
# No persistent directory is removed and no --remove-orphans/down -v command
# is used here.
set -eu

die() {
    echo "ERROR: $*" >&2
    exit 1
}

note() {
    echo "[yjc-rollback] $*"
}

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
TARGET_DIR=${YJC_TARGET_DIR:-${1:-/opt/yangjichang}}
case "$TARGET_DIR" in
    /*) ;;
    *) die "YJC_TARGET_DIR must be an absolute path" ;;
esac
[ -d "$TARGET_DIR" ] || die "target directory does not exist: $TARGET_DIR"
TARGET_DIR=$(CDPATH= cd -- "$TARGET_DIR" && pwd -P)
[ "$TARGET_DIR" != "/" ] || die "refusing to use / as target"

STATE_ROOT="$TARGET_DIR/.yjc-upgrades/local-auth-v2"
STATE_DIR=${YJC_STATE_DIR:-}
if [ -z "$STATE_DIR" ] && [ -f "$STATE_ROOT/latest" ]; then
    STATE_DIR=$(sed -n '1p' "$STATE_ROOT/latest")
fi
[ -n "$STATE_DIR" ] || die "no local-auth-v2 state found; set YJC_STATE_DIR explicitly"
case "$STATE_DIR" in
    "$STATE_ROOT"/*) ;;
    *) die "state directory is outside the target upgrade root" ;;
esac
[ -f "$STATE_DIR/state.env" ] || die "state file is missing: $STATE_DIR/state.env"

state_get() {
    # Return the last value for a key. Values written by install.sh do not
    # contain newlines and the file is mode 600.
    awk -F= -v key="$1" '$1 == key { value=substr($0, index($0, "=") + 1) } END { print value }' "$STATE_DIR/state.env"
}

PROJECT=$(state_get PROJECT)
BASE_FILE=$(state_get BASE_FILE)
OVERRIDE_FILE=$(state_get OVERRIDE_FILE)
ENV_FILE=$(state_get ENV_FILE)
SERVER_SERVICE=$(state_get SERVER_SERVICE)
MOCK_SERVICE=$(state_get MOCK_SERVICE)
REQUIRE_BRIDGE=$(state_get REQUIRE_BRIDGE)
ORIGINAL_HAS_BRIDGE=$(state_get ORIGINAL_HAS_BRIDGE)
BRIDGE_SERVICE=$(state_get BRIDGE_SERVICE)
NGINX_SERVICE=$(state_get NGINX_SERVICE)
BRIDGE_CONTAINER=$(state_get BRIDGE_CONTAINER)
NGINX_CONTAINER=$(state_get NGINX_CONTAINER)
BRIDGE_CONTAINER_ID=$(state_get BRIDGE_CONTAINER_ID)
NGINX_CONTAINER_ID=$(state_get NGINX_CONTAINER_ID)
OLD_MOCK_IMAGE_REF=$(state_get OLD_MOCK_IMAGE_REF)
OLD_MOCK_BACKUP_TAG=$(state_get OLD_MOCK_BACKUP_TAG)
[ -n "$PROJECT" ] || die "state has no project"
[ -f "$BASE_FILE" ] || die "original Compose file is missing: $BASE_FILE"
if [ -n "$OVERRIDE_FILE" ] && [ ! -f "$OVERRIDE_FILE" ]; then
    die "original override file is missing: $OVERRIDE_FILE"
fi

command -v docker >/dev/null 2>&1 || die "docker CLI is required"
docker info >/dev/null 2>&1 || die "Docker daemon is not reachable"
if docker compose version >/dev/null 2>&1; then
    COMPOSE_KIND=plugin
elif command -v docker-compose >/dev/null 2>&1 && docker-compose version >/dev/null 2>&1; then
    COMPOSE_KIND=legacy
else
    die "Docker Compose v2 plugin or docker-compose v1 is required"
fi

compose() {
    if [ "$COMPOSE_KIND" = plugin ]; then
        docker compose "$@"
    else
        docker-compose "$@"
    fi
}

compose_original() {
    if [ -n "$OVERRIDE_FILE" ] && [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" "$@"
    elif [ -n "$OVERRIDE_FILE" ]; then
        compose -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" "$@"
    elif [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" "$@"
    else
        compose -p "$PROJECT" -f "$BASE_FILE" "$@"
    fi
}

if [ -n "$OLD_MOCK_BACKUP_TAG" ] && docker image inspect "$OLD_MOCK_BACKUP_TAG" >/dev/null 2>&1; then
    if [ -n "$OLD_MOCK_IMAGE_REF" ]; then
        docker tag "$OLD_MOCK_BACKUP_TAG" "$OLD_MOCK_IMAGE_REF" || die "could not restore the old mock image tag"
    fi
else
    note "old mock image tag was not recorded; Compose rollback may require the original image to be restored manually"
fi

SERVICES=$(compose_original config --services 2>/dev/null) || die "original Compose config is invalid"
printf '%s\n' "$SERVICES" | grep -Fx "$MOCK_SERVICE" >/dev/null 2>&1 || die "mock service '$MOCK_SERVICE' is absent from the original config"
printf '%s\n' "$SERVICES" | grep -Fx "$SERVER_SERVICE" >/dev/null 2>&1 || die "server service '$SERVER_SERVICE' is absent from the original config"

# Remove only package-created bridge/Nginx containers when the original
# Compose had no bridge. IDs are checked against the current container name so
# a user's replacement container is never removed by this script.
remove_owned() {
    expected_id=$1
    container_name=$2
    [ -n "$expected_id" ] || return 0
    current_id=$(docker inspect -f '{{.Id}}' "$container_name" 2>/dev/null || true)
    if [ -n "$current_id" ] && [ "$current_id" = "$expected_id" ]; then
        docker rm -f "$expected_id" >/dev/null || die "could not remove package-created container $container_name"
    else
        note "did not remove $container_name because its current ID differs from the recorded package ID"
    fi
}

if [ "$ORIGINAL_HAS_BRIDGE" != 1 ]; then
    remove_owned "$BRIDGE_CONTAINER_ID" "$BRIDGE_CONTAINER"
    remove_owned "$NGINX_CONTAINER_ID" "$NGINX_CONTAINER"
fi

note "recreating the original mock and server services"
if [ "$COMPOSE_KIND" = plugin ]; then
    compose_original up -d --no-build --pull never --force-recreate --no-deps "$MOCK_SERVICE" "$SERVER_SERVICE" >/dev/null || die "Compose rollback failed"
else
    compose_original up -d --no-build --force-recreate --no-deps "$MOCK_SERVICE" "$SERVER_SERVICE" >/dev/null || die "Compose rollback failed"
fi

# If the target originally had bridge and Nginx services, restore both from
# the original Compose files. If it had no bridge, restore its original Nginx
# after removing the package-created derived image container above.
if [ -n "$NGINX_SERVICE" ] && printf '%s\n' "$SERVICES" | grep -Fx "$NGINX_SERVICE" >/dev/null 2>&1; then
    if [ "$ORIGINAL_HAS_BRIDGE" = 1 ] && [ -n "$BRIDGE_SERVICE" ]; then
        if [ "$COMPOSE_KIND" = plugin ]; then
            compose_original up -d --no-build --pull never --force-recreate --no-deps "$BRIDGE_SERVICE" "$NGINX_SERVICE" >/dev/null || die "bridge/Nginx Compose rollback failed"
        else
            compose_original up -d --no-build --force-recreate --no-deps "$BRIDGE_SERVICE" "$NGINX_SERVICE" >/dev/null || die "bridge/Nginx Compose rollback failed"
        fi
    else
        if [ "$COMPOSE_KIND" = plugin ]; then
            compose_original up -d --no-build --pull never --force-recreate --no-deps "$NGINX_SERVICE" >/dev/null || die "Nginx Compose rollback failed"
        else
            compose_original up -d --no-build --force-recreate --no-deps "$NGINX_SERVICE" >/dev/null || die "Nginx Compose rollback failed"
        fi
    fi
fi

MOCK_ID=$(compose_original ps -q "$MOCK_SERVICE" 2>/dev/null || true)
SERVER_ID=$(compose_original ps -q "$SERVER_SERVICE" 2>/dev/null || true)
[ -n "$MOCK_ID" ] || die "rollback mock container ID could not be resolved"
[ -n "$SERVER_ID" ] || die "rollback server container ID could not be resolved"
MOCK_STATUS=$(docker inspect -f '{{.State.Status}}' "$MOCK_ID" 2>/dev/null || true)
SERVER_STATUS=$(docker inspect -f '{{.State.Status}}' "$SERVER_ID" 2>/dev/null || true)
[ "$MOCK_STATUS" = running ] || die "rollback mock container is not running (status=$MOCK_STATUS)"
[ "$SERVER_STATUS" = running ] || die "rollback server container is not running (status=$SERVER_STATUS)"

if [ "$ORIGINAL_HAS_BRIDGE" = 1 ] && [ -n "$BRIDGE_SERVICE" ] && [ -n "$NGINX_SERVICE" ]; then
    BRIDGE_ID=$(compose_original ps -q "$BRIDGE_SERVICE" 2>/dev/null || true)
    NGINX_ID=$(compose_original ps -q "$NGINX_SERVICE" 2>/dev/null || true)
    [ -n "$BRIDGE_ID" ] || die "rollback bridge container ID could not be resolved"
    [ -n "$NGINX_ID" ] || die "rollback Nginx container ID could not be resolved"
fi

printf 'STATUS=rolled_back\nROLLBACK_MOCK_CONTAINER_ID=%s\nROLLBACK_SERVER_CONTAINER_ID=%s\nROLLBACK_BRIDGE_CONTAINER_ID=%s\nROLLBACK_NGINX_CONTAINER_ID=%s\n' "$MOCK_ID" "$SERVER_ID" "${BRIDGE_ID:-}" "${NGINX_ID:-}" >> "$STATE_DIR/state.env"
note "rollback complete; state retained at $STATE_DIR"
note "mysql, redis, uploads, and logs were not touched"
if [ "$REQUIRE_BRIDGE" = 1 ] && [ "$ORIGINAL_HAS_BRIDGE" != 1 ]; then
    note "the upgrade added bridge/Nginx services to a target that had none; inspect and remove those containers manually only after review"
fi
