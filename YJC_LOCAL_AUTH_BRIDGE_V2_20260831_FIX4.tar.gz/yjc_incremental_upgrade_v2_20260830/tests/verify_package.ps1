$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path

$required = @(
  'README.md', 'MANIFEST.txt', 'install.sh', 'rollback.sh',
  'compose/docker-compose.local-auth.override.yml',
  'compose/docker-compose.local-auth.file.override.yml',
  'compose/docker-compose.server-light.override.yml',
  'runtime/yjc-local-entrypoint.sh',
  'runtime/mock_lovol_https.pyc',
  'runtime/SHA256SUMS',
  'buildspec/mock-local.Dockerfile',
  'buildspec/compile_mock.py',
  'bridge/app.pyc',
  'bridge/Dockerfile',
  'bridge/SHA256SUMS',
  'bridge/main_linux_amd64_B',
  'bridge/nginx/Dockerfile',
  'bridge/nginx/yjc-b-bridge.location.conf',
  'compose/docker-compose.bridge.override.yml'
)
foreach ($rel in $required) {
  $path = Join-Path $Root $rel
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "missing package file: $rel"
  }
}

$install = Get-Content -Raw (Join-Path $Root 'install.sh')
$rollback = Get-Content -Raw (Join-Path $Root 'rollback.sh')
$installCode = (($install -split "`r?`n") | Where-Object { $_.Trim() -notlike '#*' }) -join "`n"
$rollbackCode = (($rollback -split "`r?`n") | Where-Object { $_.Trim() -notlike '#*' }) -join "`n"
$compose = Get-Content -Raw (Join-Path $Root 'compose/docker-compose.local-auth.override.yml')
$fileCompose = Get-Content -Raw (Join-Path $Root 'compose/docker-compose.local-auth.file.override.yml')
$bridgeDockerfile = Get-Content -Raw (Join-Path $Root 'bridge/Dockerfile')
$dockerfile = Get-Content -Raw (Join-Path $Root 'buildspec/mock-local.Dockerfile')

foreach ($text in @($installCode, $rollbackCode)) {
  foreach ($forbidden in @('--remove-orphans', 'down -v', 'volume prune', 'system prune', 'rm -rf')) {
    if ($text -match [regex]::Escape($forbidden)) {
      throw "unsafe command marker found: $forbidden"
    }
  }
}
foreach ($needle in @('bridge/pymysql/constants', 'mkdir -p "$BRIDGE_CONTEXT/pymysql/constants"')) {
  if ($install -notmatch [regex]::Escape($needle)) {
    throw "bridge dependency copy guard missing: $needle"
  }
}
if ($install -notmatch 'REQUIRE_BRIDGE=\$\{YJC_REQUIRE_BRIDGE:-1\}') {
  throw 'bridge module is not enabled by default'
}
foreach ($needle in @('docker build --pull=false', 'BRIDGE_IMAGE', 'NGINX_IMAGE', 'BRIDGE_ENV_HOST', 'YJC_B_BINARY_HOST')) {
  if ($install -notmatch [regex]::Escape($needle)) {
    throw "bridge install guard missing: $needle"
  }
}
foreach ($needle in @('yjc-lovol-mock-local:2', 'MOCK_LOCAL_ONLY', 'MOCK_MACHINE', '/opt/yjc-local/mock_lovol_https.pyc')) {
  if ($compose -notmatch [regex]::Escape($needle)) {
    throw "Compose patch missing: $needle"
  }
}
foreach ($needle in @('MOCK_LOCAL_ONLY', 'MOCK_MACHINE', 'YJC_LOCAL_AUTH_RUNTIME_HOST', '/opt/yjc-local')) {
  if ($fileCompose -notmatch [regex]::Escape($needle)) {
    throw "file-mode Compose patch missing: $needle"
  }
}
foreach ($needle in @('py_compile', 'AS builder', 'COPY --from=builder', '/opt/yjc-local', 'chmod 600 /app/server.key')) {
  if ($dockerfile -notmatch [regex]::Escape($needle)) {
    throw "Dockerfile missing image-only build guard: $needle"
  }
}
if ($bridgeDockerfile -match 'COPY\s+app\.py\s') {
  throw 'bridge Dockerfile must not copy plaintext app.py'
}
if ($bridgeDockerfile -notmatch 'COPY\s+app\.pyc\s') {
  throw 'bridge Dockerfile must copy app.pyc'
}
if ($bridgeDockerfile -notmatch 'COPY\s+pymysql/') {
  throw 'bridge Dockerfile must copy vendored PyMySQL bytecode'
}
$bridgePyc = [IO.File]::ReadAllBytes((Join-Path $Root 'bridge/app.pyc'))
if ($bridgePyc.Length -lt 4 -or ([BitConverter]::ToString($bridgePyc[0..3]) -ne 'A7-0D-0D-0A')) {
  throw 'bridge app.pyc is not Python 3.11 bytecode'
}
$bridgeBinary = [IO.File]::ReadAllBytes((Join-Path $Root 'bridge/main_linux_amd64_B'))
if ($bridgeBinary.Length -lt 4 -or ([BitConverter]::ToString($bridgeBinary[0..3]) -ne '7F-45-4C-46')) {
  throw 'bridge B binary is not an ELF executable'
}
if ((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $Root 'bridge/main_linux_amd64_B')).Hash.ToLowerInvariant() -ne 'faf3fe1ea8fbb23a695a3977d64db9d480be01b5b1730a518031a200d27953d0') {
  throw 'bridge B binary hash is not the verified WeRun baseline'
}
if (Get-ChildItem -Recurse -File (Join-Path $Root 'bridge') | Where-Object { $_.Extension -eq '.py' }) {
  throw 'bridge runtime directory contains plaintext Python source'
}
if ($dockerfile -match '05cc241dc757d4f49832a1644d525dfe') {
  throw 'Dockerfile must not embed a machine code from another host'
}
$pycPath = Join-Path $Root 'runtime/mock_lovol_https.pyc'
$pycBytes = [IO.File]::ReadAllBytes($pycPath)
if ($pycBytes.Length -lt 4 -or ([BitConverter]::ToString($pycBytes[0..3]) -ne 'A7-0D-0D-0A')) {
  throw 'runtime pyc is not Python 3.11 bytecode'
}
if ([Text.Encoding]::ASCII.GetString($pycBytes).Contains('05cc241dc757d4f49832a1644d525dfe')) {
  throw 'runtime pyc embeds a machine code from another host'
}

$sumPath = Join-Path $Root 'SHA256SUMS'
if (Test-Path -LiteralPath $sumPath) {
  foreach ($line in Get-Content -LiteralPath $sumPath) {
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+(.+)$') { continue }
    $expected = $Matches[1].ToLowerInvariant()
    $rel = $Matches[2].Replace('/', '\')
    $filePath = Join-Path $Root $rel
    if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) { throw "checksum entry points to missing file: $rel" }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $filePath).Hash.ToLowerInvariant()
    if ($actual -ne $expected) { throw "checksum mismatch: $rel" }
  }
}

Write-Output "package static verification passed: $Root"
