Place the optional verified Docker image archive here before selecting image
mode. File mode does not need this directory.

  yjc-lovol-mock-local-v2.tar.gz

The archive must contain this exact tag:

  yjc-lovol-mock-local:2

The archive is intentionally not included in this workspace because the
Windows host has no Docker builder and the image must be built and tested on a
Linux Docker host. Do not rename the small package ZIP from the older release
to this filename; it is not an image archive.

After placing the archive, create SHA256SUMS in this directory, for example:

  sha256sum yjc-lovol-mock-local-v2.tar.gz > SHA256SUMS

install.sh refuses to load an archive unless its hash is supplied through
SHA256SUMS or YJC_IMAGE_SHA256.
