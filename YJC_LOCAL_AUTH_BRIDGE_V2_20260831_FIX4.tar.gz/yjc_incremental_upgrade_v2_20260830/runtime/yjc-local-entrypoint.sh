#!/bin/bash
set -u

APP_DIR=/home/yangjichang
APP_NAME=yangjichang
UPDATE_FILE="${APP_DIR}/update_temp/unzipped/assets/${APP_NAME}"

# Preserve the existing update convention, but avoid chmod -R over large
# historical upload/update trees.  The backend is responsible for starting
# its A/B protocol children when that feature exists in the image.
if [ -f "${UPDATE_FILE}" ]; then
    if [ -f "${APP_DIR}/${APP_NAME}" ]; then
        mv "${APP_DIR}/${APP_NAME}" "${APP_DIR}/${APP_NAME}-old"
    fi
    mv "${UPDATE_FILE}" "${APP_DIR}/${APP_NAME}"
fi

chmod 755 "${APP_DIR}/${APP_NAME}" 2>/dev/null || true
chmod 755 "${APP_DIR}/main_linux_amd64" 2>/dev/null || true
chmod 755 "${APP_DIR}/main_linux_amd64_B" 2>/dev/null || true

exec "${APP_DIR}/${APP_NAME}"
