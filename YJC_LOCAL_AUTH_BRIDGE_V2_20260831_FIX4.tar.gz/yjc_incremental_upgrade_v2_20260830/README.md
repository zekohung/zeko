# YJC local-auth + protocol-B bridge incremental upgrade v2

这是已有养鸡场的增量升级包，不是新部署包。它不包含 MySQL、Redis、
uploads、logs 或应用源码。默认同时安装两个核心模块：

1. local-only Lovol mock，切断已失效的真实验证上游；
2. protocol-B bridge，提供上传步数和 WeRun 数据接口。

~~~text
runtime/mock_lovol_https.pyc       Python 3.11 mock 字节码（无明文源码）
runtime/yjc-local-entrypoint.sh    轻量启动脚本
bridge/app.pyc                     bridge 字节码
bridge/pymysql/*.pyc               PyMySQL 字节码依赖
bridge/main_linux_amd64_B          x86_64 B 二进制
compose/*.override.yml             mock、bridge、Nginx、轻量入口覆盖层
install.sh / rollback.sh           带门槛的安装和回滚
~~~

## 已核对的两台目标

~~~text
192.168.1.21
  目录：/opt/yangjichang
  已有：server、mock、MySQL、Redis、B bridge、Nginx
  问题：server 容器未真正应用旧 override，A/B 启动后验证失败退出

1.xjyyds.eu.org:1002
  目录：/root/yangjichang
  已有：server、mock、MySQL、Redis、Nginx
  没有：B bridge、旧 override
  问题：A/B 启动后退出，Nginx 只有普通 /prod-api 路由
~~~

两台机器都使用 3.8.1 后端和 Python 3.11 mock 基线。其他版本必须先做
只读分类，不要强行套用。

## 安装前预检

把整个包放到临时目录，不要覆盖 live 目录。下面命令会把归档内的顶层目录剥掉，统一解压到 `/opt/yjc-local-auth-bridge-v2`；1002 只把目标目录改成 `/root/yangjichang`，包目录仍建议放在 `/opt/yjc-local-auth-bridge-v2`。

```sh
mkdir -p /opt/yjc-local-auth-bridge-v2
tar -xzf /root/YJC_LOCAL_AUTH_BRIDGE_V2_20260831.tar.gz \
  -C /opt/yjc-local-auth-bridge-v2 --strip-components=1
```

先执行 dry-run：

~~~sh
# 21
cd /opt/yjc-local-auth-bridge-v2
YJC_TARGET_DIR=/opt/yangjichang YJC_PROJECT=yangjichang YJC_USE_LIGHT_ENTRYPOINT=1 YJC_REQUIRE_BRIDGE=1 YJC_REQUIRE_PROTOCOL=1 YJC_DRY_RUN=1 sh install.sh

# 1002
cd /opt/yjc-local-auth-bridge-v2
YJC_TARGET_DIR=/root/yangjichang YJC_PROJECT=yangjichang YJC_USE_LIGHT_ENTRYPOINT=1 YJC_REQUIRE_BRIDGE=1 YJC_REQUIRE_PROTOCOL=1 YJC_DRY_RUN=1 sh install.sh
~~~

dry-run 不加载镜像、不重建容器，但会在目标目录写入
.yjc-upgrades/local-auth-v2 的审计状态文件；不会触碰四个持久化目录。

预检必须确认：

~~~text
mysql、redis、uploads、logs 四个原目录存在
server、mock 服务存在
Compose 能解析且有 api.lovol.icu 网络别名
server 内有 A/B 文件
Python 3.11 和 Nginx 基础镜像已在本机
~~~

bridge 使用的 MySQL root 密码必须是现有数据库真实密码。安装器会尝试
读取已有 bridge.env、.env 和 Compose 值；读不到时请显式设置：

~~~sh
YJC_MYSQL_PASSWORD='本机实际密码' ...
~~~

不要把密码、Bearer、AuthKey、卡密或机器码写进包文件。

## 正式安装

dry-run 通过后去掉 YJC_DRY_RUN=1。21：

~~~sh
cd /opt/yjc-local-auth-bridge-v2
YJC_TARGET_DIR=/opt/yangjichang YJC_PROJECT=yangjichang YJC_USE_LIGHT_ENTRYPOINT=1 YJC_REQUIRE_BRIDGE=1 YJC_REQUIRE_PROTOCOL=1 sh install.sh
~~~

1002 只把目标目录改成 /root/yangjichang：

~~~sh
cd /opt/yjc-local-auth-bridge-v2
YJC_TARGET_DIR=/root/yangjichang YJC_PROJECT=yangjichang YJC_USE_LIGHT_ENTRYPOINT=1 YJC_REQUIRE_BRIDGE=1 YJC_REQUIRE_PROTOCOL=1 sh install.sh
~~~

安装器会：

~~~text
备份 Compose、override、.env 和非敏感容器清单
复制 mock/bridge/Nginx 构建上下文到目标 state 目录
本地构建或加载变更组件，禁止 registry pull
把 B 二进制以只读挂载提供给 server
重建 mock、server、bridge、Nginx
~~~

Nginx 镜像的预检在临时容器中进行。预检会为
`yangjichang-server` 和 `yangjichang-b-bridge` 临时加入本地主机解析，
仅用于让 `nginx -t` 完成配置语法检查，不会改变正式容器运行时使用的
Compose 网络或代理目标。

安装器不会：

~~~text
重建 MySQL 或 Redis
删除或初始化 mysql、redis、uploads、logs
执行 --remove-orphans
执行 down、down -v、volume prune、system prune
复制其他服务器的机器码、AuthKey、token 或卡密
~~~

1002 没有旧 bridge token 时，安装器会生成新的随机 token，保存到
目标 state 下的 bridge.env（权限 600）。需要给客户端配置时只在目标机
本地读取该文件，不要贴到聊天中。21 已有 token 会尽量复用。

## 安装后验收

~~~sh
docker compose -p yangjichang ps
docker exec yangjichang-server sh -c 'ss -lntp 2>/dev/null || true; ps -ef'
docker exec yangjichang-b-bridge python3 -c 'import urllib.request; print(urllib.request.urlopen("http://127.0.0.1:18080/health", timeout=5).read().decode())'
docker exec yangjichang-nginx nginx -t
docker logs --since 10m yangjichang-lovol-mock 2>&1 | grep -E 'MOCK kmlogon|REAL kmlogon'
~~~

目标状态：

~~~text
server 内 8848、7006 持续监听，A/B 子进程存在
bridge 18080 health 返回 code=200
Nginx /prod-api/yjc-b/health 返回 code=200
mock 出现 MOCK kmlogon，REAL kmlogon 计数为 0
welog.log / welog_B.log 不再在启动后立即退出
~~~

HTTP 200 单独不能证明业务链成功。真实微信登录、账号步数提交和任务执行
仍需另外授权和测试。

## 回滚

每次正式安装都会在目标目录生成：

~~~text
.yjc-upgrades/local-auth-v2/<UTC时间>/
~~~

执行：

~~~sh
YJC_TARGET_DIR=/opt/yangjichang sh rollback.sh
# 或
YJC_TARGET_DIR=/root/yangjichang sh rollback.sh
~~~

回滚恢复原 Compose/override 和旧 mock 镜像引用，再按原配置重建
受影响服务。它不会删除四个持久化目录。若本次在没有 bridge 的主机上
新增了 bridge，回滚会明确提示新 bridge 容器需要人工复核后清理；
不要用宽泛的 prune 命令。

## 兼容边界

适用条件：

~~~text
已有 YangJiChang Compose 项目
已有 server 和 mock 容器
server 镜像内有 main_linux_amd64、main_linux_amd64_B
后端包含 ExternalProcessStarter，可自行产生本机机器码并启动 A/B
mock 使用 Python 3.11
~~~

不适用条件：

~~~text
没有养鸡场容器或目标目录
数据库布局不是原有 ruoyi/wechat_mmtls 结构
后端没有 ExternalProcessStarter
A/B 文件缺失或架构不是 amd64
已有配置混杂且无法确认 project、网络和数据目录
~~~

不适用时先停下，制作独立的 server/bridge 兼容包；不要设置绕过检查的
变量来掩盖失败。

## 可选的 mock 镜像模式

默认 file mode 已携带 Python 3.11 pyc，适合本次核对的 21 和 1002。
如果某台旧机的 mock 不是 Python 3.11，可以在发布机制作 image mode：

~~~sh
docker build --pull=false -f buildspec/mock-local.Dockerfile -t yjc-lovol-mock-local:2 /path/to/mock-lovol
docker save yjc-lovol-mock-local:2 | gzip -c > images/yjc-lovol-mock-local-v2.tar.gz
sha256sum images/yjc-lovol-mock-local-v2.tar.gz > images/SHA256SUMS
~~~

bridge 模块仍只在目标机从字节码构建，不需要 1.3 GB 全量镜像。
