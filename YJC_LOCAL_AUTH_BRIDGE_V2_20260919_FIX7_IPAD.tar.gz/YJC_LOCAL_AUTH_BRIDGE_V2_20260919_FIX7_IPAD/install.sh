#!/bin/sh
# YangJiChang local-validation incremental installer.
#
# This script is intentionally conservative: it never removes containers with
# --remove-orphans, never runs `down -v`, and never touches the persistent
# mysql/redis/uploads/logs directories. Run it on the Linux host that owns the
# existing Compose project. File mode uses the bundled Python 3.11 bytecode;
# image mode is used only when a separately verified archive is present.
set -eu

die() {
    echo "ERROR: $*" >&2
    exit 1
}

note() {
    echo "[yjc-upgrade] $*"
}

sha256_file() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then
        shasum -a 256 "$1" | awk '{print $1}'
    else
        die "sha256sum or shasum is required for artifact verification"
    fi
}

SCRIPT_DIR=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P)
if [ -n "${YJC_TARGET_DIR:-}" ]; then
    TARGET_DIR=$YJC_TARGET_DIR
elif [ -n "${1:-}" ]; then
    TARGET_DIR=$1
elif [ -d /opt/yangjichang ] && [ ! -d /root/yangjichang ]; then
    TARGET_DIR=/opt/yangjichang
elif [ -d /root/yangjichang ] && [ ! -d /opt/yangjichang ]; then
    TARGET_DIR=/root/yangjichang
elif [ -d /opt/yangjichang ] && [ -d /root/yangjichang ]; then
    die "both /opt/yangjichang and /root/yangjichang exist; set YJC_TARGET_DIR explicitly"
else
    die "could not find /opt/yangjichang or /root/yangjichang; set YJC_TARGET_DIR explicitly"
fi

case "$TARGET_DIR" in
    /*) ;;
    *) die "YJC_TARGET_DIR must be an absolute path (got: $TARGET_DIR)" ;;
esac
[ -d "$TARGET_DIR" ] || die "target directory does not exist: $TARGET_DIR"
TARGET_DIR=$(CDPATH='' cd -- "$TARGET_DIR" && pwd -P)
[ "$TARGET_DIR" != "/" ] || die "refusing to use / as target"
HOST_MACHINE=$(uname -m 2>/dev/null || true)
case "$HOST_MACHINE" in
    x86_64|amd64) ;;
    *) die "FIX7 B binary requires an x86_64/amd64 host (detected: $HOST_MACHINE)" ;;
esac

for d in mysql redis uploads logs; do
    [ -d "$TARGET_DIR/$d" ] || die "persistent directory is missing: $TARGET_DIR/$d (refusing to guess a new data path)"
done

command -v docker >/dev/null 2>&1 || die "docker CLI is required"
docker info >/dev/null 2>&1 || die "Docker daemon is not reachable"

if docker compose version >/dev/null 2>&1; then
    COMPOSE_KIND=plugin
elif command -v docker-compose >/dev/null 2>&1 && docker-compose version >/dev/null 2>&1; then
    COMPOSE_KIND=legacy
else
    die "Docker Compose v2 plugin or docker-compose v1 is required"
fi

compose() {
    if [ "$COMPOSE_KIND" = plugin ]; then
        docker compose "$@"
    else
        docker-compose "$@"
    fi
}

# Keep the file count explicit so paths are passed as arguments rather than
# through eval/word splitting. The normal YJC layout is base plus one
# override; users with a different layout can set the two file variables.
BASE_FILE=${YJC_BASE_COMPOSE_FILE:-}
if [ -z "$BASE_FILE" ]; then
    for candidate in docker-compose.yml docker-compose.yaml compose.yml compose.yaml; do
        if [ -f "$TARGET_DIR/$candidate" ]; then
            BASE_FILE="$TARGET_DIR/$candidate"
            break
        fi
    done
fi
[ -n "$BASE_FILE" ] || die "no Compose file found under $TARGET_DIR"
[ -f "$BASE_FILE" ] || die "Compose file does not exist: $BASE_FILE"
case "$BASE_FILE" in
    /*) ;;
    *) BASE_FILE=$(CDPATH='' cd -- "$(dirname -- "$BASE_FILE")" && pwd -P)/$(basename -- "$BASE_FILE") ;;
esac
case "$BASE_FILE" in
    *' '*) die "Compose paths containing spaces are not supported by this POSIX installer" ;;
esac

OVERRIDE_FILE=${YJC_EXISTING_OVERRIDE_FILE:-}
if [ -z "$OVERRIDE_FILE" ] && [ -f "$TARGET_DIR/docker-compose.override.yml" ]; then
    OVERRIDE_FILE="$TARGET_DIR/docker-compose.override.yml"
fi
if [ -n "$OVERRIDE_FILE" ]; then
    [ -f "$OVERRIDE_FILE" ] || die "existing override does not exist: $OVERRIDE_FILE"
    case "$OVERRIDE_FILE" in
        /*) ;;
        *) OVERRIDE_FILE=$(CDPATH='' cd -- "$(dirname -- "$OVERRIDE_FILE")" && pwd -P)/$(basename -- "$OVERRIDE_FILE") ;;
    esac
    case "$OVERRIDE_FILE" in
        *' '*) die "Compose paths containing spaces are not supported by this POSIX installer" ;;
    esac
fi

ENV_FILE=""
if [ -f "$TARGET_DIR/.env" ]; then
    ENV_FILE="$TARGET_DIR/.env"
fi
MANAGED_ENV_FILE="$TARGET_DIR/.env"
MANAGED_ENV_BEGIN='# BEGIN YJC FIX7 MANAGED COMPOSE'
MANAGED_ENV_END='# END YJC FIX7 MANAGED COMPOSE'
ORIGINAL_ENV_PRESENT=0
if [ -n "$ENV_FILE" ]; then
    [ ! -L "$ENV_FILE" ] || die "refusing to replace symlinked environment file: $ENV_FILE"
    ORIGINAL_ENV_PRESENT=1
fi

SERVER_CONTAINER=${YJC_SERVER_CONTAINER:-yangjichang-server}
MOCK_CONTAINER=${YJC_MOCK_CONTAINER:-yangjichang-lovol-mock}
BRIDGE_CONTAINER=${YJC_BRIDGE_CONTAINER:-yangjichang-b-bridge}
NGINX_CONTAINER=${YJC_NGINX_CONTAINER:-yangjichang-nginx}
SERVER_SERVICE=${YJC_SERVER_SERVICE:-yangjichang-server}
MOCK_SERVICE=${YJC_MOCK_SERVICE:-yangjichang-lovol-mock}
BRIDGE_SERVICE=${YJC_BRIDGE_SERVICE:-yangjichang-b-bridge}
NGINX_SERVICE=${YJC_NGINX_SERVICE:-yangjichang-nginx}
MYSQL_SERVICE=${YJC_MYSQL_SERVICE:-yangjichang-mysql}
MYSQL_CONTAINER=${YJC_MYSQL_CONTAINER:-$MYSQL_SERVICE}
# The bridge talks to the Compose services, never to a build-host LAN IP.
# These two overrides are useful when an existing deployment uses different
# service names; the defaults follow the detected target service variables.
BRIDGE_MYSQL_HOST=${YJC_BRIDGE_MYSQL_HOST:-$MYSQL_SERVICE}
BRIDGE_B_HOST=${YJC_BRIDGE_B_HOST:-$SERVER_SERVICE}
case "$BRIDGE_MYSQL_HOST" in
    ''|*[!A-Za-z0-9_.:_-]*) die "YJC_BRIDGE_MYSQL_HOST contains unsupported characters" ;;
esac
case "$BRIDGE_B_HOST" in
    ''|*[!A-Za-z0-9_.:_-]*) die "YJC_BRIDGE_B_HOST contains unsupported characters" ;;
esac
REQUIRE_BRIDGE=${YJC_REQUIRE_BRIDGE:-1}
case "$REQUIRE_BRIDGE" in 0|1) ;; *) die "YJC_REQUIRE_BRIDGE must be 0 or 1" ;; esac

STATE_ROOT="$TARGET_DIR/.yjc-upgrades/local-auth-v2"

# A second run of the same FIX7 package is a verified no-op. If a previous
# run wrote the managed block but did not finish, require rollback instead of
# stacking another state layer on top of an uncertain installation.
if [ -n "$ENV_FILE" ] && grep -Fqx "$MANAGED_ENV_BEGIN" "$ENV_FILE"; then
    [ "$(grep -Fxc "$MANAGED_ENV_BEGIN" "$ENV_FILE" || true)" -eq 1 ] || die "the existing .env has duplicate FIX7 begin markers"
    [ "$(grep -Fxc "$MANAGED_ENV_END" "$ENV_FILE" || true)" -eq 1 ] || die "the existing .env has no single matching FIX7 end marker"
    [ -f "$STATE_ROOT/latest" ] || die "FIX7 managed .env exists but its latest state pointer is missing; rollback or merge manually"
    EXISTING_STATE=$(sed -n '1p' "$STATE_ROOT/latest")
    case "$EXISTING_STATE" in
        "$STATE_ROOT"/*) ;;
        *) die "FIX7 latest state points outside the target upgrade root" ;;
    esac
    [ -f "$EXISTING_STATE/state.env" ] || die "FIX7 latest state file is missing"
    EXISTING_STATUS=$(awk -F= '$1 == "STATUS" {value=$2} END {print value}' "$EXISTING_STATE/state.env")
    [ "$EXISTING_STATUS" = installed ] || die "a previous FIX7 run did not finish; run rollback.sh before retrying"
    EXISTING_ENV_SHA256=$(awk -F= '$1 == "INSTALLED_ENV_SHA256" {value=$2} END {print value}' "$EXISTING_STATE/state.env")
    [ -n "$EXISTING_ENV_SHA256" ] || die "FIX7 latest state has no installed .env checksum"
    [ "$(sha256_file "$ENV_FILE")" = "$EXISTING_ENV_SHA256" ] || die "FIX7 managed .env was edited after installation; preserve it and merge manually"
    EXISTING_REQUIRE_BRIDGE=$(awk -F= '$1 == "REQUIRE_BRIDGE" {value=$2} END {print value}' "$EXISTING_STATE/state.env")
    existing_container_running() {
        [ "$(docker inspect -f '{{.State.Status}}' "$1" 2>/dev/null || true)" = running ] || die "FIX7 is installed but container $1 is not running"
    }
    existing_container_running "$SERVER_CONTAINER"
    existing_container_running "$MOCK_CONTAINER"
    if [ "$EXISTING_REQUIRE_BRIDGE" = 1 ]; then
        ACTIVE_B_SOURCE=$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/home/yangjichang/main_linux_amd64_B"}}{{.Source}}{{end}}{{end}}' "$SERVER_CONTAINER" 2>/dev/null || true)
        [ -f "$ACTIVE_B_SOURCE" ] || die "FIX7 state is installed but the active B bind mount is missing"
        cmp -s "$SCRIPT_DIR/bridge/main_linux_amd64_B" "$ACTIVE_B_SOURCE" || die "FIX7 is installed but the active B binary differs from this package"
        existing_container_running "$BRIDGE_CONTAINER"
        existing_container_running "$NGINX_CONTAINER"
    fi
    (
        unset COMPOSE_FILE COMPOSE_PATH_SEPARATOR COMPOSE_PROJECT_NAME
        unset YJC_LOCAL_AUTH_RUNTIME_HOST YJC_LOCAL_AUTH_MOCK_IMAGE YJC_LIGHT_ENTRYPOINT_HOST
        unset YJC_B_BINARY_HOST YJC_BRIDGE_CONTEXT YJC_NGINX_CONTEXT YJC_BRIDGE_ENV_HOST
        unset YJC_BRIDGE_IMAGE YJC_NGINX_IMAGE YJC_PYTHON_BASE_IMAGE YJC_NGINX_BASE_IMAGE
        cd "$TARGET_DIR"
        compose config --quiet
    ) || die "FIX7 is installed but normal docker compose config is invalid"
    note "FIX7 is already installed and healthy; no files or containers were changed"
    exit 0
fi

REQUESTED_PROJECT=${YJC_PROJECT:-}
PROJECT=$REQUESTED_PROJECT
CONTAINER_PROJECT=""
if docker inspect "$SERVER_CONTAINER" >/dev/null 2>&1; then
    CONTAINER_PROJECT=$(docker inspect -f '{{index .Config.Labels "com.docker.compose.project"}}' "$SERVER_CONTAINER" 2>/dev/null || true)
fi
case "$CONTAINER_PROJECT" in
    ''|'<no value>') CONTAINER_PROJECT="" ;;
esac
if [ -z "$PROJECT" ]; then
    PROJECT=$CONTAINER_PROJECT
fi
if [ -n "$REQUESTED_PROJECT" ] && [ -n "$CONTAINER_PROJECT" ] && [ "$REQUESTED_PROJECT" != "$CONTAINER_PROJECT" ]; then
    die "YJC_PROJECT='$REQUESTED_PROJECT' does not match the running server project label"
fi
if [ -z "$PROJECT" ]; then
    PROJECT=$(basename -- "$TARGET_DIR")
    note "Compose project label was not found; using directory name '$PROJECT'. Set YJC_PROJECT if this is not the old project."
fi

compose_base() {
    if [ -n "$OVERRIDE_FILE" ] && [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" "$@"
    elif [ -n "$OVERRIDE_FILE" ]; then
        compose -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" "$@"
    elif [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" "$@"
    else
        compose -p "$PROJECT" -f "$BASE_FILE" "$@"
    fi
}

has_service() {
    printf '%s\n' "$SERVICES" | grep -Fx "$1" >/dev/null 2>&1
}

SERVICES=$(compose_base config --services 2>/dev/null) || die "Compose config failed; inspect the original files before upgrading"
has_service "$SERVER_SERVICE" || die "server service '$SERVER_SERVICE' is not present in the merged Compose config"
has_service "$MOCK_SERVICE" || die "mock service '$MOCK_SERVICE' is not present in the merged Compose config"

if ! has_service "$MYSQL_SERVICE"; then
    note "mysql service name '$MYSQL_SERVICE' is not present in the merged Compose config; data-path checks remain mandatory"
fi
if ! printf '%s\n' "$SERVICES" | grep -Fx 'yangjichang-redis' >/dev/null 2>&1; then
    note "redis service name is not the usual yangjichang-redis; data-path checks remain mandatory"
fi
ORIGINAL_HAS_BRIDGE=0
if has_service "$BRIDGE_SERVICE"; then
    ORIGINAL_HAS_BRIDGE=1
fi

STAMP=$(date -u +%Y%m%dT%H%M%SZ)
STATE_DIR="$STATE_ROOT/$STAMP"
PATCH_FILE="$STATE_DIR/local-auth.override.yml"
BRIDGE_PATCH_FILE="$STATE_DIR/bridge.override.yml"
LIGHT_PATCH_FILE="$STATE_DIR/server-light.override.yml"
LIGHT_ENTRYPOINT_FILE="$STATE_DIR/yjc-local-entrypoint.sh"
BRIDGE_CONTEXT="$STATE_DIR/bridge"
NGINX_CONTEXT="$STATE_DIR/nginx"
BINARY_HOST="$STATE_DIR/main_linux_amd64_B"
BRIDGE_ENV_HOST="$STATE_DIR/bridge.env"
BRIDGE_IMAGE=${YJC_BRIDGE_IMAGE:-yjc-b-bridge-local:v2}
NGINX_IMAGE=${YJC_NGINX_IMAGE:-yjc-nginx-b-bridge-local:v2}
PYTHON_BASE_IMAGE=${YJC_PYTHON_BASE_IMAGE:-crpi-alum0hjwgw1q0tig.cn-qingdao.personal.cr.aliyuncs.com/wx_jichang/wxyjc:666-python311-slim}
NGINX_BASE_IMAGE=${YJC_NGINX_BASE_IMAGE:-crpi-alum0hjwgw1q0tig.cn-qingdao.personal.cr.aliyuncs.com/wx_jichang/wxyjc:666-nginx}
umask 077
mkdir -p "$STATE_ROOT"
[ ! -e "$STATE_DIR" ] || die "upgrade state already exists for this second: $STATE_DIR"
mkdir "$STATE_DIR"

CONFIG_BEFORE="$STATE_DIR/compose-before.yml"
compose_base config > "$CONFIG_BEFORE" || die "could not render the current Compose config"
chmod 600 "$CONFIG_BEFORE"

# Save the exact Compose inputs and non-secret container inventory before any
# image or container mutation. The .env copy is mode 600 and is never printed.
mkdir -p "$STATE_DIR/config"
cp -p "$BASE_FILE" "$STATE_DIR/config/base.compose"
if [ -n "$OVERRIDE_FILE" ]; then
    cp -p "$OVERRIDE_FILE" "$STATE_DIR/config/override.compose"
fi
if [ -n "$ENV_FILE" ]; then
    cp -p "$ENV_FILE" "$STATE_DIR/config/.env"
    chmod 600 "$STATE_DIR/config/.env"
fi
ENV_BASE_FILE="$STATE_DIR/config/.env.unmanaged"
if [ -n "$ENV_FILE" ]; then
    awk -v begin="$MANAGED_ENV_BEGIN" -v end="$MANAGED_ENV_END" '
        $0 == begin {
            if (inside || seen_begin) bad=1
            inside=1
            seen_begin=1
            next
        }
        $0 == end {
            if (!inside || seen_end) bad=1
            inside=0
            seen_end=1
            next
        }
        !inside { print }
        END {
            if (inside || seen_begin != seen_end || bad) exit 42
        }
    ' "$ENV_FILE" > "$ENV_BASE_FILE" || die "the existing .env has malformed YJC FIX7 managed markers"
else
    : > "$ENV_BASE_FILE"
fi
chmod 600 "$ENV_BASE_FILE"
if grep -Eq '^[[:space:]]*(COMPOSE_FILE|COMPOSE_PATH_SEPARATOR|YJC_LOCAL_AUTH_RUNTIME_HOST|YJC_LOCAL_AUTH_MOCK_IMAGE|YJC_LIGHT_ENTRYPOINT_HOST|YJC_B_BINARY_HOST|YJC_BRIDGE_CONTEXT|YJC_NGINX_CONTEXT|YJC_BRIDGE_ENV_HOST|YJC_BRIDGE_IMAGE|YJC_NGINX_IMAGE|YJC_PYTHON_BASE_IMAGE|YJC_NGINX_BASE_IMAGE)[[:space:]]*=' "$ENV_BASE_FILE"; then
    die "the existing .env defines Compose/FIX7 control keys outside the managed block; preserve those settings and merge manually"
fi
docker ps -a --format '{{.Names}}\t{{.Image}}\t{{.Status}}' > "$STATE_DIR/containers-before.txt" 2>/dev/null || true
docker image ls --no-trunc > "$STATE_DIR/images-before.txt" 2>/dev/null || true
chmod 600 "$STATE_DIR/containers-before.txt" "$STATE_DIR/images-before.txt" 2>/dev/null || true

# Refuse to continue if the merged config does not visibly preserve the four
# known persistent paths. This catches running a full package from a new
# empty directory.
for d in mysql redis uploads logs; do
    if ! grep -F "$TARGET_DIR/$d" "$CONFIG_BEFORE" >/dev/null 2>&1 && ! grep -F "./$d" "$CONFIG_BEFORE" >/dev/null 2>&1; then
        die "merged Compose config does not reference the expected persistent path '$d'"
    fi
done

if ! grep -F 'api.lovol.icu' "$CONFIG_BEFORE" >/dev/null 2>&1; then
    die "merged Compose config has no api.lovol.icu network alias; stop and adapt this target explicitly"
fi

if ! docker inspect "$MOCK_CONTAINER" >/dev/null 2>&1; then
    [ "${YJC_ALLOW_MISSING_CONTAINERS:-0}" = 1 ] || die "mock container '$MOCK_CONTAINER' is missing; set YJC_ALLOW_MISSING_CONTAINERS=1 only after auditing the stopped deployment"
fi
if ! docker inspect "$SERVER_CONTAINER" >/dev/null 2>&1; then
    [ "${YJC_ALLOW_MISSING_CONTAINERS:-0}" = 1 ] || die "server container '$SERVER_CONTAINER' is missing; set YJC_ALLOW_MISSING_CONTAINERS=1 only after auditing the stopped deployment"
fi

MODE=${YJC_LOCAL_AUTH_MODE:-auto}
case "$MODE" in
    auto|image|file) ;;
    *) die "YJC_LOCAL_AUTH_MODE must be auto, image, or file" ;;
esac

IMAGE_TAG=${YJC_LOCAL_AUTH_MOCK_IMAGE:-yjc-lovol-mock-local:2}
IMAGE_ARCHIVE=${YJC_IMAGE_ARCHIVE:-$SCRIPT_DIR/images/yjc-lovol-mock-local-v2.tar.gz}
RUNTIME_PYC="$SCRIPT_DIR/runtime/mock_lovol_https.pyc"

# File mode is the small path for the common FIX4/FIX6 Python 3.11 deployments.
# Image mode is preferred when a verified archive has been supplied.
if [ "$MODE" = auto ]; then
    IMAGE_HASH_AVAILABLE=0
    if [ -n "${YJC_IMAGE_SHA256:-}" ]; then
        IMAGE_HASH_AVAILABLE=1
    elif [ -f "$SCRIPT_DIR/images/SHA256SUMS" ] && grep -Eq '^[[:xdigit:]]{64}[[:space:]]+' "$SCRIPT_DIR/images/SHA256SUMS"; then
        IMAGE_HASH_AVAILABLE=1
    fi
    if [ -f "$IMAGE_ARCHIVE" ] && [ "$IMAGE_HASH_AVAILABLE" = 1 ]; then
        MODE=image
    else
        MODE='file'
    fi
fi
if [ "$MODE" = image ]; then
    [ -f "$IMAGE_ARCHIVE" ] || die "verified image archive is missing: $IMAGE_ARCHIVE"
else
    [ -f "$RUNTIME_PYC" ] || die "file mode requires runtime/mock_lovol_https.pyc"
    if command -v od >/dev/null 2>&1; then
        PYC_MAGIC=$(od -An -tx1 -N4 "$RUNTIME_PYC" | tr -d ' \n')
        [ "$PYC_MAGIC" = a70d0d0a ] || die "file mode bytecode is not Python 3.11 (magic=$PYC_MAGIC)"
    fi
fi

if [ "$REQUIRE_BRIDGE" = 1 ]; then
    for required in bridge/app.pyc bridge/Dockerfile bridge/main_linux_amd64_B bridge/pymysql bridge/pymysql/constants bridge/SHA256SUMS bridge/nginx/Dockerfile bridge/nginx/yjc-b-bridge.location.conf compose/docker-compose.bridge.override.yml; do
        [ -e "$SCRIPT_DIR/$required" ] || die "bridge module file is missing: $required"
    done
    (cd "$SCRIPT_DIR/bridge" && sha256sum -c SHA256SUMS >/dev/null) || die "bridge module SHA256 verification failed"
fi

REQUIRE_PROTOCOL=${YJC_REQUIRE_PROTOCOL:-auto}
case "$REQUIRE_PROTOCOL" in
    auto|0|1) ;;
    *) die "YJC_REQUIRE_PROTOCOL must be auto, 0, or 1" ;;
esac

RUNTIME_SHA256=""
if [ "$MODE" = file ]; then
    RUNTIME_SHA256=$(sha256_file "$RUNTIME_PYC")
    if [ -f "$SCRIPT_DIR/runtime/SHA256SUMS" ]; then
        EXPECTED_RUNTIME_SHA256=$(awk -v n="$(basename -- "$RUNTIME_PYC")" '$2 == n {print $1; exit}' "$SCRIPT_DIR/runtime/SHA256SUMS" || true)
        [ -n "$EXPECTED_RUNTIME_SHA256" ] || die "runtime/SHA256SUMS has no entry for $(basename -- "$RUNTIME_PYC")"
        [ "$(printf '%s' "$RUNTIME_SHA256" | tr '[:upper:]' '[:lower:]')" = "$(printf '%s' "$EXPECTED_RUNTIME_SHA256" | tr '[:upper:]' '[:lower:]')" ] || die "runtime bytecode SHA256 mismatch"
    fi
fi

ARCHIVE_SHA256=""
EXPECTED_SHA256=""
if [ "$MODE" = image ]; then
    ARCHIVE_SHA256=$(sha256_file "$IMAGE_ARCHIVE")
    EXPECTED_SHA256=${YJC_IMAGE_SHA256:-}
    if [ -z "$EXPECTED_SHA256" ] && [ -f "$SCRIPT_DIR/images/SHA256SUMS" ]; then
        EXPECTED_SHA256=$(awk -v n="$(basename -- "$IMAGE_ARCHIVE")" '$2 == n {print $1; exit}' "$SCRIPT_DIR/images/SHA256SUMS" || true)
    fi
    [ -n "$EXPECTED_SHA256" ] || die "no expected SHA256 for image archive; set YJC_IMAGE_SHA256 or ship images/SHA256SUMS"
    case "$EXPECTED_SHA256" in
        *[!0123456789abcdefABCDEF]*) die "invalid expected SHA256" ;;
    esac
    [ "${#EXPECTED_SHA256}" -eq 64 ] || die "expected SHA256 must contain 64 hexadecimal characters"
    [ "$(printf '%s' "$ARCHIVE_SHA256" | tr '[:upper:]' '[:lower:]')" = "$(printf '%s' "$EXPECTED_SHA256" | tr '[:upper:]' '[:lower:]')" ] || die "image archive SHA256 mismatch"
    note "image archive hash verified: ${ARCHIVE_SHA256}"
else
    note "using file mode; runtime bytecode will be copied to target state"
fi

OLD_MOCK_IMAGE_REF=""
OLD_MOCK_IMAGE_ID=""
if docker inspect "$MOCK_CONTAINER" >/dev/null 2>&1; then
    OLD_MOCK_IMAGE_REF=$(docker inspect -f '{{.Config.Image}}' "$MOCK_CONTAINER" 2>/dev/null || true)
    OLD_MOCK_IMAGE_ID=$(docker inspect -f '{{.Image}}' "$MOCK_CONTAINER" 2>/dev/null || true)
fi
case "$OLD_MOCK_IMAGE_REF" in
    ''|'<no value>') OLD_MOCK_IMAGE_REF="" ;;
esac
case "$OLD_MOCK_IMAGE_ID" in
    ''|'<no value>') OLD_MOCK_IMAGE_ID="" ;;
esac
if [ -z "$OLD_MOCK_IMAGE_ID" ] && [ "${YJC_ALLOW_NO_OLD_IMAGE:-0}" != 1 ]; then
    die "cannot record the old mock image for rollback; set YJC_ALLOW_NO_OLD_IMAGE=1 only after accepting manual rollback"
fi
OLD_SERVER_IMAGE_REF=""
OLD_SERVER_IMAGE_ID=""
if docker inspect "$SERVER_CONTAINER" >/dev/null 2>&1; then
    OLD_SERVER_IMAGE_REF=$(docker inspect -f '{{.Config.Image}}' "$SERVER_CONTAINER" 2>/dev/null || true)
    OLD_SERVER_IMAGE_ID=$(docker inspect -f '{{.Image}}' "$SERVER_CONTAINER" 2>/dev/null || true)
fi
case "$OLD_SERVER_IMAGE_REF" in
    '<no value>') OLD_SERVER_IMAGE_REF="" ;;
esac
case "$OLD_SERVER_IMAGE_ID" in
    '<no value>') OLD_SERVER_IMAGE_ID="" ;;
esac
OLD_BRIDGE_IMAGE_REF=""
OLD_BRIDGE_IMAGE_ID=""
if docker inspect "$BRIDGE_CONTAINER" >/dev/null 2>&1; then
    OLD_BRIDGE_IMAGE_REF=$(docker inspect -f '{{.Config.Image}}' "$BRIDGE_CONTAINER" 2>/dev/null || true)
    OLD_BRIDGE_IMAGE_ID=$(docker inspect -f '{{.Image}}' "$BRIDGE_CONTAINER" 2>/dev/null || true)
fi
case "$OLD_BRIDGE_IMAGE_REF" in
    ''|'<no value>') OLD_BRIDGE_IMAGE_REF="" ;;
esac
case "$OLD_BRIDGE_IMAGE_ID" in
    ''|'<no value>') OLD_BRIDGE_IMAGE_ID="" ;;
esac
OLD_NGINX_IMAGE_REF=""
OLD_NGINX_IMAGE_ID=""
if docker inspect "$NGINX_CONTAINER" >/dev/null 2>&1; then
    OLD_NGINX_IMAGE_REF=$(docker inspect -f '{{.Config.Image}}' "$NGINX_CONTAINER" 2>/dev/null || true)
    OLD_NGINX_IMAGE_ID=$(docker inspect -f '{{.Image}}' "$NGINX_CONTAINER" 2>/dev/null || true)
fi
case "$OLD_NGINX_IMAGE_REF" in
    ''|'<no value>') OLD_NGINX_IMAGE_REF="" ;;
esac
case "$OLD_NGINX_IMAGE_ID" in
    ''|'<no value>') OLD_NGINX_IMAGE_ID="" ;;
esac

ORIGINAL_ENV_SHA256=""
if [ "$ORIGINAL_ENV_PRESENT" = 1 ]; then
    ORIGINAL_ENV_SHA256=$(sha256_file "$STATE_DIR/config/.env")
fi

cat > "$STATE_DIR/state.env" <<EOF
VERSION=local-auth-v2-fix7-ipad
MODE=$MODE
REQUIRE_BRIDGE=$REQUIRE_BRIDGE
STAMP=$STAMP
TARGET_DIR=$TARGET_DIR
PROJECT=$PROJECT
BASE_FILE=$BASE_FILE
OVERRIDE_FILE=$OVERRIDE_FILE
ENV_FILE=$ENV_FILE
SERVER_SERVICE=$SERVER_SERVICE
MOCK_SERVICE=$MOCK_SERVICE
MYSQL_SERVICE=$MYSQL_SERVICE
MYSQL_CONTAINER=$MYSQL_CONTAINER
BRIDGE_MYSQL_HOST=$BRIDGE_MYSQL_HOST
BRIDGE_B_HOST=$BRIDGE_B_HOST
SERVER_CONTAINER=$SERVER_CONTAINER
MOCK_CONTAINER=$MOCK_CONTAINER
IMAGE_TAG=$IMAGE_TAG
IMAGE_ARCHIVE=$IMAGE_ARCHIVE
RUNTIME_PYC=$RUNTIME_PYC
RUNTIME_SHA256=$RUNTIME_SHA256
ARCHIVE_SHA256=$ARCHIVE_SHA256
OLD_MOCK_IMAGE_REF=$OLD_MOCK_IMAGE_REF
OLD_MOCK_IMAGE_ID=$OLD_MOCK_IMAGE_ID
OLD_SERVER_IMAGE_REF=$OLD_SERVER_IMAGE_REF
OLD_SERVER_IMAGE_ID=$OLD_SERVER_IMAGE_ID
OLD_BRIDGE_IMAGE_REF=$OLD_BRIDGE_IMAGE_REF
OLD_BRIDGE_IMAGE_ID=$OLD_BRIDGE_IMAGE_ID
OLD_NGINX_IMAGE_REF=$OLD_NGINX_IMAGE_REF
OLD_NGINX_IMAGE_ID=$OLD_NGINX_IMAGE_ID
PATCH_FILE=$PATCH_FILE
BRIDGE_PATCH_FILE=$BRIDGE_PATCH_FILE
LIGHT_PATCH_FILE=$LIGHT_PATCH_FILE
LIGHT_ENTRYPOINT_FILE=$LIGHT_ENTRYPOINT_FILE
BRIDGE_SERVICE=$BRIDGE_SERVICE
NGINX_SERVICE=$NGINX_SERVICE
BRIDGE_CONTAINER=$BRIDGE_CONTAINER
NGINX_CONTAINER=$NGINX_CONTAINER
BRIDGE_IMAGE=$BRIDGE_IMAGE
NGINX_IMAGE=$NGINX_IMAGE
PYTHON_BASE_IMAGE=$PYTHON_BASE_IMAGE
NGINX_BASE_IMAGE=$NGINX_BASE_IMAGE
BRIDGE_CONTEXT=$BRIDGE_CONTEXT
NGINX_CONTEXT=$NGINX_CONTEXT
BINARY_HOST=$BINARY_HOST
BRIDGE_ENV_HOST=$BRIDGE_ENV_HOST
ORIGINAL_HAS_BRIDGE=$ORIGINAL_HAS_BRIDGE
ORIGINAL_ENV_PRESENT=$ORIGINAL_ENV_PRESENT
ORIGINAL_ENV_SHA256=$ORIGINAL_ENV_SHA256
MANAGED_ENV_FILE=$MANAGED_ENV_FILE
CONFIG_BACKUP_DIR=$STATE_DIR/config
EOF
chmod 600 "$STATE_DIR/state.env"

if [ "$MODE" = image ]; then
    cp -p "$SCRIPT_DIR/compose/docker-compose.local-auth.override.yml" "$PATCH_FILE"
else
    RUNTIME_HOST="$STATE_DIR/runtime"
    mkdir -p "$RUNTIME_HOST"
    cp -p "$RUNTIME_PYC" "$RUNTIME_HOST/mock_lovol_https.pyc"
    chmod 600 "$RUNTIME_HOST/mock_lovol_https.pyc"
    export YJC_LOCAL_AUTH_RUNTIME_HOST="$RUNTIME_HOST"
    cp -p "$SCRIPT_DIR/compose/docker-compose.local-auth.file.override.yml" "$PATCH_FILE"
fi
chmod 600 "$PATCH_FILE"
if [ "$MODE" = file ]; then
    printf 'RUNTIME_HOST=%s\n' "$RUNTIME_HOST" >> "$STATE_DIR/state.env"
fi

USE_LIGHT=${YJC_USE_LIGHT_ENTRYPOINT:-auto}
if [ "$USE_LIGHT" = auto ]; then
    USE_LIGHT=0
    if docker inspect "$SERVER_CONTAINER" >/dev/null 2>&1; then
        if docker exec "$SERVER_CONTAINER" sh -c 'grep -F "chmod 755 -R" /home/yangjichang/entrypoint.sh 2>/dev/null' >/dev/null 2>&1; then
            USE_LIGHT=1
            note "recursive chmod entrypoint detected; enabling the tested light entrypoint"
        fi
    fi
fi
case "$USE_LIGHT" in
    0|1) ;;
    *) die "YJC_USE_LIGHT_ENTRYPOINT must be 0, 1, or auto" ;;
esac

if [ "$USE_LIGHT" = 1 ]; then
    cp -p "$SCRIPT_DIR/runtime/yjc-local-entrypoint.sh" "$LIGHT_ENTRYPOINT_FILE"
    chmod 700 "$LIGHT_ENTRYPOINT_FILE"
    # Compose interpolation reads this exported absolute path. It is kept in
    # the target-side state directory, away from persistent data trees.
    export YJC_LIGHT_ENTRYPOINT_HOST="$LIGHT_ENTRYPOINT_FILE"
    cp -p "$SCRIPT_DIR/compose/docker-compose.server-light.override.yml" "$LIGHT_PATCH_FILE"
    chmod 600 "$LIGHT_PATCH_FILE"
else
    : > "$LIGHT_PATCH_FILE"
    chmod 600 "$LIGHT_PATCH_FILE"
fi

if [ "$REQUIRE_BRIDGE" = 1 ]; then
    mkdir -p "$BRIDGE_CONTEXT/pymysql/constants" "$NGINX_CONTEXT"
    cp -p "$SCRIPT_DIR/bridge/app.pyc" "$BRIDGE_CONTEXT/app.pyc"
    cp -p "$SCRIPT_DIR/bridge/pymysql/"*.pyc "$BRIDGE_CONTEXT/pymysql/"
    cp -p "$SCRIPT_DIR/bridge/pymysql/constants/"*.pyc "$BRIDGE_CONTEXT/pymysql/constants/"
    cp -p "$SCRIPT_DIR/bridge/Dockerfile" "$BRIDGE_CONTEXT/Dockerfile"
    cp -p "$SCRIPT_DIR/bridge/main_linux_amd64_B" "$BINARY_HOST"
    cp -p "$SCRIPT_DIR/bridge/nginx/Dockerfile" "$NGINX_CONTEXT/Dockerfile"
    cp -p "$SCRIPT_DIR/bridge/nginx/yjc-b-bridge.location.conf" "$NGINX_CONTEXT/yjc-b-bridge.location.conf"
    chmod 600 "$BRIDGE_CONTEXT/app.pyc"
    # Keep the protocol binary executable after copying it to the target-side
    # state directory; chmod 600 would make a non-root server unable to spawn
    # it.
    chmod 755 "$BINARY_HOST"
    if [ -z "${YJC_MYSQL_PASSWORD:-}" ]; then
        YJC_MYSQL_PASSWORD=""
        if docker inspect "$BRIDGE_CONTAINER" >/dev/null 2>&1; then
            YJC_MYSQL_PASSWORD=$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$BRIDGE_CONTAINER" 2>/dev/null | awk -F= '$1 == "MYSQL_PASSWORD" {print substr($0,index($0,"=")+1); exit}' || true)
        fi
        if [ -z "$YJC_MYSQL_PASSWORD" ] && docker inspect "$MYSQL_CONTAINER" >/dev/null 2>&1; then
            YJC_MYSQL_PASSWORD=$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$MYSQL_CONTAINER" 2>/dev/null | awk -F= '$1 == "MYSQL_ROOT_PASSWORD" || $1 == "MYSQL_PASSWORD" {print substr($0,index($0,"=")+1); exit}' || true)
        fi
        for candidate in "$TARGET_DIR/b-bridge/bridge.env" "$TARGET_DIR/bridge.env" "$ENV_FILE"; do
            if [ -z "$YJC_MYSQL_PASSWORD" ] && [ -f "$candidate" ]; then
                YJC_MYSQL_PASSWORD=$(awk -F= '$1 == "MYSQL_PASSWORD" {v=substr($0,index($0,"=")+1); gsub(/^['"'"' ]+|['"'"' ]+$/, "", v); print v; exit}' "$candidate" || true)
            fi
        done
        if [ -z "$YJC_MYSQL_PASSWORD" ] && [ -n "$ENV_FILE" ]; then
            YJC_MYSQL_PASSWORD=$(awk -F= '$1 == "MYSQL_ROOT_PASSWORD" {v=substr($0,index($0,"=")+1); gsub(/^["'\'' ]+|["'\'' ]+$/, "", v); print v; exit}' "$ENV_FILE" || true)
        fi
        if [ -z "$YJC_MYSQL_PASSWORD" ]; then
            YJC_MYSQL_PASSWORD=$(awk '/^[[:space:]]*MYSQL_ROOT_PASSWORD[[:space:]]*:/ {v=$0; sub(/^[^:]*:[[:space:]]*/, "", v); gsub(/["'\'' ]/, "", v); print v; exit}' "$BASE_FILE" || true)
        fi
    fi
    case "$YJC_MYSQL_PASSWORD" in
        *'${'*|*'}'*) die "bridge MySQL password is an unresolved Compose variable; set YJC_MYSQL_PASSWORD explicitly" ;;
    esac
    [ -n "$YJC_MYSQL_PASSWORD" ] || die "bridge needs YJC_MYSQL_PASSWORD (the existing MySQL root password); it is not guessed"
    BRIDGE_TOKEN=${YJC_BRIDGE_AUTH_TOKEN:-}
    if [ -z "$BRIDGE_TOKEN" ] && docker inspect "$BRIDGE_CONTAINER" >/dev/null 2>&1; then
        BRIDGE_TOKEN=$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$BRIDGE_CONTAINER" 2>/dev/null | awk -F= '$1 == "BRIDGE_AUTH_TOKEN" {print substr($0,index($0,"=")+1); exit}' || true)
    fi
    for candidate in "$TARGET_DIR/b-bridge/bridge.env" "$TARGET_DIR/bridge.env" "$ENV_FILE"; do
        if [ -z "$BRIDGE_TOKEN" ] && [ -f "$candidate" ]; then
            BRIDGE_TOKEN=$(awk -F= '$1 == "BRIDGE_AUTH_TOKEN" {v=substr($0,index($0,"=")+1); gsub(/^['"'"' ]+|['"'"' ]+$/, "", v); print v; exit}' "$candidate" || true)
        fi
    done
    if [ -z "$BRIDGE_TOKEN" ]; then
        if command -v openssl >/dev/null 2>&1; then
            BRIDGE_TOKEN=$(openssl rand -hex 32)
        else
            BRIDGE_TOKEN=$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')
        fi
        note "no existing bridge token found; generated a new one and stored it mode 600 in the target state"
    fi
    case "$BRIDGE_TOKEN" in
        Bearer\ *) BRIDGE_TOKEN=${BRIDGE_TOKEN#Bearer } ;;
    esac
    case "$BRIDGE_TOKEN" in
        *'${'*|*'}'*) die "bridge token is an unresolved Compose variable; set YJC_BRIDGE_AUTH_TOKEN explicitly" ;;
    esac
    printf '%s\n' \
      "BRIDGE_AUTH_TOKEN=$BRIDGE_TOKEN" \
      "MYSQL_PASSWORD=$YJC_MYSQL_PASSWORD" \
      "MYSQL_HOST=$BRIDGE_MYSQL_HOST" \
      "MYSQL_DATABASE=wechat_mmtls" \
      "B_HOST=$BRIDGE_B_HOST" \
      "B_PORT=7006" \
      "LISTEN_PORT=18080" \
      "B_TIMEOUT_SECONDS=45" > "$BRIDGE_ENV_HOST"
    chmod 600 "$BRIDGE_ENV_HOST"
    export YJC_B_BINARY_HOST="$BINARY_HOST"
    export YJC_BRIDGE_CONTEXT="$BRIDGE_CONTEXT"
    export YJC_NGINX_CONTEXT="$NGINX_CONTEXT"
    export YJC_BRIDGE_ENV_HOST="$BRIDGE_ENV_HOST"
    export YJC_PYTHON_BASE_IMAGE
    export YJC_NGINX_BASE_IMAGE
    export YJC_BRIDGE_IMAGE
    export YJC_NGINX_IMAGE
    cp -p "$SCRIPT_DIR/compose/docker-compose.bridge.override.yml" "$BRIDGE_PATCH_FILE"
    chmod 600 "$BRIDGE_PATCH_FILE"
else
    printf '%s\n' 'services: {}' > "$BRIDGE_PATCH_FILE"
    chmod 600 "$BRIDGE_PATCH_FILE"
fi
compose_patched() {
    if [ "$USE_LIGHT" = 1 ] && [ -n "$OVERRIDE_FILE" ] && [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" -f "$PATCH_FILE" -f "$LIGHT_PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    elif [ "$USE_LIGHT" = 1 ] && [ -n "$OVERRIDE_FILE" ]; then
        compose -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" -f "$PATCH_FILE" -f "$LIGHT_PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    elif [ "$USE_LIGHT" = 1 ] && [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" -f "$PATCH_FILE" -f "$LIGHT_PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    elif [ "$USE_LIGHT" = 1 ]; then
        compose -p "$PROJECT" -f "$BASE_FILE" -f "$PATCH_FILE" -f "$LIGHT_PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    elif [ -n "$OVERRIDE_FILE" ] && [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" -f "$PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    elif [ -n "$OVERRIDE_FILE" ]; then
        compose -p "$PROJECT" -f "$BASE_FILE" -f "$OVERRIDE_FILE" -f "$PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    elif [ -n "$ENV_FILE" ]; then
        compose --env-file "$ENV_FILE" -p "$PROJECT" -f "$BASE_FILE" -f "$PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    else
        compose -p "$PROJECT" -f "$BASE_FILE" -f "$PATCH_FILE" -f "$BRIDGE_PATCH_FILE" "$@"
    fi
}

compose_update() {
    if [ "$COMPOSE_KIND" = plugin ]; then
        compose_patched up -d --no-build --pull never --force-recreate --no-deps "$@"
    else
        # docker-compose v1 has inconsistent support for `up --pull`; the
        # image was already loaded and --no-build prevents a local build.
        compose_patched up -d --no-build --force-recreate --no-deps "$@"
    fi
}

CONFIG_AFTER="$STATE_DIR/compose-after.yml"
compose_patched config > "$CONFIG_AFTER" || die "patched Compose config is invalid; no containers were changed"
chmod 600 "$CONFIG_AFTER"
if [ "$MODE" = image ]; then
    grep -F "$IMAGE_TAG" "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config does not select image $IMAGE_TAG"
else
    grep -F "$RUNTIME_HOST" "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config does not mount the packaged mock runtime"
fi
grep -F 'MOCK_LOCAL_ONLY' "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config does not set MOCK_LOCAL_ONLY=1"
grep -F '/opt/yjc-local/mock_lovol_https.pyc' "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config does not select the packaged mock bytecode"
if [ "$REQUIRE_BRIDGE" = 1 ]; then
    grep -Eq "^[[:space:]]*$BRIDGE_SERVICE:" "$CONFIG_AFTER" || die "patched config has no bridge service $BRIDGE_SERVICE"
    grep -F "$BRIDGE_IMAGE" "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config does not select bridge image $BRIDGE_IMAGE"
    grep -F "$NGINX_IMAGE" "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config does not select nginx image $NGINX_IMAGE"
    grep -F '/home/yangjichang/main_linux_amd64_B' "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config has no B binary mount"
    grep -E 'read_only:[[:space:]]*true|/home/yangjichang/main_linux_amd64_B:ro' "$CONFIG_AFTER" >/dev/null 2>&1 || die "patched config B binary mount is not read-only"
    grep -F '/prod-api/yjc-b/' "$NGINX_CONTEXT/yjc-b-bridge.location.conf" >/dev/null 2>&1 || die "patched nginx config has no yjc-b route"
fi
for d in mysql redis uploads logs; do
    if ! grep -F "$TARGET_DIR/$d" "$CONFIG_AFTER" >/dev/null 2>&1 && ! grep -F "./$d" "$CONFIG_AFTER" >/dev/null 2>&1; then
        die "patched config changed the expected persistent path '$d'; refusing to continue"
    fi
done

# Build the exact .env that makes a normal `cd TARGET && docker compose up -d`
# retain every upgrade layer. Existing user keys are preserved verbatim; only
# the marked block is owned by this installer.
PERSISTENT_COMPOSE_FILES=$BASE_FILE
if [ -n "$OVERRIDE_FILE" ]; then
    PERSISTENT_COMPOSE_FILES="$PERSISTENT_COMPOSE_FILES:$OVERRIDE_FILE"
fi
PERSISTENT_COMPOSE_FILES="$PERSISTENT_COMPOSE_FILES:$PATCH_FILE"
if [ "$USE_LIGHT" = 1 ]; then
    PERSISTENT_COMPOSE_FILES="$PERSISTENT_COMPOSE_FILES:$LIGHT_PATCH_FILE"
fi
if [ "$REQUIRE_BRIDGE" = 1 ]; then
    PERSISTENT_COMPOSE_FILES="$PERSISTENT_COMPOSE_FILES:$BRIDGE_PATCH_FILE"
fi

ENV_CANDIDATE="$STATE_DIR/managed.env.candidate"
cp -p "$ENV_BASE_FILE" "$ENV_CANDIDATE"
{
    printf '\n%s\n' "$MANAGED_ENV_BEGIN"
    printf 'COMPOSE_PROJECT_NAME=%s\n' "$PROJECT"
    printf 'COMPOSE_PATH_SEPARATOR=:\n'
    printf 'COMPOSE_FILE=%s\n' "$PERSISTENT_COMPOSE_FILES"
    if [ "$MODE" = image ]; then
        printf 'YJC_LOCAL_AUTH_MOCK_IMAGE=%s\n' "$IMAGE_TAG"
    else
        printf 'YJC_LOCAL_AUTH_RUNTIME_HOST=%s\n' "$RUNTIME_HOST"
    fi
    if [ "$USE_LIGHT" = 1 ]; then
        printf 'YJC_LIGHT_ENTRYPOINT_HOST=%s\n' "$LIGHT_ENTRYPOINT_FILE"
    fi
    if [ "$REQUIRE_BRIDGE" = 1 ]; then
        printf 'YJC_B_BINARY_HOST=%s\n' "$BINARY_HOST"
        printf 'YJC_BRIDGE_CONTEXT=%s\n' "$BRIDGE_CONTEXT"
        printf 'YJC_NGINX_CONTEXT=%s\n' "$NGINX_CONTEXT"
        printf 'YJC_BRIDGE_ENV_HOST=%s\n' "$BRIDGE_ENV_HOST"
        printf 'YJC_BRIDGE_IMAGE=%s\n' "$BRIDGE_IMAGE"
        printf 'YJC_NGINX_IMAGE=%s\n' "$NGINX_IMAGE"
        printf 'YJC_PYTHON_BASE_IMAGE=%s\n' "$PYTHON_BASE_IMAGE"
        printf 'YJC_NGINX_BASE_IMAGE=%s\n' "$NGINX_BASE_IMAGE"
    fi
    printf '%s\n' "$MANAGED_ENV_END"
} >> "$ENV_CANDIDATE"
chmod 600 "$ENV_CANDIDATE"

persistent_compose() {
    persistent_env=$1
    shift
    (
        unset COMPOSE_FILE COMPOSE_PATH_SEPARATOR COMPOSE_PROJECT_NAME
        unset YJC_LOCAL_AUTH_RUNTIME_HOST YJC_LOCAL_AUTH_MOCK_IMAGE YJC_LIGHT_ENTRYPOINT_HOST
        unset YJC_B_BINARY_HOST YJC_BRIDGE_CONTEXT YJC_NGINX_CONTEXT YJC_BRIDGE_ENV_HOST
        unset YJC_BRIDGE_IMAGE YJC_NGINX_IMAGE YJC_PYTHON_BASE_IMAGE YJC_NGINX_BASE_IMAGE
        cd "$TARGET_DIR"
        if [ "$COMPOSE_KIND" = plugin ]; then
            docker compose --env-file "$persistent_env" "$@"
        else
            docker-compose --env-file "$persistent_env" "$@"
        fi
    )
}

PERSISTENT_CONFIG="$STATE_DIR/compose-persistent.yml"
persistent_compose "$ENV_CANDIDATE" config > "$PERSISTENT_CONFIG" || die "persistent Compose configuration is invalid; no containers were changed"
chmod 600 "$PERSISTENT_CONFIG"
grep -Eq "^[[:space:]]*$MOCK_SERVICE:" "$PERSISTENT_CONFIG" || die "persistent config lost mock service $MOCK_SERVICE"
grep -Eq "^[[:space:]]*$SERVER_SERVICE:" "$PERSISTENT_CONFIG" || die "persistent config lost server service $SERVER_SERVICE"
grep -F '/opt/yjc-local/mock_lovol_https.pyc' "$PERSISTENT_CONFIG" >/dev/null 2>&1 || die "persistent config lost the local-auth runtime"
if [ "$REQUIRE_BRIDGE" = 1 ]; then
    grep -Eq "^[[:space:]]*$BRIDGE_SERVICE:" "$PERSISTENT_CONFIG" || die "persistent config lost bridge service $BRIDGE_SERVICE"
    grep -F "$BINARY_HOST" "$PERSISTENT_CONFIG" >/dev/null 2>&1 || die "persistent config lost the verified B binary mount"
fi

if [ "${YJC_DRY_RUN:-0}" = 1 ]; then
    note "dry run complete; no image was loaded and no container was changed"
    note "rendered config: $CONFIG_AFTER"
    note "persistent .env candidate: $ENV_CANDIDATE"
    exit 0
fi

# Preserve old local image tags before the FIX7 bridge/Nginx builds can move
# an existing tag to a new image ID.
OLD_BRIDGE_BACKUP_TAG=""
if [ "$REQUIRE_BRIDGE" = 1 ] && [ -n "$OLD_BRIDGE_IMAGE_ID" ]; then
    OLD_BRIDGE_BACKUP_TAG="yjc-local-auth-rollback:${STAMP}-bridge"
    docker tag "$OLD_BRIDGE_IMAGE_ID" "$OLD_BRIDGE_BACKUP_TAG" || die "could not tag the old bridge image for rollback"
fi
OLD_NGINX_BACKUP_TAG=""
if [ "$REQUIRE_BRIDGE" = 1 ] && [ -n "$OLD_NGINX_IMAGE_ID" ]; then
    OLD_NGINX_BACKUP_TAG="yjc-local-auth-rollback:${STAMP}-nginx"
    docker tag "$OLD_NGINX_IMAGE_ID" "$OLD_NGINX_BACKUP_TAG" || die "could not tag the old Nginx image for rollback"
fi
{
    printf 'OLD_BRIDGE_BACKUP_TAG=%s\n' "$OLD_BRIDGE_BACKUP_TAG"
    printf 'OLD_NGINX_BACKUP_TAG=%s\n' "$OLD_NGINX_BACKUP_TAG"
} >> "$STATE_DIR/state.env"

if [ "$REQUIRE_BRIDGE" = 1 ]; then
    docker image inspect "$PYTHON_BASE_IMAGE" >/dev/null 2>&1 || die "Python base image is not present locally: $PYTHON_BASE_IMAGE (set YJC_PYTHON_BASE_IMAGE to an existing tag)"
    docker image inspect "$NGINX_BASE_IMAGE" >/dev/null 2>&1 || die "Nginx base image is not present locally: $NGINX_BASE_IMAGE (set YJC_NGINX_BASE_IMAGE to an existing tag)"
    note "building protocol-B bridge image locally (no registry pull)"
    docker build --pull=false --build-arg "PYTHON_BASE_IMAGE=$PYTHON_BASE_IMAGE" -t "$BRIDGE_IMAGE" "$BRIDGE_CONTEXT" >/dev/null || die "bridge image build failed"
    note "building Nginx bridge-route image locally (no registry pull)"
    docker build --pull=false --build-arg "NGINX_BASE_IMAGE=$NGINX_BASE_IMAGE" -t "$NGINX_IMAGE" "$NGINX_CONTEXT" >/dev/null || die "Nginx bridge image build failed"
    # The temporary validation container is not attached to the Compose
    # network, so its Docker DNS cannot resolve the Compose upstream names.
    # These hosts entries are only for config parsing; runtime traffic still
    # uses the real Compose network aliases.
    if ! docker run --rm --pull=never \
        --add-host "yangjichang-server:127.0.0.1" \
        --add-host "yangjichang-b-bridge:127.0.0.1" \
        --entrypoint nginx "$NGINX_IMAGE" -t >/dev/null 2>&1; then
        die "built Nginx bridge image failed nginx -t"
    fi
fi

# Keep the old mock image addressable for rollback before replacing its tag.
OLD_MOCK_BACKUP_TAG=""
if [ -n "$OLD_MOCK_IMAGE_ID" ]; then
    OLD_MOCK_BACKUP_TAG="yjc-local-auth-rollback:${STAMP}-mock"
    docker tag "$OLD_MOCK_IMAGE_ID" "$OLD_MOCK_BACKUP_TAG" || die "could not tag the old mock image for rollback"
fi
{
    printf 'USE_LIGHT=%s\n' "$USE_LIGHT"
    printf 'OLD_MOCK_BACKUP_TAG=%s\n' "$OLD_MOCK_BACKUP_TAG"
} >> "$STATE_DIR/state.env"

if [ "$MODE" = image ]; then
    note "loading image (no registry pull)"
    docker load -i "$IMAGE_ARCHIVE" >/dev/null || die "docker load failed; no Compose action was attempted"
    docker image inspect "$IMAGE_TAG" >/dev/null 2>&1 || die "loaded archive does not contain expected image $IMAGE_TAG"

    HOST_ARCH=$(docker info --format '{{.Architecture}}' 2>/dev/null || true)
    IMAGE_ARCH=$(docker image inspect -f '{{.Architecture}}' "$IMAGE_TAG" 2>/dev/null || true)
    if [ -n "$HOST_ARCH" ] && [ -n "$IMAGE_ARCH" ] && [ "$HOST_ARCH" != "$IMAGE_ARCH" ]; then
        die "image architecture '$IMAGE_ARCH' does not match Docker host '$HOST_ARCH'"
    fi

    # Verify the image contract without printing its environment or filesystem.
    docker run --rm --pull=never --entrypoint /bin/sh "$IMAGE_TAG" -c 'test -r /opt/yjc-local/mock_lovol_https.pyc && test -r /opt/yjc-local/server.crt && test -r /opt/yjc-local/server.key' >/dev/null 2>&1 || die "image $IMAGE_TAG is missing the packaged mock runtime contract"
else
    # File mode uses the existing Python 3.11 mock image and only mounts pyc.
    docker exec "$MOCK_CONTAINER" sh -c 'python3 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)"' >/dev/null 2>&1 || die "file mode requires Python 3.11 in the existing mock container"
    docker exec "$MOCK_CONTAINER" sh -c 'test -r /app/server.crt && test -r /app/server.key' >/dev/null 2>&1 || die "file mode requires the existing mock TLS certificate and key"
fi

# If the server already mounts a Lovol CA file, compare it with the image
# certificate before replacing the mock. File mode intentionally reuses that
# existing certificate; image mode reads the packaged certificate.
if [ "$MODE" = image ] && docker inspect "$SERVER_CONTAINER" >/dev/null 2>&1; then
    SERVER_CA_SOURCE=$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/usr/local/share/ca-certificates/yjc-lovol-mock-ca.crt"}}{{.Source}}{{end}}{{end}}' "$SERVER_CONTAINER" 2>/dev/null || true)
    if [ -n "$SERVER_CA_SOURCE" ] && [ -f "$SERVER_CA_SOURCE" ]; then
        IMAGE_CERT_SHA=$(docker run --rm --pull=never --entrypoint /bin/sh "$IMAGE_TAG" -c 'sha256sum /app/server.crt' 2>/dev/null | awk '{print $1}' || true)
        HOST_CA_SHA=$(sha256_file "$SERVER_CA_SOURCE")
        [ -n "$IMAGE_CERT_SHA" ] && [ "$IMAGE_CERT_SHA" = "$HOST_CA_SHA" ] || die "packaged mock certificate does not match the server's mounted CA"
    fi
fi

note "recreating only $MOCK_SERVICE"
compose_update "$MOCK_SERVICE" >/dev/null || die "mock service update failed; inspect state at $STATE_DIR and use rollback.sh"

if [ "${YJC_RECREATE_SERVER:-1}" = 1 ]; then
    note "recreating only $SERVER_SERVICE (dependencies are not restarted)"
    compose_update "$SERVER_SERVICE" >/dev/null || die "server update failed; inspect state at $STATE_DIR and use rollback.sh"
fi

if [ "$REQUIRE_BRIDGE" = 1 ]; then
    note "recreating only $BRIDGE_SERVICE"
    compose_update "$BRIDGE_SERVICE" >/dev/null || die "bridge service update failed; inspect state at $STATE_DIR and use rollback.sh"
    note "recreating only $NGINX_SERVICE"
    compose_update "$NGINX_SERVICE" >/dev/null || die "Nginx service update failed; inspect state at $STATE_DIR and use rollback.sh"
fi

MOCK_ID=$(compose_patched ps -q "$MOCK_SERVICE" 2>/dev/null || true)
SERVER_ID=$(compose_patched ps -q "$SERVER_SERVICE" 2>/dev/null || true)
[ -n "$MOCK_ID" ] || die "updated mock container ID could not be resolved"
[ -n "$SERVER_ID" ] || die "updated server container ID could not be resolved"
BRIDGE_ID=""
NGINX_ID=""
if [ "$REQUIRE_BRIDGE" = 1 ]; then
    BRIDGE_ID=$(compose_patched ps -q "$BRIDGE_SERVICE" 2>/dev/null || true)
    NGINX_ID=$(compose_patched ps -q "$NGINX_SERVICE" 2>/dev/null || true)
    [ -n "$BRIDGE_ID" ] || die "updated bridge container ID could not be resolved"
    [ -n "$NGINX_ID" ] || die "updated Nginx container ID could not be resolved"
fi

# Record recreated container IDs before readiness checks. If a later health
# check fails, rollback.sh can identify only the containers from this run.
printf 'MOCK_CONTAINER_ID=%s\nSERVER_CONTAINER_ID=%s\nBRIDGE_CONTAINER_ID=%s\nNGINX_CONTAINER_ID=%s\n' \
    "$MOCK_ID" "$SERVER_ID" "$BRIDGE_ID" "$NGINX_ID" >> "$STATE_DIR/state.env"
printf '%s\n' "$STATE_DIR" > "$STATE_ROOT/latest"
chmod 600 "$STATE_ROOT/latest"

MOCK_STATUS=$(docker inspect -f '{{.State.Status}}' "$MOCK_ID" 2>/dev/null || true)
SERVER_STATUS=$(docker inspect -f '{{.State.Status}}' "$SERVER_ID" 2>/dev/null || true)
[ "$MOCK_STATUS" = running ] || die "mock container is not running (status=$MOCK_STATUS)"
[ "$SERVER_STATUS" = running ] || die "server container is not running (status=$SERVER_STATUS)"
if [ "$REQUIRE_BRIDGE" = 1 ]; then
    BRIDGE_STATUS=$(docker inspect -f '{{.State.Status}}' "$BRIDGE_ID" 2>/dev/null || true)
    NGINX_STATUS=$(docker inspect -f '{{.State.Status}}' "$NGINX_ID" 2>/dev/null || true)
    [ "$BRIDGE_STATUS" = running ] || die "bridge container is not running (status=$BRIDGE_STATUS)"
    [ "$NGINX_STATUS" = running ] || die "Nginx container is not running (status=$NGINX_STATUS)"
    BRIDGE_READY=0
    BRIDGE_ATTEMPT=1
    while [ "$BRIDGE_ATTEMPT" -le 30 ]; do
        if docker exec "$BRIDGE_ID" python3 -c 'import urllib.request; urllib.request.urlopen("http://127.0.0.1:18080/health", timeout=5).read()' >/dev/null 2>&1; then
            BRIDGE_READY=1
            break
        fi
        sleep 2
        BRIDGE_ATTEMPT=$((BRIDGE_ATTEMPT + 1))
    done
    [ "$BRIDGE_READY" -eq 1 ] || die "bridge health check failed"
    docker exec "$NGINX_ID" nginx -t >/dev/null 2>&1 || die "Nginx bridge image failed nginx -t"
fi

MOCK_LOCAL_ENV=$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$MOCK_ID" 2>/dev/null | grep '^MOCK_LOCAL_ONLY=' || true)
[ "$MOCK_LOCAL_ENV" = 'MOCK_LOCAL_ONLY=1' ] || die "updated mock does not expose MOCK_LOCAL_ONLY=1"

if [ "$REQUIRE_BRIDGE" = 1 ]; then
    REQUIRE_PROTOCOL=1
fi
if [ "$REQUIRE_PROTOCOL" = 1 ] || { [ "$REQUIRE_PROTOCOL" = auto ] && printf '%s\n' "$SERVICES" | grep -Fx 'yangjichang-b-bridge' >/dev/null 2>&1; }; then
    READY=0
    ATTEMPT=1
    while [ "$ATTEMPT" -le 30 ]; do
        PORTS=$(docker exec "$SERVER_ID" sh -c 'if command -v ss >/dev/null 2>&1; then ss -lnt; elif command -v netstat >/dev/null 2>&1; then netstat -lnt; else cat /proc/net/tcp /proc/net/tcp6 2>/dev/null || true; fi' 2>/dev/null || true)
        if printf '%s\n' "$PORTS" | grep -Eiq '(:8848|:2290)' && printf '%s\n' "$PORTS" | grep -Eiq '(:7006|:1b5e)'; then
            READY=1
            break
        fi
        sleep 2
        ATTEMPT=$((ATTEMPT + 1))
    done
    [ "$READY" -eq 1 ] || die "server A/B ports 8848/7006 are not listening; use rollback.sh and inspect protocol logs"
fi

MOCK_LOGS=$(docker logs --since 5m "$MOCK_ID" 2>&1 || true)
MOCK_COUNT=$(printf '%s\n' "$MOCK_LOGS" | grep -c 'MOCK kmlogon' || true)
REAL_COUNT=$(printf '%s\n' "$MOCK_LOGS" | grep -c 'REAL kmlogon' || true)
note "mock recent counters: MOCK=$MOCK_COUNT REAL=$REAL_COUNT"
[ "$REAL_COUNT" -eq 0 ] || die "mock attempted a real kmlogon upstream request"

# Install the already validated .env atomically, but only if it has not been
# edited since the preflight backup. This is the last host-level mutation.
if [ "$ORIGINAL_ENV_PRESENT" = 1 ]; then
    [ -f "$MANAGED_ENV_FILE" ] || die "the original .env disappeared during installation; run rollback.sh"
    CURRENT_ENV_SHA256=$(sha256_file "$MANAGED_ENV_FILE")
    [ "$CURRENT_ENV_SHA256" = "$ORIGINAL_ENV_SHA256" ] || die "the original .env changed during installation; run rollback.sh and merge manually"
else
    [ ! -e "$MANAGED_ENV_FILE" ] || die "a new .env appeared during installation; run rollback.sh and merge manually"
fi
ENV_INSTALL_TMP="$TARGET_DIR/.env.yjc-fix7-$STAMP.tmp"
[ ! -e "$ENV_INSTALL_TMP" ] || die "temporary environment path already exists: $ENV_INSTALL_TMP"
cp -p "$ENV_CANDIDATE" "$ENV_INSTALL_TMP"
chmod 600 "$ENV_INSTALL_TMP"
mv -f "$ENV_INSTALL_TMP" "$MANAGED_ENV_FILE"
INSTALLED_ENV_SHA256=$(sha256_file "$MANAGED_ENV_FILE")
printf 'INSTALLED_ENV_SHA256=%s\n' "$INSTALLED_ENV_SHA256" >> "$STATE_DIR/state.env"

PLAIN_CONFIG="$STATE_DIR/compose-plain-after-install.yml"
(
    unset COMPOSE_FILE COMPOSE_PATH_SEPARATOR COMPOSE_PROJECT_NAME
    unset YJC_LOCAL_AUTH_RUNTIME_HOST YJC_LOCAL_AUTH_MOCK_IMAGE YJC_LIGHT_ENTRYPOINT_HOST
    unset YJC_B_BINARY_HOST YJC_BRIDGE_CONTEXT YJC_NGINX_CONTEXT YJC_BRIDGE_ENV_HOST
    unset YJC_BRIDGE_IMAGE YJC_NGINX_IMAGE YJC_PYTHON_BASE_IMAGE YJC_NGINX_BASE_IMAGE
    cd "$TARGET_DIR"
    compose config
) > "$PLAIN_CONFIG" || die "installed .env does not support normal docker compose commands; run rollback.sh"
chmod 600 "$PLAIN_CONFIG"
cmp -s "$PERSISTENT_CONFIG" "$PLAIN_CONFIG" || die "normal docker compose config differs from the validated FIX7 config; run rollback.sh"
if [ "$REQUIRE_BRIDGE" = 1 ]; then
    grep -F "$BINARY_HOST" "$PLAIN_CONFIG" >/dev/null 2>&1 || die "normal docker compose config lost the verified B binary; run rollback.sh"
fi

printf 'STATUS=installed\nMOCK_CONTAINER_ID=%s\nSERVER_CONTAINER_ID=%s\nBRIDGE_CONTAINER_ID=%s\nNGINX_CONTAINER_ID=%s\nMOCK_COUNTER=%s\nREAL_COUNTER=%s\n' "$MOCK_ID" "$SERVER_ID" "$BRIDGE_ID" "$NGINX_ID" "$MOCK_COUNT" "$REAL_COUNT" >> "$STATE_DIR/state.env"
printf '%s\n' "$STATE_DIR" > "$STATE_ROOT/latest"
chmod 600 "$STATE_ROOT/latest"

note "upgrade complete; state recorded at $STATE_DIR"
note "normal 'cd $TARGET_DIR && docker compose up -d' now retains FIX7 layers"
note "persistent directories were not removed or recreated"
note "if business login still fails, do not repeat restarts; inspect welog.log/welog_B.log and run rollback.sh"
