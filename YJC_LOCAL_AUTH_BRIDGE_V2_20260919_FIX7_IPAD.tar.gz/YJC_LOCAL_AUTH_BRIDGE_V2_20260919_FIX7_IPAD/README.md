# YJC 通用增量升级 FIX7

这是已有养鸡场的增量升级包，不是新部署包。它一次安装以下三个部分：

1. FIX6 的 local-only Lovol mock，避免访问已经失效的外部验证上游；
2. FIX6 的 protocol-B bridge，提供上传步数和 WeRun 数据接口；
3. 已验证的 B 二进制，强制扫码身份为 `iPad iPadOS18.8.1`，并使用
   `ClientVersion=0x18004B22` 修复“当前客户端版本过低”。

包内 B 的固定 SHA256：

```text
a7e1204c7358f314548fb1b137375b01e7b769f4974d75d2c312ddacb84ca680
```

## 兼容状态

安装器按现有 Compose 的实际状态工作：

```text
从未安装 bridge   新增 bridge 和 Nginx 路由，并生成独立 token
已有 bridge/FIX4  升级为 FIX6 bridge，不再内置 192.168.1.21
已有 FIX6         保留本地认证和上传步数逻辑，升级 B 的 iPad 登录身份
已有 override     保留原文件，把 FIX7 作为最后一层 Compose 配置叠加
已有只读 B 挂载  按容器目标路径替换为本包的已验证 B
重复执行 FIX7     核对状态和 B 后直接退出，不叠加第二套配置
```

默认自动识别 `/opt/yangjichang` 或 `/root/yangjichang`。两者同时存在、
目录结构不是常规 YJC、或 `.env` 已有未托管的 `COMPOSE_FILE` 时会在修改
容器前停止，不会猜测或覆盖。

## 安全边界

安装器会备份 Compose、override、`.env`、旧镜像引用和容器清单。它不会：

```text
重建 MySQL 或 Redis
删除或初始化 mysql、redis、uploads、logs
覆盖已有 docker-compose.override.yml
执行 down、down -v、--remove-orphans、volume prune 或 system prune
复制其他服务器的机器码、AuthKey、token 或卡密
```

bridge 使用 Compose 服务名连接 server 和 MySQL，不使用宿主机局域网 IP。
已有 bridge 时会复用其数据库密码和 token；没有 bridge 时优先从正在运行的
MySQL 容器读取真实密码，并生成新的 bridge token。无法确认密码就停止。

## 一条命令升级

先把 `YJC_LOCAL_AUTH_BRIDGE_V2_20260919_FIX7_IPAD.tar.gz` 上传到 `/root`，
然后以 root 执行：

```sh
PKG=/root/YJC_LOCAL_AUTH_BRIDGE_V2_20260919_FIX7_IPAD.tar.gz; WORK=$(mktemp -d /opt/yjc-fix7.XXXXXX) && tar -xzf "$PKG" -C "$WORK" --strip-components=1 && cd "$WORK" && sh install.sh
```

养鸡场不在两个默认目录时，在最后改为：

```sh
YJC_TARGET_DIR=/实际/养鸡场目录 sh install.sh
```

建议第一次先预检。解压进入包目录后执行：

```sh
YJC_DRY_RUN=1 sh install.sh
```

dry-run 会生成审计和待安装 Compose 配置，不加载镜像、不重建容器、不改
目标 `.env`。正式安装成功后，安装器会在原 `.env` 末尾加入带边界标记的
FIX7 托管块。以后在养鸡场目录执行普通 `docker compose up -d`，仍会保留
local-auth、bridge、新版 B 和轻量 entrypoint，不会退回旧配置。

## 安装后验收

```sh
cd /opt/yangjichang  # 实际目录是 /root/yangjichang 时相应修改
docker compose config --quiet
docker compose ps
docker exec yangjichang-b-bridge python3 -c 'import urllib.request; print(urllib.request.urlopen("http://127.0.0.1:18080/health", timeout=5).read().decode())'
docker exec yangjichang-nginx nginx -t
docker logs --since 10m yangjichang-lovol-mock 2>&1 | grep -E 'MOCK kmlogon|REAL kmlogon'
```

目标状态：server、mock、bridge、Nginx 均为 running；server 内 8848 和 7006
持续监听；bridge health 与 Nginx 配置通过；mock 的 `REAL kmlogon` 为 0。
最后刷新网页生成全新二维码，再扫码登录。旧二维码不能用于验证升级结果。

HTTP 200 只能证明服务链可用，真实微信登录和账号步数提交仍需用有权限的账号
实际测试。

## 上传步数客户端配置

外部青龙插件必须显式填写当前养鸡场地址，不能继续使用 FIX4 的默认
`192.168.1.21`。例如：

```sh
WECHAT_SERVER=http://当前养鸡场IP:666/prod-api
WECHAT_TOKEN='Bearer 当前养鸡场token'
```

使用 `JJAPI`/`JJTOKEN` 的插件同理。bridge token 保存在本机最新状态目录的
`bridge.env` 中，权限为 600，不要发到聊天或写入公开升级包。

## 回滚

在本升级包解压目录执行：

```sh
sh rollback.sh
```

非默认目标目录：

```sh
YJC_TARGET_DIR=/实际/养鸡场目录 sh rollback.sh
```

回滚恢复安装前的 `.env`、原 Compose 组合和旧 mock 镜像引用，只重建受影响
服务。若原机器没有 bridge，只删除本次创建且容器 ID 仍匹配的 bridge/Nginx
容器。安装后若有人手工修改 `.env`，回滚会拒绝覆盖，须先保留并人工合并。

## 适用条件

```text
Linux x86_64 / amd64
已有可运行的 YangJiChang Compose 项目
已有 server、mock、MySQL、Redis 及 mysql/redis/uploads/logs 原目录
server 镜像内支持 main_linux_amd64 和 main_linux_amd64_B
mock 容器是 Python 3.11，且保留原 TLS 证书
构建 bridge/Nginx 所需的离线基础镜像仍在本机
```

若架构不是 amd64、数据库布局不同、持久化目录缺失、服务名完全自定义，或
基础镜像已清理，应先做专项适配；不要使用绕过变量掩盖预检失败。
