package handler

import (
	"net/http"

	"zhongqiu/internal/model"
)

// QueryWins 查询当前用户所有账号的中奖情况。
func (s *Server) QueryWins(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	list, err := s.store.ListWinsByUser(r.Context(), uid)
	if err != nil {
		fail(w, http.StatusInternalServerError, "查询失败")
		return
	}
	if list == nil {
		list = []model.WinRecord{}
	}
	ok(w, list)
}
