package handler

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"zhongqiu/internal/eventlog"
	"zhongqiu/internal/model"
	"zhongqiu/internal/store"
	"zhongqiu/internal/ysp"
)

// 自动续期参数
const (
	autoRefreshInterval  = 3 * time.Minute // 扫描间隔
	autoRefreshThreshold = 600             // 剩余 <=600s 触发续期
)

// refreshOne 调用协议续期并写回一个账号。返回新的剩余秒数。
func (s *Server) refreshOne(ctx context.Context, a *model.Account) (int64, error) {
	if a.RefreshToken == "" || a.VideoToken == "" || a.VUserID == "" || a.GUID == "" {
		return 0, errors.New("该账号缺少续期所需票据")
	}
	ec, msg, tk, err := s.ysp.RefreshCookie(ysp.RefreshInput{
		GUID:         a.GUID,
		OmgID:        a.OmgID,
		OpenID:       a.OpenID,
		AccessToken:  a.AccessToken,
		RefreshToken: a.RefreshToken,
		VUserID:      a.VUserID,
		VUSession:    a.VideoToken,
	})
	if err != nil {
		return 0, err
	}
	if ec != 0 {
		return 0, errors.New("续期被拒 errCode=" + strconv.FormatInt(ec, 10) + " " + msg)
	}
	openid := tk.OpenID
	if openid == "" {
		openid = a.OpenID
	}
	issued := time.Now().Unix()
	if err := s.store.UpdateAccountTokens(ctx, a.ID, openid, tk.AccessToken, tk.RefreshToken,
		tk.VideoToken, tk.Cookie, issued, tk.VideoTokenExpire); err != nil {
		return 0, err
	}
	eventlog.OK("续期", "账号 %s 续期成功，新有效期约 %d 分钟", maskPhoneView(a.Phone), tk.VideoTokenExpire/60)
	return tk.VideoTokenExpire, nil
}

// RefreshAccount 用户手动续期自己的某个账号。
func (s *Server) RefreshAccount(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	acc, err := s.store.GetAccountFull(r.Context(), id, uid)
	if err != nil {
		if errors.Is(err, store.ErrNotFound) {
			fail(w, http.StatusNotFound, "账号不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "查询失败")
		return
	}
	remaining, err := s.refreshOne(r.Context(), acc)
	if err != nil {
		fail(w, http.StatusBadGateway, "续期失败："+err.Error())
		return
	}
	ok(w, map[string]any{"refreshed": id, "token_remaining": remaining})
}

// autoRefreshLoop 后台定时续期：对剩余有效期不足的账号自动续期（对齐 App RefreshTickTask）。
func (s *Server) autoRefreshLoop() {
	// 启动后先等一小会儿，避开建库/首启动
	time.Sleep(30 * time.Second)
	t := time.NewTicker(autoRefreshInterval)
	defer t.Stop()
	for {
		s.autoRefreshOnce()
		<-t.C
	}
}

func (s *Server) autoRefreshOnce() {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	accs, err := s.store.ListAccountsForRefresh(ctx)
	if err != nil {
		slog.Warn("自动续期：查询失败", "err", err)
		return
	}
	now := time.Now().Unix()
	done, failed := 0, 0
	for i := range accs {
		a := &accs[i]
		remaining := int64(-1)
		if a.TokenIssuedAt > 0 && a.TokenExpire > 0 {
			remaining = a.TokenIssuedAt + a.TokenExpire - now
		}
		// 未知有效期或即将过期才续期
		if remaining >= 0 && remaining > autoRefreshThreshold {
			continue
		}
		if _, err := s.refreshOne(ctx, a); err != nil {
			failed++
			slog.Warn("自动续期失败", "account", a.ID, "err", err)
		} else {
			done++
		}
		time.Sleep(300 * time.Millisecond) // 轻微限速，避免风控
	}
	if done > 0 || failed > 0 {
		slog.Info("自动续期完成", "success", done, "failed", failed, "scanned", len(accs))
		eventlog.Info("续期", "自动续期完成：成功 %d，失败 %d", done, failed)
	}
}
