package handler

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"zhongqiu/internal/eventlog"
	"zhongqiu/internal/model"
	"zhongqiu/internal/store"
	"zhongqiu/internal/ysp"
)

type smsSendReq struct {
	Phone string `json:"phone"`
}

type smsLoginReq struct {
	SessionID string `json:"session_id"`
	Code      string `json:"code"`
	Remark    string `json:"remark"`
}

type manualAccountReq struct {
	Phone  string `json:"phone"`
	Cookie string `json:"cookie"`
	Remark string `json:"remark"`
}

// SMSSend 站内发送短信验证码：建设备→注册 guid→发码，返回会话 id。
func (s *Server) SMSSend(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	var req smsSendReq
	if !decodeJSON(w, r, &req) {
		return
	}
	phone := strings.TrimSpace(req.Phone)
	if !validPhone(phone) {
		fail(w, http.StatusBadRequest, "手机号需为 11 位数字")
		return
	}
	if !s.sendRate.allow(strconv.FormatInt(uid, 10)) {
		fail(w, http.StatusTooManyRequests, "发码过于频繁，请稍后再试")
		return
	}

	dev := ysp.NewDevice()
	ec, guid, err := s.ysp.RegisterGuid(dev)
	if err != nil {
		fail(w, http.StatusBadGateway, "设备注册失败："+err.Error())
		return
	}
	if ec != 0 || guid == "" {
		fail(w, http.StatusBadGateway, "设备注册被拒 errCode="+strconv.FormatInt(ec, 10))
		return
	}
	dev.GUID = guid

	ec, msg, err := s.ysp.GetCode(phone, dev)
	if err != nil {
		fail(w, http.StatusBadGateway, "发码失败："+err.Error())
		return
	}
	if ec != 0 {
		fail(w, http.StatusBadGateway, "发码被拒："+msg)
		return
	}

	sid := randID()
	s.sms.put(sid, &smsSession{phone: phone, userID: uid, device: dev})
	eventlog.Info("账号", "发送验证码到 %s", maskPhoneView(phone))
	ok(w, map[string]any{"session_id": sid, "message": "验证码已发送"})
}

// SMSLogin 用验证码完成登录并保存账号票据。
func (s *Server) SMSLogin(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	var req smsLoginReq
	if !decodeJSON(w, r, &req) {
		return
	}
	code := strings.TrimSpace(req.Code)
	if req.SessionID == "" || code == "" {
		fail(w, http.StatusBadRequest, "请填写验证码")
		return
	}
	sess, ok2 := s.sms.get(req.SessionID)
	if !ok2 || sess.userID != uid {
		fail(w, http.StatusBadRequest, "会话已过期，请重新发码")
		return
	}

	ec, msg, tokens, err := s.ysp.NewLogin(sess.phone, code, sess.device)
	if err != nil {
		fail(w, http.StatusBadGateway, "登录失败："+err.Error())
		return
	}
	if ec != 0 {
		fail(w, http.StatusBadRequest, "登录被拒："+msg)
		return
	}
	s.sms.del(req.SessionID)

	acc := &model.Account{
		UserID:       uid,
		Phone:        sess.phone,
		Nickname:     tokens.Nickname,
		GUID:         sess.device.GUID,
		DeviceID:     sess.device.DeviceID,
		OmgID:        sess.device.OmgID,
		OpenID:       tokens.OpenID,
		VUserID:      strconv.FormatInt(tokens.UserID, 10),
		AccessToken:  tokens.AccessToken,
		RefreshToken: tokens.RefreshToken,
		VideoToken:    tokens.VideoToken,
		Cookie:        tokens.Cookie,
		Status:        model.StatusActive,
		Remark:        strings.TrimSpace(req.Remark),
		TokenIssuedAt: time.Now().Unix(),
		TokenExpire:   tokens.VideoTokenExpire,
	}
	id, err := s.store.UpsertAccount(r.Context(), acc)
	if err != nil {
		fail(w, http.StatusInternalServerError, "保存账号失败")
		return
	}
	acc.ID = id
	eventlog.OK("账号", "%s 短信登录成功（%s）", maskPhoneView(sess.phone), tokens.Nickname)
	ok(w, acc.Masked())
}

// SubmitManual 手动提交账号（已有 cookie 的场景）。
func (s *Server) SubmitManual(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	var req manualAccountReq
	if !decodeJSON(w, r, &req) {
		return
	}
	phone := strings.TrimSpace(req.Phone)
	if !validPhone(phone) {
		fail(w, http.StatusBadRequest, "手机号需为 11 位数字")
		return
	}
	if strings.TrimSpace(req.Cookie) == "" {
		fail(w, http.StatusBadRequest, "请填写账号 Cookie")
		return
	}
	acc := &model.Account{
		UserID: uid,
		Phone:  phone,
		Cookie: strings.TrimSpace(req.Cookie),
		Status: model.StatusActive,
		Remark: strings.TrimSpace(req.Remark),
	}
	id, err := s.store.UpsertAccount(r.Context(), acc)
	if err != nil {
		fail(w, http.StatusInternalServerError, "保存账号失败")
		return
	}
	acc.ID = id
	eventlog.Info("账号", "手动提交账号 %s", maskPhoneView(phone))
	ok(w, acc.Masked())
}

// ListAccounts 列出当前用户的账号（脱敏）。
func (s *Server) ListAccounts(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	list, err := s.store.ListAccountsByUser(r.Context(), uid)
	if err != nil {
		fail(w, http.StatusInternalServerError, "查询失败")
		return
	}
	out := make([]map[string]any, 0, len(list))
	for _, a := range list {
		out = append(out, a.Masked())
	}
	ok(w, out)
}

// DeleteAccount 删除自己的账号。
func (s *Server) DeleteAccount(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	if err := s.store.DeleteAccount(r.Context(), id, uid); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			fail(w, http.StatusNotFound, "账号不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "删除失败")
		return
	}
	ok(w, map[string]any{"deleted": id})
}

type setRoundsReq struct {
	Rounds []int `json:"rounds"`
}

// SetRounds 设置当前用户某账号参与抢购的轮次（单选或多选）。
func (s *Server) SetRounds(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	var req setRoundsReq
	if !decodeJSON(w, r, &req) {
		return
	}
	// 校验轮次范围（1..8，足够覆盖活动轮次），去重
	seen := map[int]bool{}
	clean := make([]int, 0, len(req.Rounds))
	for _, n := range req.Rounds {
		if n < 1 || n > 8 {
			fail(w, http.StatusBadRequest, "轮次超出范围")
			return
		}
		if !seen[n] {
			seen[n] = true
			clean = append(clean, n)
		}
	}
	if len(clean) == 0 {
		fail(w, http.StatusBadRequest, "至少选择一轮")
		return
	}
	if err := s.store.SetAccountRounds(r.Context(), id, uid, model.RoundsToCSV(clean)); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			fail(w, http.StatusNotFound, "账号不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "更新失败")
		return
	}
	ok(w, map[string]any{"id": id, "rounds": clean})
}

func validPhone(p string) bool {
	if len(p) != 11 {
		return false
	}
	for _, r := range p {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

func randID() string {
	b := make([]byte, 18)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}
