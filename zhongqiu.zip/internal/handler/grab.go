package handler

import (
	"context"
	"net/http"
	"strconv"

	"zhongqiu/internal/eventlog"
	"zhongqiu/internal/grab"
	"zhongqiu/internal/model"
	"zhongqiu/internal/store"
)

// storeRecorder 让 store 满足 grab.Recorder 接口。
type storeRecorder struct{ st *store.Store }

func (r storeRecorder) RecordWin(ctx context.Context, accountID, campaignID int64, status, prize, detail string) error {
	return r.st.UpsertWin(ctx, &model.WinRecord{
		AccountID:  accountID,
		CampaignID: campaignID,
		Status:     status,
		Prize:      prize,
		Detail:     detail,
	})
}

func (r storeRecorder) SetCampaignStatus(ctx context.Context, campaignID int64, status string) error {
	return r.st.SetCampaignStatus(ctx, campaignID, status)
}

// StartGrab 启动某活动的抢购（管理员）。
func (s *Server) StartGrab(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	// 取活动配置
	camps, err := s.store.ListCampaigns(r.Context())
	if err != nil {
		fail(w, http.StatusInternalServerError, "读取活动失败")
		return
	}
	var camp *model.Campaign
	for i := range camps {
		if camps[i].ID == id {
			camp = &camps[i]
			break
		}
	}
	if camp == nil {
		fail(w, http.StatusNotFound, "活动不存在")
		return
	}
	cfg, err := grab.ParseConfig(camp.Config)
	if err != nil {
		fail(w, http.StatusBadRequest, "活动配置有误："+err.Error())
		return
	}
	// 取参与账号（带 cookie 的有效账号）
	accs, err := s.store.ListActiveAccountsWithCookie(r.Context())
	if err != nil {
		fail(w, http.StatusInternalServerError, "读取账号失败")
		return
	}
	list := make([]grab.Account, 0, len(accs))
	for _, a := range accs {
		list = append(list, grab.Account{
			ID:     a.ID,
			Name:   a.OwnerName + "/" + maskPhoneView(a.Phone),
			Cookie: a.Cookie,
			Rounds: a.GrabRounds,
		})
	}
	if err := s.grab.Start(id, camp.Name, cfg, list); err != nil {
		fail(w, http.StatusConflict, err.Error())
		return
	}
	_ = s.store.SetCampaignStatus(r.Context(), id, "running")
	eventlog.OK("抢购", "活动「%s」启动，参与账号 %d 个", camp.Name, len(list))
	ok(w, map[string]any{"started": id, "accounts": len(list)})
}

// TestAccount 用某账号的 cookie 打一次抢购接口，测试是否可正常抢购。
func (s *Server) TestAccount(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	acc, err := s.store.GetAccountFull(r.Context(), id, uid)
	if err != nil {
		if err == store.ErrNotFound {
			fail(w, http.StatusNotFound, "账号不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "查询失败")
		return
	}
	cookie := acc.Cookie
	if cookie == "" {
		fail(w, http.StatusBadRequest, "该账号没有 cookie，无法测试")
		return
	}
	cfg := grab.DefaultConfig() // 用当前活动（qw26）接口测试
	code, msg, err := s.grab.TestCookie(cfg, cookie)
	if err != nil {
		fail(w, http.StatusBadGateway, "测试请求失败："+err.Error())
		return
	}
	usable := code == cfg.SuccessCode
	eventlog.Info("测试", "账号 %s 抢购测试：%s（code=%d %s）", maskPhoneView(acc.Phone),
		map[bool]string{true: "可用", false: "不可用"}[usable], code, msg)
	ok(w, map[string]any{"usable": usable, "code": code, "msg": msg})
}

// StopGrab 停止某活动的抢购。
func (s *Server) StopGrab(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	if err := s.grab.Stop(id); err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	eventlog.Warn("抢购", "活动 #%d 收到停止指令", id)
	ok(w, map[string]any{"stopped": id})
}

// GrabStatus 查询某活动抢购实时状态。
func (s *Server) GrabStatus(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	st, running := s.grab.Status(id)
	if !running {
		ok(w, map[string]any{"exists": false})
		return
	}
	ok(w, map[string]any{"exists": true, "status": st})
}

// GrabTemplate 返回默认抢购配置模板（管理员填活动 config 用）。
func (s *Server) GrabTemplate(w http.ResponseWriter, r *http.Request) {
	ok(w, grab.DefaultConfig())
}

// maskPhoneView 复用脱敏（避免日志出现完整手机号）。
func maskPhoneView(p string) string {
	if len(p) == 11 {
		return p[:3] + "****" + p[7:]
	}
	return p
}
