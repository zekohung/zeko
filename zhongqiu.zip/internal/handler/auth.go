package handler

import (
	"errors"
	"net/http"
	"strings"

	"zhongqiu/internal/auth"
	"zhongqiu/internal/eventlog"
	"zhongqiu/internal/model"
	"zhongqiu/internal/store"
)

type registerReq struct {
	Username string `json:"username"`
	Password string `json:"password"`
	CardKey  string `json:"card_key"`
}

type loginReq struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// Register 卡密注册（普通用户）。
func (s *Server) Register(w http.ResponseWriter, r *http.Request) {
	var req registerReq
	if !decodeJSON(w, r, &req) {
		return
	}
	req.Username = strings.TrimSpace(req.Username)
	req.CardKey = strings.TrimSpace(req.CardKey)
	if !validUsername(req.Username) {
		fail(w, http.StatusBadRequest, "用户名需 3-32 位字母/数字/下划线")
		return
	}
	if len(req.Password) < 6 || len(req.Password) > 64 {
		fail(w, http.StatusBadRequest, "密码长度需 6-64 位")
		return
	}
	if req.CardKey == "" {
		fail(w, http.StatusBadRequest, "请填写卡密")
		return
	}
	hash, err := auth.HashPassword(req.Password)
	if err != nil {
		fail(w, http.StatusInternalServerError, "服务器繁忙")
		return
	}
	u, err := s.store.RegisterWithCardKey(r.Context(), req.Username, hash, req.CardKey)
	switch {
	case errors.Is(err, store.ErrCardInvalid):
		fail(w, http.StatusBadRequest, "卡密无效或已被使用")
		return
	case errors.Is(err, store.ErrDuplicate):
		fail(w, http.StatusConflict, "用户名已被占用")
		return
	case err != nil:
		fail(w, http.StatusInternalServerError, "注册失败")
		return
	}
	token, err := s.jwt.Issue(u.ID, u.Username, u.Role)
	if err != nil {
		fail(w, http.StatusInternalServerError, "签发凭证失败")
		return
	}
	eventlog.OK("用户", "新用户「%s」注册成功", u.Username)
	ok(w, map[string]any{"token": token, "user": userView(u)})
}

// Login 账号密码登录。
func (s *Server) Login(w http.ResponseWriter, r *http.Request) {
	var req loginReq
	if !decodeJSON(w, r, &req) {
		return
	}
	req.Username = strings.TrimSpace(req.Username)
	u, err := s.store.GetUserByUsername(r.Context(), req.Username)
	if err != nil || !auth.CheckPassword(u.PasswordHash, req.Password) {
		// 统一话术，避免用户名枚举
		fail(w, http.StatusUnauthorized, "用户名或密码错误")
		return
	}
	if u.Status != model.StatusActive {
		fail(w, http.StatusForbidden, "账号已被禁用")
		return
	}
	token, err := s.jwt.Issue(u.ID, u.Username, u.Role)
	if err != nil {
		fail(w, http.StatusInternalServerError, "签发凭证失败")
		return
	}
	eventlog.Info("登录", "%s（%s）登录", u.Username, roleName(u.Role))
	ok(w, map[string]any{"token": token, "user": userView(u)})
}

func roleName(role string) string {
	if role == model.RoleAdmin {
		return "管理员"
	}
	return "用户"
}

// Me 返回当前登录用户信息。
func (s *Server) Me(w http.ResponseWriter, r *http.Request) {
	uid := currentUserID(r)
	u, err := s.store.GetUserByID(r.Context(), uid)
	if err != nil {
		fail(w, http.StatusUnauthorized, "用户不存在")
		return
	}
	ok(w, userView(u))
}

func userView(u *model.User) map[string]any {
	return map[string]any{
		"id":         u.ID,
		"username":   u.Username,
		"role":       u.Role,
		"status":     u.Status,
		"created_at": u.CreatedAt,
	}
}

func validUsername(s string) bool {
	if len(s) < 3 || len(s) > 32 {
		return false
	}
	for _, r := range s {
		if !(r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '_') {
			return false
		}
	}
	return true
}
