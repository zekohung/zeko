package handler

import (
	"net/http"
	"strconv"

	"zhongqiu/internal/eventlog"
)

// Logs 返回全局实时日志（增量）。?since=<id> 只取该 id 之后的。
func (s *Server) Logs(w http.ResponseWriter, r *http.Request) {
	var since int64
	if v := r.URL.Query().Get("since"); v != "" {
		since, _ = strconv.ParseInt(v, 10, 64)
	}
	entries, last := eventlog.Since(since)
	ok(w, map[string]any{"entries": entries, "last_id": last})
}
