package handler

import (
	"crypto/rand"
	"errors"
	"net/http"
	"strconv"
	"strings"

	"zhongqiu/internal/model"
	"zhongqiu/internal/store"
)

// ---------------- 卡密 ----------------

type genCardsReq struct {
	Count int    `json:"count"`
	Note  string `json:"note"`
}

// GenCards 批量生成卡密。
func (s *Server) GenCards(w http.ResponseWriter, r *http.Request) {
	var req genCardsReq
	if !decodeJSON(w, r, &req) {
		return
	}
	if req.Count < 1 || req.Count > 500 {
		fail(w, http.StatusBadRequest, "数量需在 1-500 之间")
		return
	}
	codes := make([]string, 0, req.Count)
	for i := 0; i < req.Count; i++ {
		codes = append(codes, genCardCode())
	}
	if err := s.store.CreateCardKeys(r.Context(), codes, strings.TrimSpace(req.Note)); err != nil {
		fail(w, http.StatusInternalServerError, "生成卡密失败")
		return
	}
	ok(w, map[string]any{"count": len(codes), "codes": codes})
}

// ListCards 列出全部卡密。
func (s *Server) ListCards(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListCardKeys(r.Context())
	if err != nil {
		fail(w, http.StatusInternalServerError, "查询卡密失败")
		return
	}
	if list == nil {
		list = []model.CardKey{}
	}
	ok(w, list)
}

// DeleteCard 删除未使用卡密。
func (s *Server) DeleteCard(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	err = s.store.DeleteCardKey(r.Context(), id)
	switch {
	case errors.Is(err, store.ErrNotFound):
		fail(w, http.StatusNotFound, "卡密不存在")
	case errors.Is(err, store.ErrCardNotUnused):
		fail(w, http.StatusConflict, "卡密已被使用，不能删除")
	case err != nil:
		fail(w, http.StatusInternalServerError, "删除失败")
	default:
		ok(w, map[string]any{"deleted": id})
	}
}

// ---------------- 用户 ----------------

// ListUsers 列出全部用户。
func (s *Server) ListUsers(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListUsers(r.Context())
	if err != nil {
		fail(w, http.StatusInternalServerError, "查询用户失败")
		return
	}
	out := make([]map[string]any, 0, len(list))
	for i := range list {
		out = append(out, userView(&list[i]))
	}
	ok(w, out)
}

type userStatusReq struct {
	Status string `json:"status"`
}

// SetUserStatus 启用/禁用用户。
func (s *Server) SetUserStatus(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	var req userStatusReq
	if !decodeJSON(w, r, &req) {
		return
	}
	if req.Status != model.StatusActive && req.Status != model.StatusDisabled {
		fail(w, http.StatusBadRequest, "状态非法")
		return
	}
	// 不允许禁用自己，避免锁死后台
	if id == currentUserID(r) {
		fail(w, http.StatusBadRequest, "不能修改自己的状态")
		return
	}
	if err := s.store.SetUserStatus(r.Context(), id, req.Status); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			fail(w, http.StatusNotFound, "用户不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "更新失败")
		return
	}
	ok(w, map[string]any{"id": id, "status": req.Status})
}

// ---------------- 账号总览 ----------------

// ListAllAccounts 管理端账号总览（脱敏）。
func (s *Server) ListAllAccounts(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListAllAccounts(r.Context())
	if err != nil {
		fail(w, http.StatusInternalServerError, "查询账号失败")
		return
	}
	out := make([]map[string]any, 0, len(list))
	for _, a := range list {
		out = append(out, a.Masked())
	}
	ok(w, out)
}

// ---------------- 抢购活动（预留，执行逻辑外部接入） ----------------

type campaignReq struct {
	Name   string `json:"name"`
	Status string `json:"status"`
	Config string `json:"config"`
}

// ListCampaigns 列出抢购活动。
func (s *Server) ListCampaigns(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListCampaigns(r.Context())
	if err != nil {
		fail(w, http.StatusInternalServerError, "查询活动失败")
		return
	}
	if list == nil {
		list = []model.Campaign{}
	}
	ok(w, list)
}

// CreateCampaign 新建抢购活动。
func (s *Server) CreateCampaign(w http.ResponseWriter, r *http.Request) {
	var req campaignReq
	if !decodeJSON(w, r, &req) {
		return
	}
	if strings.TrimSpace(req.Name) == "" {
		fail(w, http.StatusBadRequest, "活动名不能为空")
		return
	}
	if req.Status == "" {
		req.Status = "draft"
	}
	c := &model.Campaign{Name: strings.TrimSpace(req.Name), Status: req.Status, Config: req.Config}
	id, err := s.store.CreateCampaign(r.Context(), c)
	if err != nil {
		fail(w, http.StatusInternalServerError, "创建活动失败")
		return
	}
	c.ID = id
	ok(w, c)
}

// UpdateCampaign 更新抢购活动。
func (s *Server) UpdateCampaign(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	var req campaignReq
	if !decodeJSON(w, r, &req) {
		return
	}
	c := &model.Campaign{ID: id, Name: strings.TrimSpace(req.Name), Status: req.Status, Config: req.Config}
	if err := s.store.UpdateCampaign(r.Context(), c); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			fail(w, http.StatusNotFound, "活动不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "更新失败")
		return
	}
	ok(w, c)
}

// DeleteCampaign 删除抢购活动。
func (s *Server) DeleteCampaign(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "参数错误")
		return
	}
	if err := s.store.DeleteCampaign(r.Context(), id); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			fail(w, http.StatusNotFound, "活动不存在")
			return
		}
		fail(w, http.StatusInternalServerError, "删除失败")
		return
	}
	ok(w, map[string]any{"deleted": id})
}

// ---------------- 中奖录入（供抢购程序回写 / 管理员手动录入） ----------------

type winReq struct {
	AccountID  int64  `json:"account_id"`
	CampaignID int64  `json:"campaign_id"`
	Status     string `json:"status"`
	Prize      string `json:"prize"`
	Detail     string `json:"detail"`
}

// UpsertWin 写入/更新某账号在某活动的中奖结果。
func (s *Server) UpsertWin(w http.ResponseWriter, r *http.Request) {
	var req winReq
	if !decodeJSON(w, r, &req) {
		return
	}
	if req.AccountID <= 0 || req.CampaignID <= 0 {
		fail(w, http.StatusBadRequest, "account_id / campaign_id 必填")
		return
	}
	switch req.Status {
	case model.WinPending, model.WinWon, model.WinLost:
	default:
		fail(w, http.StatusBadRequest, "状态非法（pending/won/lost）")
		return
	}
	rec := &model.WinRecord{
		AccountID:  req.AccountID,
		CampaignID: req.CampaignID,
		Status:     req.Status,
		Prize:      strings.TrimSpace(req.Prize),
		Detail:     strings.TrimSpace(req.Detail),
	}
	if err := s.store.UpsertWin(r.Context(), rec); err != nil {
		fail(w, http.StatusInternalServerError, "写入失败")
		return
	}
	ok(w, map[string]any{"account_id": req.AccountID, "campaign_id": req.CampaignID, "status": req.Status})
}

// genCardCode 生成形如 ZQ-XXXX-XXXX-XXXX 的卡密（无易混字符）。
func genCardCode() string {
	const charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b := make([]byte, 12)
	_, _ = rand.Read(b)
	var sb strings.Builder
	sb.WriteString("ZQ-")
	for i, v := range b {
		sb.WriteByte(charset[int(v)%len(charset)])
		if (i+1)%4 == 0 && i != len(b)-1 {
			sb.WriteByte('-')
		}
	}
	return sb.String()
}
