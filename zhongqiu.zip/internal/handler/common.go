// Package handler 提供 HTTP 接口层：入参校验、鉴权取值、调用 store/ysp、统一响应。
package handler

import (
	"encoding/json"
	"net/http"
	"sync"
	"time"

	"zhongqiu/internal/auth"
	"zhongqiu/internal/eventlog"
	"zhongqiu/internal/grab"
	"zhongqiu/internal/store"
	"zhongqiu/internal/ysp"
)

// Server 汇聚依赖并挂载路由。
type Server struct {
	store *store.Store
	jwt   *auth.Manager
	ysp   *ysp.Client
	grab  *grab.Engine

	sms      *smsSessions
	sendRate *rateLimiter
}

func NewServer(st *store.Store, jm *auth.Manager) *Server {
	s := &Server{
		store:    st,
		jwt:      jm,
		ysp:      ysp.NewClient(),
		grab:     grab.NewEngine(storeRecorder{st: st}),
		sms:      newSMSSessions(10 * time.Minute),
		sendRate: newRateLimiter(60*time.Second, 3), // 每用户 60s 内最多 3 次发码
	}
	go s.autoRefreshLoop() // 后台自动续期
	eventlog.Info("系统", "服务已启动")
	return s
}

// ---------- 统一 JSON 响应 ----------

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func ok(w http.ResponseWriter, v any) {
	writeJSON(w, http.StatusOK, map[string]any{"data": v})
}

func fail(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]any{"error": msg})
}

// decodeJSON 限制请求体大小并解析。
func decodeJSON(w http.ResponseWriter, r *http.Request, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20) // 1MB 上限
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		fail(w, http.StatusBadRequest, "请求格式错误")
		return false
	}
	return true
}

func currentUserID(r *http.Request) int64 {
	if c := auth.FromContext(r.Context()); c != nil {
		return c.UserID
	}
	return 0
}

// ---------- 短信登录会话（内存态，带 TTL） ----------

type smsSession struct {
	phone   string
	userID  int64
	device  *ysp.Device
	expires time.Time
}

type smsSessions struct {
	mu  sync.Mutex
	m   map[string]*smsSession
	ttl time.Duration
}

func newSMSSessions(ttl time.Duration) *smsSessions {
	s := &smsSessions{m: make(map[string]*smsSession), ttl: ttl}
	go s.gcLoop()
	return s
}

func (s *smsSessions) put(id string, sess *smsSession) {
	sess.expires = time.Now().Add(s.ttl)
	s.mu.Lock()
	s.m[id] = sess
	s.mu.Unlock()
}

func (s *smsSessions) get(id string) (*smsSession, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.m[id]
	if !ok || time.Now().After(sess.expires) {
		delete(s.m, id)
		return nil, false
	}
	return sess, true
}

func (s *smsSessions) del(id string) {
	s.mu.Lock()
	delete(s.m, id)
	s.mu.Unlock()
}

func (s *smsSessions) gcLoop() {
	t := time.NewTicker(2 * time.Minute)
	defer t.Stop()
	for range t.C {
		now := time.Now()
		s.mu.Lock()
		for id, sess := range s.m {
			if now.After(sess.expires) {
				delete(s.m, id)
			}
		}
		s.mu.Unlock()
	}
}

// ---------- 简单滑动窗口限流（按 key，如 userID） ----------

type rateLimiter struct {
	mu     sync.Mutex
	window time.Duration
	limit  int
	hits   map[string][]time.Time
}

func newRateLimiter(window time.Duration, limit int) *rateLimiter {
	return &rateLimiter{window: window, limit: limit, hits: make(map[string][]time.Time)}
}

// allow 返回是否放行；超限返回 false。
func (rl *rateLimiter) allow(key string) bool {
	now := time.Now()
	rl.mu.Lock()
	defer rl.mu.Unlock()
	cutoff := now.Add(-rl.window)
	kept := rl.hits[key][:0]
	for _, t := range rl.hits[key] {
		if t.After(cutoff) {
			kept = append(kept, t)
		}
	}
	if len(kept) >= rl.limit {
		rl.hits[key] = kept
		return false
	}
	rl.hits[key] = append(kept, now)
	return true
}
