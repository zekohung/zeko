package handler

import (
	"io/fs"
	"net/http"

	"zhongqiu/internal/auth"
)

// Routes 组装全部路由：/api 下为接口，其余交给前端静态资源。
func (s *Server) Routes(staticFS fs.FS) http.Handler {
	mux := http.NewServeMux()

	// 公开接口
	mux.HandleFunc("POST /api/auth/register", s.Register)
	mux.HandleFunc("POST /api/auth/login", s.Login)

	// 需登录
	authed := func(h http.HandlerFunc) http.Handler {
		return s.jwt.Middleware(h)
	}
	mux.Handle("GET /api/auth/me", authed(s.Me))
	mux.Handle("POST /api/accounts/sms/send", authed(s.SMSSend))
	mux.Handle("POST /api/accounts/sms/login", authed(s.SMSLogin))
	mux.Handle("POST /api/accounts", authed(s.SubmitManual))
	mux.Handle("GET /api/accounts", authed(s.ListAccounts))
	mux.Handle("POST /api/accounts/{id}/rounds", authed(s.SetRounds))
	mux.Handle("POST /api/accounts/{id}/refresh", authed(s.RefreshAccount))
	mux.Handle("POST /api/accounts/{id}/test", authed(s.TestAccount))
	mux.Handle("DELETE /api/accounts/{id}", authed(s.DeleteAccount))
	mux.Handle("GET /api/query/wins", authed(s.QueryWins))

	// 需管理员
	admin := func(h http.HandlerFunc) http.Handler {
		return s.jwt.Middleware(auth.RequireAdmin(h))
	}
	mux.Handle("POST /api/admin/cardkeys", admin(s.GenCards))
	mux.Handle("GET /api/admin/cardkeys", admin(s.ListCards))
	mux.Handle("DELETE /api/admin/cardkeys/{id}", admin(s.DeleteCard))
	mux.Handle("GET /api/admin/users", admin(s.ListUsers))
	mux.Handle("POST /api/admin/users/{id}/status", admin(s.SetUserStatus))
	mux.Handle("GET /api/admin/accounts", admin(s.ListAllAccounts))
	mux.Handle("GET /api/admin/campaigns", admin(s.ListCampaigns))
	mux.Handle("POST /api/admin/campaigns", admin(s.CreateCampaign))
	mux.Handle("PUT /api/admin/campaigns/{id}", admin(s.UpdateCampaign))
	mux.Handle("DELETE /api/admin/campaigns/{id}", admin(s.DeleteCampaign))
	mux.Handle("POST /api/admin/wins", admin(s.UpsertWin))

	// 实时日志（管理员）
	mux.Handle("GET /api/admin/logs", admin(s.Logs))

	// 抢购（管理员控制）
	mux.Handle("GET /api/admin/grab/template", admin(s.GrabTemplate))
	mux.Handle("POST /api/admin/campaigns/{id}/grab/start", admin(s.StartGrab))
	mux.Handle("POST /api/admin/campaigns/{id}/grab/stop", admin(s.StopGrab))
	mux.Handle("GET /api/admin/campaigns/{id}/grab/status", admin(s.GrabStatus))

	// 前端静态资源（含 index.html）
	mux.Handle("/", http.FileServerFS(staticFS))

	return securityHeaders(mux)
}

// securityHeaders 附加基础安全响应头。
func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		next.ServeHTTP(w, r)
	})
}
