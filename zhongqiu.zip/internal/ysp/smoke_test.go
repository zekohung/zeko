package ysp

import (
	"os"
	"testing"
)

// TestRegisterGuidLive 打通性验证：注册 guid（StGuidGet），不消耗短信。
// 仅在 ZQ_NET_TEST=1 时运行，避免离线 CI 失败。
func TestRegisterGuidLive(t *testing.T) {
	if os.Getenv("ZQ_NET_TEST") != "1" {
		t.Skip("设置 ZQ_NET_TEST=1 运行联网测试")
	}
	c := NewClient()
	dev := NewDevice()
	ec, guid, err := c.RegisterGuid(dev)
	if err != nil {
		t.Fatalf("请求失败: %v", err)
	}
	t.Logf("errCode=%d guid=%s", ec, guid)
	if ec != 0 || guid == "" {
		t.Fatalf("注册未成功 errCode=%d guid=%q", ec, guid)
	}
}
