// Package ysp 是央视频 JCE 协议（腾讯 TAF）的 Go 移植，
// 逐字节对齐已验证可用的 Python 版 央视频App登录.py。
// 仅实现短信登录链路所需：GetCode / NewLogin / StGuidGet，并预留 NewRefreshToken。
package ysp

import (
	"encoding/binary"
	"math"
	"unicode/utf8"
)

// JCE 类型标签
const (
	tByte    = 0
	tShort   = 1
	tInt     = 2
	tLong    = 3
	tFloat   = 4
	tDouble  = 5
	tString1 = 6
	tString4 = 7
	tMap     = 8
	tList    = 9
	tSBegin  = 10
	tSEnd    = 11
	tZero    = 12
	tSList   = 13
)

// JceWriter 增量写出 JCE 字节流。
type JceWriter struct {
	b []byte
}

func (w *JceWriter) head(t, tag int) {
	if tag < 15 {
		w.b = append(w.b, byte((tag<<4)|t))
	} else {
		w.b = append(w.b, byte(0xF0|t), byte(tag&0xFF))
	}
}

// WriteInt 按数值大小选择最小编码（对齐 Python write_int）。
func (w *JceWriter) WriteInt(tag int, v int64) {
	switch {
	case v == 0:
		w.head(tZero, tag)
	case v >= -128 && v <= 127:
		w.head(tByte, tag)
		w.b = append(w.b, byte(int8(v)))
	case v >= -32768 && v <= 32767:
		w.head(tShort, tag)
		w.b = binary.BigEndian.AppendUint16(w.b, uint16(int16(v)))
	case v >= -2147483648 && v <= 2147483647:
		w.head(tInt, tag)
		w.b = binary.BigEndian.AppendUint32(w.b, uint32(int32(v)))
	default:
		w.head(tLong, tag)
		w.b = binary.BigEndian.AppendUint64(w.b, uint64(v))
	}
}

// WriteString 写字符串（空串也写，len 0，与 Python 一致）。
func (w *JceWriter) WriteString(tag int, s string) {
	data := []byte(s)
	if len(data) <= 255 {
		w.head(tString1, tag)
		w.b = append(w.b, byte(len(data)))
	} else {
		w.head(tString4, tag)
		w.b = binary.BigEndian.AppendUint32(w.b, uint32(len(data)))
	}
	w.b = append(w.b, data...)
}

// WriteBytes 写 vector<byte>（SLIST）。
func (w *JceWriter) WriteBytes(tag int, data []byte) {
	w.head(tSList, tag)
	w.head(tByte, 0)
	w.WriteInt(0, int64(len(data)))
	w.b = append(w.b, data...)
}

func (w *JceWriter) StructBegin(tag int) { w.head(tSBegin, tag) }
func (w *JceWriter) StructEnd()          { w.head(tSEnd, 0) }
func (w *JceWriter) ListBegin(tag, size int) {
	w.head(tList, tag)
	w.WriteInt(0, int64(size))
}

// EmptyMapHead 只写一个空 map 的头字节（对齐 Python 顶层 tag2）。
func (w *JceWriter) EmptyMapHead(tag int) { w.head(tMap, tag) }

func (w *JceWriter) Bytes() []byte { return w.b }

// JceReader 容错解析 JCE 字节流。遇到非法数据以 panic 抛出，
// 由 parseTolerant 顶层 recover，行为对齐 Python 的 try/except break。
type JceReader struct {
	b []byte
	o int
}

func newReader(b []byte, o int) *JceReader { return &JceReader{b: b, o: o} }

func (r *JceReader) eof() bool { return r.o >= len(r.b) }

func (r *JceReader) u8() int {
	v := int(r.b[r.o])
	r.o++
	return v
}

func (r *JceReader) headRead() (t, tag int) {
	h := r.u8()
	t = h & 0x0F
	tag = (h >> 4) & 0x0F
	if tag == 15 {
		tag = r.u8()
	}
	return
}

func (r *JceReader) readInt(t int) int64 {
	switch t {
	case tZero:
		return 0
	case tByte:
		v := r.u8()
		if v >= 128 {
			return int64(v - 256)
		}
		return int64(v)
	case tShort:
		v := int64(int16(binary.BigEndian.Uint16(r.b[r.o:])))
		r.o += 2
		return v
	case tInt:
		v := int64(int32(binary.BigEndian.Uint32(r.b[r.o:])))
		r.o += 4
		return v
	case tLong:
		v := int64(binary.BigEndian.Uint64(r.b[r.o:]))
		r.o += 8
		return v
	}
	panic("jce: not int type")
}

func (r *JceReader) length() int {
	t, _ := r.headRead()
	return int(r.readInt(t))
}

func (r *JceReader) value(t int) any {
	switch t {
	case tByte, tShort, tInt, tLong, tZero:
		return r.readInt(t)
	case tFloat:
		v := math.Float32frombits(binary.BigEndian.Uint32(r.b[r.o:]))
		r.o += 4
		return v
	case tDouble:
		v := math.Float64frombits(binary.BigEndian.Uint64(r.b[r.o:]))
		r.o += 8
		return v
	case tString1:
		l := r.u8()
		s := decodeStr(r.b[r.o : r.o+l])
		r.o += l
		return s
	case tString4:
		l := int(binary.BigEndian.Uint32(r.b[r.o:]))
		r.o += 4
		s := decodeStr(r.b[r.o : r.o+l])
		r.o += l
		return s
	case tMap:
		n := r.length()
		d := make(map[any]any, n)
		for i := 0; i < n; i++ {
			kt, _ := r.headRead()
			k := r.value(kt)
			vt, _ := r.headRead()
			d[k] = r.value(vt)
		}
		return d
	case tList:
		n := r.length()
		out := make([]any, 0, n)
		for i := 0; i < n; i++ {
			et, _ := r.headRead()
			out = append(out, r.value(et))
		}
		return out
	case tSBegin:
		return r.structVal()
	case tSList:
		r.headRead()
		n := r.length()
		v := append([]byte(nil), r.b[r.o:r.o+n]...)
		r.o += n
		return v
	}
	panic("jce: bad type")
}

func (r *JceReader) structVal() map[int]any {
	out := map[int]any{}
	for !r.eof() {
		t, tag := r.headRead()
		if t == tSEnd {
			break
		}
		out[tag] = r.value(t)
	}
	return out
}

// parseTolerant 从 off 开始逐字段解析为 tag->value，遇非法数据即止（对齐 Python）。
func parseTolerant(b []byte, off int) map[int]any {
	r := newReader(b, off)
	out := map[int]any{}
	for !r.eof() {
		ok := func() (cont bool) {
			defer func() {
				if recover() != nil {
					cont = false
				}
			}()
			t, tag := r.headRead()
			if t == tSEnd {
				return true
			}
			out[tag] = r.value(t)
			return true
		}()
		if !ok {
			break
		}
	}
	return out
}

// decodeStr 优先 UTF-8，非法则返回原始字节（对齐 Python _dec）。
func decodeStr(bs []byte) any {
	if utf8.Valid(bs) {
		return string(bs)
	}
	return append([]byte(nil), bs...)
}
