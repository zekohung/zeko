package ysp

import (
	"bytes"
	"compress/gzip"
	"crypto/rand"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"net/url"
	"strconv"
	"sync"
	"time"
)

// 协议常量（对齐 Python）
const (
	Gateway      = "https://jacc.ysp.cctv.cn/"
	cmdGetCode   = 24680
	cmdNewLogin  = 59986
	cmdStGuidGet = 24865
	cmdNewRefresh = 59987 // 预留：Cookie 续期（NewRefreshToken，静态已还原，端到端未通过）
	getCodeAppID = "1400227916"
	headAppID    = "1200013"
)

var (
	outerA = []byte{0x00, 0x02, 0xff, 0x01}
	outerB = []byte{0x00, 0x00, 0x02, 0x13, 0x00, 0x00, 0x27, 0x1c}
	outerC = []byte{0x01, 0x00, 0x04, 0xa7, 0x7f}
)

// Device 一套独立设备身份。
type Device struct {
	GUID            string `json:"guid"`
	VersionName     string `json:"version_name"`
	VersionCode     string `json:"version_code"`
	Platform        int    `json:"platform"`
	PlatformVersion string `json:"platform_version"`
	MarkerID        int    `json:"marker_id"`
	NetworkMode     int    `json:"network_mode"`
	DensityDPI      int    `json:"density_dpi"`
	ChannelID       string `json:"channel_id"`
	DeviceModel     string `json:"device_model"`
	DeviceType      int    `json:"device_type"`
	WDevPlatType    int    `json:"w_dev_plat_type"`
	StrFromInfo     string `json:"str_from_info"`
	DeviceID        string `json:"device_id"`
	Qimei           string `json:"qimei"`
	OmgID           string `json:"omg_id"`
}

// NewDevice 生成一套全新独立设备身份（guid 待注册）。
func NewDevice() *Device {
	return &Device{
		VersionName: "3.5.2.26828", VersionCode: "305023",
		Platform: 3, PlatformVersion: "Xiaomi,37,17",
		MarkerID: 1, NetworkMode: 3, DensityDPI: 480,
		ChannelID: "10006", DeviceModel: "25102RKBEC", DeviceType: 1,
		WDevPlatType: 8, StrFromInfo: "Xiaomi,37,17",
		DeviceID: randHex(16), Qimei: randHex(36), OmgID: randHex(46),
	}
}

// Tokens 登录/续期返回的票据集合。
type Tokens struct {
	Nickname          string `json:"nickname"`
	Head              string `json:"head"`
	OpenID            string `json:"openid"`
	AccessToken       string `json:"access_token"`
	RefreshToken      string `json:"refresh_token"`
	AccessTokenExpire int64  `json:"access_token_expire"`
	UserID            int64  `json:"user_id"`
	VideoToken        string `json:"video_token"`
	VideoTokenExpire  int64  `json:"video_token_expire"`
	Cookie            string `json:"cookie"`
}

// Client 面向央视频网关的协议客户端。
type Client struct {
	http *http.Client
	mu   sync.Mutex
	seq  int
}

// NewClient 构造客户端。Go 默认走 HTTP/2（ALPN 协商），并自动处理传输层 gzip。
func NewClient() *Client {
	return &Client{
		http: &http.Client{Timeout: 20 * time.Second},
		seq:  80 + randInt(120),
	}
}

func (c *Client) nextSeq() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.seq++
	return c.seq
}

// ---------------- 帧封装 ----------------

// loginToken 是 RequestHead.token 列表元素（续期鉴权靠它）。
type loginToken struct {
	appID   string
	keyType int
	value   []byte
	uin     string
	isMain  bool
}

func (c *Client) buildInner(seq, cmdID int, dev *Device, clientKey string, fields func(*JceWriter), guid string, tokens []loginToken) []byte {
	sub := &JceWriter{}
	fields(sub)
	w := &JceWriter{}
	writeRequestHead(w, 0, seq, cmdID, dev, clientKey, guid, tokens)
	w.WriteBytes(1, sub.Bytes())
	w.EmptyMapHead(2) // 顶层 tag2 = 空 map（仅 1 字节头）
	return w.Bytes()
}

func packInner(jce []byte) []byte {
	out := []byte{0x26}
	out = appendU32(out, uint32(16+len(jce)))
	out = append(out, 0x01)
	out = append(out, make([]byte, 10)...)
	return append(out, jce...)
}

func packOuter(cmdID int, guid string, seq int, inner []byte) []byte {
	gz := gzipCompress(inner)
	body := []byte{0x13, 0x00, 0x00, 0x00, 0x00}
	body = append(body, outerA...)
	body = appendU16(body, uint16(cmdID))
	body = append(body, make([]byte, 8)...)
	body = appendU16(body, uint16(seq))
	body = append(body, outerB...)
	body = append(body, make([]byte, 8)...)
	g := []byte(guid)
	if len(g) > 32 {
		g = g[:32]
	}
	guidField := make([]byte, 32)
	copy(guidField, g)
	body = append(body, guidField...)
	body = append(body, outerC...)
	body = append(body, make([]byte, 13)...)
	body = appendU16(body, uint16(len(inner)))
	body = append(body, gz...)
	body = append(body, 0x03) // 帧尾 0x03（缺失网关 500）
	// 回填总长度
	total := uint32(len(body))
	body[1] = byte(total >> 24)
	body[2] = byte(total >> 16)
	body[3] = byte(total >> 8)
	body[4] = byte(total)
	return body
}

func (c *Client) post(cmdID int, body []byte, ck string) (map[int]any, error) {
	req, err := http.NewRequest(http.MethodPost, Gateway, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("构造请求: %w", err)
	}
	// Host 由 URL 决定；不手动设置 Accept-Encoding，交给 Go 自动加并解压（对齐 curl_cffi 效果）。
	req.Header.Set("request-id", ck)
	req.Header.Set("jcegodid", strconv.Itoa(cmdID))
	req.Header.Set("content-type", "application/octet-stream")
	req.Header.Set("user-agent", "okhttp/4.11.0")

	resp, err := c.http.Do(req)
	if err != nil {
		return nil, fmt.Errorf("请求网关: %w", err)
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("读取响应: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("网关拒绝 HTTP %d", resp.StatusCode)
	}
	top, err := parseTop(raw)
	if err != nil {
		return nil, err
	}
	if b1, ok := top[1].([]byte); ok {
		return parseTolerant(b1, 0), nil
	}
	return map[int]any{}, nil
}

func parseTop(raw []byte) (map[int]any, error) {
	i := bytes.Index(raw, []byte{0x1f, 0x8b, 0x08})
	if i < 0 {
		return nil, fmt.Errorf("响应无 gzip 段")
	}
	zr, err := gzip.NewReader(bytes.NewReader(raw[i:]))
	if err != nil {
		return nil, fmt.Errorf("解压响应: %w", err)
	}
	defer zr.Close()
	zr.Multistream(false) // 只读第一段，容忍帧尾残余
	data, err := io.ReadAll(zr)
	if err != nil && len(data) == 0 {
		return nil, fmt.Errorf("解压响应体: %w", err)
	}
	return parseTolerant(data, 16), nil
}

// ---------------- 业务结构编码 ----------------

func writeCoordinates(w *JceWriter, tag int) {
	w.StructBegin(tag)
	w.WriteInt(0, 0)
	w.head(tFloat, 1)
	w.b = appendU32(w.b, 0)
	w.head(tFloat, 2)
	w.b = appendU32(w.b, 0)
	w.head(tDouble, 3)
	w.b = appendU64(w.b, 0)
	w.StructEnd()
}

func writeExtentData(w *JceWriter, tag int) {
	w.StructBegin(tag)
	w.WriteInt(0, 0)
	w.WriteInt(1, 0)
	w.WriteString(2, "")
	w.StructEnd()
}

func writeQUA(w *JceWriter, tag int, dev *Device, clientKey string) {
	w.StructBegin(tag)
	w.WriteString(0, dev.VersionName)
	w.WriteString(1, dev.VersionCode)
	w.WriteInt(2, 0)
	w.WriteInt(3, 0)
	w.WriteInt(4, int64(dev.Platform))
	w.WriteString(5, dev.PlatformVersion)
	w.WriteInt(6, int64(dev.MarkerID))
	w.WriteInt(7, int64(dev.NetworkMode))
	w.WriteInt(8, int64(dev.DensityDPI))
	w.WriteString(9, dev.ChannelID)
	w.WriteString(10, "")
	w.WriteString(11, "")
	w.WriteString(12, "")
	w.WriteString(13, dev.OmgID)
	w.WriteString(14, "")
	writeExtentData(w, 15)
	w.WriteString(16, clientKey)
	w.WriteString(17, "")
	w.WriteString(18, "")
	writeCoordinates(w, 19)
	w.WriteString(20, dev.DeviceID)
	w.WriteString(21, dev.DeviceModel)
	w.WriteInt(22, int64(dev.DeviceType))
	w.WriteInt(23, 0)
	w.WriteInt(24, 0)
	w.WriteInt(25, 0)
	w.WriteInt(26, 0)
	w.WriteString(27, "")
	w.WriteString(28, "")
	w.WriteString(29, dev.Qimei)
	w.StructEnd()
}

func writeLogReport(w *JceWriter, tag int) {
	w.StructBegin(tag)
	w.WriteString(0, "page_login_phone")
	w.WriteString(1, "page_my")
	w.WriteInt(2, 5)
	w.WriteString(3, "self")
	w.WriteInt(4, 0)
	w.WriteString(5, "")
	w.WriteString(6, "")
	w.WriteString(7, "")
	w.WriteString(8, "10006")
	w.WriteString(9, "")
	w.WriteString(10, "")
	w.StructEnd()
}

func writeRequestHead(w *JceWriter, tag, seq, cmdID int, dev *Device, clientKey, guid string, tokens []loginToken) {
	w.StructBegin(tag)
	w.WriteInt(0, int64(seq))
	w.WriteInt(1, int64(cmdID))
	writeQUA(w, 2, dev, clientKey)
	w.WriteString(3, headAppID)
	w.WriteString(4, guid)
	// tag5 = token 列表：登录/发码为空；续期(59987)必须带 LoginToken 否则 errCode=1002
	if len(tokens) == 0 {
		w.ListBegin(5, 0)
	} else {
		w.ListBegin(5, len(tokens))
		for _, t := range tokens {
			w.StructBegin(0)
			w.WriteString(0, t.appID)
			w.WriteInt(1, int64(t.keyType))
			w.WriteBytes(2, t.value)
			w.WriteString(3, t.uin)
			if t.isMain {
				w.WriteInt(4, 1)
			} else {
				w.WriteInt(4, 0)
			}
			w.StructEnd()
		}
	}
	writeLogReport(w, 6)
	w.ListBegin(7, 0)
	w.WriteInt(8, 0)
	w.WriteInt(9, 0)
	w.WriteInt(10, 0)
	w.StructEnd()
}

func writeOauth(w *JceWriter, tag int, openid, code string) {
	w.StructBegin(tag)
	w.WriteString(0, "")
	w.WriteString(1, openid)
	w.WriteString(2, "")
	w.WriteString(3, "")
	w.WriteString(4, code)
	w.WriteInt(5, 0)
	w.StructEnd()
}

func writeStDevInfo(w *JceWriter, tag int, dev *Device) {
	w.StructBegin(tag)
	w.WriteInt(0, int64(dev.WDevPlatType))
	w.WriteString(1, "")
	w.WriteString(2, dev.GUID)
	w.WriteString(3, dev.DeviceID)
	w.WriteString(4, dev.StrFromInfo)
	w.StructEnd()
}

// ---------------- 对外三大请求 ----------------

// RegisterGuid 注册设备 guid（StGuidGet）。返回 errCode 与 guid。
func (c *Client) RegisterGuid(dev *Device) (int64, string, error) {
	ck := clientKey()
	seq := c.nextSeq()
	inner := packInner(c.buildInner(seq, cmdStGuidGet, dev, ck, func(w *JceWriter) {
		w.WriteInt(0, 1)
		w.WriteInt(1, 2)
		w.WriteInt(2, time.Now().Unix())
	}, dev.DeviceID, nil))
	biz, err := c.post(cmdStGuidGet, packOuter(cmdStGuidGet, dev.DeviceID, seq, inner), ck)
	if err != nil {
		return 0, "", err
	}
	return asInt(biz[0]), asStr(biz[2]), nil
}

// GetCode 发送短信验证码。返回 errorCode 与 errorMsg。
func (c *Client) GetCode(phone string, dev *Device) (int64, string, error) {
	pid := normalizePhone(phone)
	ck := clientKey()
	seq := c.nextSeq()
	inner := packInner(c.buildInner(seq, cmdGetCode, dev, ck, func(w *JceWriter) {
		w.WriteString(0, getCodeAppID)
		w.WriteString(1, pid)
		w.WriteString(2, "")
		w.WriteString(3, "ONE")
		w.WriteString(6, "86")
	}, dev.GUID, nil))
	biz, err := c.post(cmdGetCode, packOuter(cmdGetCode, dev.GUID, seq, inner), ck)
	if err != nil {
		return 0, "", err
	}
	return asInt(biz[0]), asStr(biz[1]), nil
}

// NewLogin 短信验证码登录。成功时返回带 Cookie 的票据。
func (c *Client) NewLogin(phone, code string, dev *Device) (int64, string, *Tokens, error) {
	pid := normalizePhone(phone)
	ck := clientKey()
	seq := c.nextSeq()
	inner := packInner(c.buildInner(seq, cmdNewLogin, dev, ck, func(w *JceWriter) {
		w.ListBegin(0, 1)
		w.StructBegin(0)
		w.WriteInt(0, 104)
		writeOauth(w, 1, pid, code)
		w.StructEnd()
		writeStDevInfo(w, 1, dev)
	}, dev.GUID, nil))
	biz, err := c.post(cmdNewLogin, packOuter(cmdNewLogin, dev.GUID, seq, inner), ck)
	if err != nil {
		return 0, "", nil, err
	}
	ec := asInt(biz[0])
	msg := asStr(biz[1])
	tokens := extractTokens(biz)
	if ec == 0 {
		tokens.Cookie = BuildCookie(dev, tokens, "[]")
	}
	return ec, msg, tokens, nil
}

// RefreshInput 续期所需的账号票据（来自 accounts 表）。
type RefreshInput struct {
	GUID         string
	OmgID        string
	OpenID       string
	AccessToken  string
	RefreshToken string
	VUserID      string // vuserid
	VUSession    string // vusession（= 内部 video_token）
}

// RefreshCookie 用 NewRefreshToken(59987) 续期。关键：RequestHead.token 携带
// LoginToken(keyType=9, value=vusession, uin=vuserid)，否则服务端返回 1002 checkInput failed。
// 成功返回新票据（含新 Cookie，沿用原 guid/omgId）。
func (c *Client) RefreshCookie(in RefreshInput) (int64, string, *Tokens, error) {
	if in.RefreshToken == "" || in.VUSession == "" || in.VUserID == "" {
		return 0, "", nil, fmt.Errorf("缺少 refresh_token / vusession / vuserid，无法续期")
	}
	dev := NewDevice()
	dev.GUID = in.GUID
	dev.DeviceID = in.GUID // 对齐 refresh_cookie.py：devid = guid
	if in.OmgID != "" {
		dev.OmgID = in.OmgID
	}
	openid := in.OpenID
	if openid == "" {
		openid = in.VUserID // 对齐 py：openid 缺失时回退 vuserid
	}
	tokens := []loginToken{{
		appID:   "",
		keyType: 9,
		value:   []byte(in.VUSession),
		uin:     in.VUserID,
		isMain:  true,
	}}

	ck := clientKey()
	seq := c.nextSeq()
	inner := packInner(c.buildInner(seq, cmdNewRefresh, dev, ck, func(w *JceWriter) {
		w.ListBegin(0, 1) // curLoginTokenList
		w.StructBegin(0)
		w.WriteInt(0, 104) // eTokenType
		w.StructBegin(1)   // OauthTokenInfo @ tag1
		w.WriteString(0, "")
		w.WriteString(1, openid)
		w.WriteString(2, in.AccessToken)
		w.WriteString(3, in.RefreshToken)
		w.WriteString(4, "")
		w.WriteInt(5, 0)
		w.StructEnd()
		w.StructEnd()
		writeStDevInfo(w, 1, dev) // stDevInfo @ tag1
	}, in.GUID, tokens))

	biz, err := c.post(cmdNewRefresh, packOuter(cmdNewRefresh, in.GUID, seq, inner), ck)
	if err != nil {
		return 0, "", nil, err
	}
	ec := asInt(biz[0])
	msg := asStr(biz[1])
	t := extractTokens(biz)
	if ec == 0 {
		// 续期沿用原设备身份重建 Cookie
		t.Cookie = BuildCookie(dev, t, "[]")
	}
	return ec, msg, t, nil
}

// ---------------- 票据 / Cookie ----------------

func extractTokens(biz map[int]any) *Tokens {
	t := &Tokens{}
	if uti, ok := biz[2].(map[int]any); ok {
		if user, ok := uti[0].(map[int]any); ok {
			t.Nickname = asStr(user[0])
			t.Head = asStr(user[1])
		}
		if oauth, ok := uti[1].(map[int]any); ok {
			t.OpenID = asStr(oauth[1])
			t.AccessToken = asStr(oauth[2])
			t.RefreshToken = asStr(oauth[3])
			t.AccessTokenExpire = asInt(oauth[5])
		}
	}
	if inner, ok := biz[3].(map[int]any); ok {
		t.UserID = asInt(inner[0])
		t.VideoToken = asStr(inner[1])
		t.VideoTokenExpire = asInt(inner[2])
	}
	return t
}

// BuildCookie 组装登录态 Cookie（对齐 App H5Utils.i()+AccountManager.f()，手机登录 logintype=5）。
func BuildCookie(dev *Device, t *Tokens, extentJSON string) string {
	if extentJSON == "" {
		extentJSON = "[]"
	}
	iPart := fmt.Sprintf("video_omgid=%s;guid=%s;", dev.OmgID, dev.GUID)
	fPart := fmt.Sprintf(
		"vuserid=%d;vusession=%s;access_token=%s;refresh_token=%s;logintype=5;_video_qq_version=1.0;vplatform=3;yspExtentAccountList=%s;guid=%s",
		t.UserID, t.VideoToken, t.AccessToken, t.RefreshToken, url.QueryEscape(extentJSON), dev.GUID)
	return iPart + fPart
}

// ---------------- 工具 ----------------

func normalizePhone(p string) string {
	if len(p) > 0 && p[0] == '+' {
		return p
	}
	return "+86" + p
}

func asStr(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

func asInt(v any) int64 {
	if n, ok := v.(int64); ok {
		return n
	}
	return 0
}

func gzipCompress(data []byte) []byte {
	var buf bytes.Buffer
	zw, _ := gzip.NewWriterLevel(&buf, gzip.BestCompression)
	zw.ModTime = time.Time{} // mtime=0，输出确定
	_, _ = zw.Write(data)
	_ = zw.Close()
	return buf.Bytes()
}

func appendU16(b []byte, v uint16) []byte { return append(b, byte(v>>8), byte(v)) }
func appendU32(b []byte, v uint32) []byte {
	return append(b, byte(v>>24), byte(v>>16), byte(v>>8), byte(v))
}
func appendU64(b []byte, v uint64) []byte {
	return append(b, byte(v>>56), byte(v>>48), byte(v>>40), byte(v>>32),
		byte(v>>24), byte(v>>16), byte(v>>8), byte(v))
}

const hexChars = "0123456789abcdef"

func randHex(n int) string {
	out := make([]byte, n)
	for i := range out {
		out[i] = hexChars[randInt(16)]
	}
	return string(out)
}

// clientKey 生成 14 位十进制随机串（对齐 Python _client_key）。
func clientKey() string {
	lo := int64(1e13)
	hi := int64(1e14 - 1)
	n, err := rand.Int(rand.Reader, big.NewInt(hi-lo+1))
	if err != nil {
		return strconv.FormatInt(lo, 10)
	}
	return strconv.FormatInt(lo+n.Int64(), 10)
}

func randInt(n int) int {
	v, err := rand.Int(rand.Reader, big.NewInt(int64(n)))
	if err != nil {
		return 0
	}
	return int(v.Int64())
}
