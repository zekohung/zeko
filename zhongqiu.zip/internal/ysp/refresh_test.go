package ysp

import (
	"os"
	"testing"
)

// TestRefreshStructLive 用（可能已过期的）样本票据验证续期请求的“结构”是否被服务端接受。
// 判据：修复前空 token 列表必得 errCode=1002 "checkInput failed"；
// 若本次返回非 1002（如 token 过期类错误），说明 LoginToken 结构修复生效。
// 需 ZQ_NET_TEST=1，并通过环境变量提供样本票据。
func TestRefreshStructLive(t *testing.T) {
	if os.Getenv("ZQ_NET_TEST") != "1" {
		t.Skip("设置 ZQ_NET_TEST=1 运行联网测试")
	}
	in := RefreshInput{
		GUID:         os.Getenv("RF_GUID"),
		OmgID:        os.Getenv("RF_OMGID"),
		OpenID:       os.Getenv("RF_OPENID"),
		AccessToken:  os.Getenv("RF_ACCESS"),
		RefreshToken: os.Getenv("RF_REFRESH"),
		VUserID:      os.Getenv("RF_VUSERID"),
		VUSession:    os.Getenv("RF_VUSESSION"),
	}
	if in.RefreshToken == "" {
		t.Skip("未提供 RF_* 样本票据")
	}
	c := NewClient()
	ec, msg, tok, err := c.RefreshCookie(in)
	if err != nil {
		t.Fatalf("请求失败: %v", err)
	}
	t.Logf("errCode=%d msg=%q", ec, msg)
	if tok != nil && ec == 0 {
		t.Logf("续期成功：新 vusession=%s 新 refresh=%s cookie=%s", tok.VideoToken, tok.RefreshToken, tok.Cookie)
	}
	if ec == 1002 {
		t.Fatalf("仍为 1002 checkInput failed —— 结构未修复")
	}
	t.Logf("✅ 非 1002：LoginToken 结构被接受（ec=%d 属业务层结果，如票据过期）", ec)
}
