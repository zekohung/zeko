// Package config 负责加载运行配置。所有敏感项优先从环境变量读取，
// 缺失时给出安全默认值（JWT 密钥缺失则自动生成并持久化到数据目录）。
package config

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
)

type Config struct {
	Addr          string // 监听地址，如 :24041
	DataDir       string // 数据目录（SQLite 文件、密钥文件）
	DBPath        string // SQLite 路径
	JWTSecret     []byte // JWT 签名密钥
	AdminUser     string // 初始管理员账号
	AdminPassword string // 初始管理员密码（仅首次建库时使用）
	TokenTTLHours int    // JWT 有效期（小时）
}

// Load 读取环境变量并组装配置。
func Load() (*Config, error) {
	c := &Config{
		Addr:          getenv("ZQ_ADDR", ":24041"),
		DataDir:       getenv("ZQ_DATA_DIR", "data"),
		AdminUser:     getenv("ZQ_ADMIN_USER", "admin"),
		AdminPassword: os.Getenv("ZQ_ADMIN_PASSWORD"),
		TokenTTLHours: getenvInt("ZQ_TOKEN_TTL_HOURS", 24),
	}
	if err := os.MkdirAll(c.DataDir, 0o750); err != nil {
		return nil, fmt.Errorf("创建数据目录: %w", err)
	}
	c.DBPath = filepath.Join(c.DataDir, "zhongqiu.db")

	secret, err := loadOrCreateSecret(c.DataDir)
	if err != nil {
		return nil, err
	}
	c.JWTSecret = secret
	return c, nil
}

// loadOrCreateSecret 优先用环境变量 ZQ_JWT_SECRET；否则在数据目录生成一份并复用。
func loadOrCreateSecret(dataDir string) ([]byte, error) {
	if s := os.Getenv("ZQ_JWT_SECRET"); s != "" {
		return []byte(s), nil
	}
	path := filepath.Join(dataDir, "jwt.secret")
	if b, err := os.ReadFile(path); err == nil && len(b) >= 32 {
		return b, nil
	}
	buf := make([]byte, 32)
	if _, err := rand.Read(buf); err != nil {
		return nil, fmt.Errorf("生成 JWT 密钥: %w", err)
	}
	secret := []byte(hex.EncodeToString(buf))
	if err := os.WriteFile(path, secret, 0o600); err != nil {
		return nil, fmt.Errorf("写入 JWT 密钥: %w", err)
	}
	return secret, nil
}

func getenv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func getenvInt(key string, def int) int {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return def
}
