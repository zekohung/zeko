// Package auth 提供密码哈希、JWT 签发校验与鉴权中间件。
package auth

import (
	"fmt"

	"golang.org/x/crypto/bcrypt"
)

// HashPassword 用 bcrypt 生成密码哈希。
func HashPassword(pw string) (string, error) {
	b, err := bcrypt.GenerateFromPassword([]byte(pw), bcrypt.DefaultCost)
	if err != nil {
		return "", fmt.Errorf("哈希密码: %w", err)
	}
	return string(b), nil
}

// CheckPassword 校验明文与哈希是否匹配。
func CheckPassword(hash, pw string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(pw)) == nil
}
