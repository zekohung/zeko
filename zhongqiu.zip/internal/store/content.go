package store

import (
	"context"
	"database/sql"
	"fmt"

	"zhongqiu/internal/model"
)

// ---------------- 账号 ----------------

// UpsertAccount 按 (user_id, phone) 新增或更新账号票据。
func (s *Store) UpsertAccount(ctx context.Context, a *model.Account) (int64, error) {
	// grab_rounds 仅在首次插入时给默认值；重复登录/提交不覆盖用户已选轮次。
	res, err := s.db.ExecContext(ctx, `
		INSERT INTO accounts(user_id, phone, nickname, guid, device_id, omg_id, openid, vuserid,
		                     access_token, refresh_token, video_token, cookie, status, remark, grab_rounds,
		                     token_issued_at, token_expire, updated_at)
		VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '1,2,3,4', ?, ?, CURRENT_TIMESTAMP)
		ON CONFLICT(user_id, phone) DO UPDATE SET
		    nickname=excluded.nickname, guid=excluded.guid, device_id=excluded.device_id,
		    omg_id=excluded.omg_id, openid=excluded.openid, vuserid=excluded.vuserid,
		    access_token=excluded.access_token, refresh_token=excluded.refresh_token,
		    video_token=excluded.video_token, cookie=excluded.cookie,
		    status=excluded.status, token_issued_at=excluded.token_issued_at,
		    token_expire=excluded.token_expire, updated_at=CURRENT_TIMESTAMP`,
		a.UserID, a.Phone, a.Nickname, a.GUID, a.DeviceID, a.OmgID, a.OpenID, a.VUserID,
		a.AccessToken, a.RefreshToken, a.VideoToken, a.Cookie, a.Status, a.Remark,
		a.TokenIssuedAt, a.TokenExpire)
	if err != nil {
		return 0, fmt.Errorf("保存账号: %w", err)
	}
	if id, _ := res.LastInsertId(); id > 0 {
		return id, nil
	}
	// 冲突更新时 LastInsertId 可能为 0，回查 id
	var id int64
	err = s.db.QueryRowContext(ctx, `SELECT id FROM accounts WHERE user_id = ? AND phone = ?`, a.UserID, a.Phone).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("回查账号 id: %w", err)
	}
	return id, nil
}

// ListAccountsByUser 列出某用户的账号。
func (s *Store) ListAccountsByUser(ctx context.Context, userID int64) ([]model.Account, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, user_id, phone, nickname, vuserid, video_token, status, remark, grab_rounds,
		       refresh_token, token_issued_at, token_expire, created_at, updated_at
		FROM accounts WHERE user_id = ? ORDER BY id DESC`, userID)
	if err != nil {
		return nil, fmt.Errorf("查询账号: %w", err)
	}
	defer rows.Close()
	return scanAccountList(rows, false)
}

// ListAllAccounts 管理端列出全部账号（含所属用户名）。
func (s *Store) ListAllAccounts(ctx context.Context) ([]model.Account, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT a.id, a.user_id, a.phone, a.nickname, a.vuserid, a.video_token, a.status, a.remark,
		       a.grab_rounds, a.refresh_token, a.token_issued_at, a.token_expire, a.created_at, a.updated_at, u.username
		FROM accounts a JOIN users u ON u.id = a.user_id ORDER BY a.id DESC`)
	if err != nil {
		return nil, fmt.Errorf("查询全部账号: %w", err)
	}
	defer rows.Close()
	return scanAccountList(rows, true)
}

// ListActiveAccountsWithCookie 取全部“正常且有 cookie”的账号（供抢购引擎使用）。
// 含完整 cookie，仅在服务端内部流转，不下发前端。
func (s *Store) ListActiveAccountsWithCookie(ctx context.Context) ([]model.Account, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT a.id, a.user_id, a.phone, a.cookie, a.grab_rounds, u.username
		FROM accounts a JOIN users u ON u.id = a.user_id
		WHERE a.status = 'active' AND a.cookie != '' ORDER BY a.id`)
	if err != nil {
		return nil, fmt.Errorf("查询抢购账号: %w", err)
	}
	defer rows.Close()
	var out []model.Account
	for rows.Next() {
		var a model.Account
		var owner, grabRounds sql.NullString
		if err := rows.Scan(&a.ID, &a.UserID, &a.Phone, &a.Cookie, &grabRounds, &owner); err != nil {
			return nil, fmt.Errorf("扫描抢购账号: %w", err)
		}
		a.GrabRounds = model.RoundsFromCSV(grabRounds.String)
		a.OwnerName = owner.String
		out = append(out, a)
	}
	return out, rows.Err()
}

// GetAccountForOwner 取账号（校验归属）。userID<=0 表示管理员不校验归属。
func (s *Store) GetAccountForOwner(ctx context.Context, id, userID int64) (*model.Account, error) {
	q := `SELECT id, user_id, phone, nickname, vuserid, video_token, status, remark, grab_rounds, refresh_token, token_issued_at, token_expire, created_at, updated_at FROM accounts WHERE id = ?`
	args := []any{id}
	if userID > 0 {
		q += ` AND user_id = ?`
		args = append(args, userID)
	}
	rows, err := s.db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("查询账号: %w", err)
	}
	defer rows.Close()
	list, err := scanAccountList(rows, false)
	if err != nil {
		return nil, err
	}
	if len(list) == 0 {
		return nil, ErrNotFound
	}
	return &list[0], nil
}

// UpdateAccountTokens 续期成功后写回新票据与新 Cookie。
func (s *Store) UpdateAccountTokens(ctx context.Context, id int64, openid, access, refresh, vusession, cookie string, issuedAt, expire int64) error {
	res, err := s.db.ExecContext(ctx, `
		UPDATE accounts SET openid=?, access_token=?, refresh_token=?, video_token=?, cookie=?,
		    token_issued_at=?, token_expire=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
		openid, access, refresh, vusession, cookie, issuedAt, expire, id)
	if err != nil {
		return fmt.Errorf("更新账号票据: %w", err)
	}
	return requireAffected(res)
}

// ListAccountsForRefresh 返回可续期的账号（有 refresh_token/vusession/vuserid/guid）及其票据。
func (s *Store) ListAccountsForRefresh(ctx context.Context) ([]model.Account, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, phone, guid, omg_id, openid, access_token, refresh_token, vuserid, video_token,
		       token_issued_at, token_expire
		FROM accounts
		WHERE status='active' AND refresh_token!='' AND video_token!='' AND vuserid!='' AND guid!=''
		ORDER BY id`)
	if err != nil {
		return nil, fmt.Errorf("查询可续期账号: %w", err)
	}
	defer rows.Close()
	var out []model.Account
	for rows.Next() {
		var (
			a                                              model.Account
			phone, guid, omg, openid, access, refresh, vuser sql.NullString
			vsession                                       sql.NullString
			issued, expire                                 sql.NullInt64
		)
		if err := rows.Scan(&a.ID, &phone, &guid, &omg, &openid, &access, &refresh, &vuser, &vsession, &issued, &expire); err != nil {
			return nil, fmt.Errorf("扫描可续期账号: %w", err)
		}
		a.Phone = phone.String
		a.GUID = guid.String
		a.OmgID = omg.String
		a.OpenID = openid.String
		a.AccessToken = access.String
		a.RefreshToken = refresh.String
		a.VUserID = vuser.String
		a.VideoToken = vsession.String
		a.TokenIssuedAt = issued.Int64
		a.TokenExpire = expire.Int64
		out = append(out, a)
	}
	return out, rows.Err()
}

// GetAccountFull 取账号全部票据字段（含 refresh 所需，校验归属）。
func (s *Store) GetAccountFull(ctx context.Context, id, userID int64) (*model.Account, error) {
	q := `SELECT id, user_id, phone, guid, omg_id, openid, access_token, refresh_token, vuserid, video_token,
	             cookie, token_issued_at, token_expire FROM accounts WHERE id=?`
	args := []any{id}
	if userID > 0 {
		q += ` AND user_id=?`
		args = append(args, userID)
	}
	var (
		a                                                model.Account
		phone, guid, omg, openid, access, refresh, vuser sql.NullString
		vsession, cookie                                 sql.NullString
		issued, expire                                   sql.NullInt64
	)
	err := s.db.QueryRowContext(ctx, q, args...).Scan(&a.ID, &a.UserID, &phone, &guid, &omg, &openid, &access, &refresh, &vuser, &vsession, &cookie, &issued, &expire)
	if err == sql.ErrNoRows {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("查询账号: %w", err)
	}
	a.Phone = phone.String
	a.Cookie = cookie.String
	a.GUID = guid.String
	a.OmgID = omg.String
	a.OpenID = openid.String
	a.AccessToken = access.String
	a.RefreshToken = refresh.String
	a.VUserID = vuser.String
	a.VideoToken = vsession.String
	a.TokenIssuedAt = issued.Int64
	a.TokenExpire = expire.Int64
	return &a, nil
}

// SetAccountRounds 设置某账号参与抢购的轮次（校验归属；userID<=0 为管理员）。
func (s *Store) SetAccountRounds(ctx context.Context, id, userID int64, csv string) error {
	q := `UPDATE accounts SET grab_rounds = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
	args := []any{csv, id}
	if userID > 0 {
		q += ` AND user_id = ?`
		args = append(args, userID)
	}
	res, err := s.db.ExecContext(ctx, q, args...)
	if err != nil {
		return fmt.Errorf("更新抢购轮次: %w", err)
	}
	return requireAffected(res)
}

// DeleteAccount 删除账号（校验归属；userID<=0 为管理员）。
func (s *Store) DeleteAccount(ctx context.Context, id, userID int64) error {
	q := `DELETE FROM accounts WHERE id = ?`
	args := []any{id}
	if userID > 0 {
		q += ` AND user_id = ?`
		args = append(args, userID)
	}
	res, err := s.db.ExecContext(ctx, q, args...)
	if err != nil {
		return fmt.Errorf("删除账号: %w", err)
	}
	return requireAffected(res)
}

func scanAccountList(rows *sql.Rows, withOwner bool) ([]model.Account, error) {
	var out []model.Account
	for rows.Next() {
		var (
			a                    model.Account
			nickname, remark     sql.NullString
			vuserid, videoToken  sql.NullString
			grabRounds, refresh  sql.NullString
			issued, expire       sql.NullInt64
			createdAt, updatedAt string
			owner                sql.NullString
		)
		dest := []any{&a.ID, &a.UserID, &a.Phone, &nickname, &vuserid, &videoToken, &a.Status, &remark, &grabRounds, &refresh, &issued, &expire, &createdAt, &updatedAt}
		if withOwner {
			dest = append(dest, &owner)
		}
		if err := rows.Scan(dest...); err != nil {
			return nil, fmt.Errorf("扫描账号: %w", err)
		}
		a.Nickname = nickname.String
		a.Remark = remark.String
		a.VUserID = vuserid.String
		a.VideoToken = videoToken.String
		a.GrabRounds = model.RoundsFromCSV(grabRounds.String)
		a.RefreshToken = refresh.String
		a.TokenIssuedAt = issued.Int64
		a.TokenExpire = expire.Int64
		a.OwnerName = owner.String
		a.CreatedAt = parseTime(createdAt)
		a.UpdatedAt = parseTime(updatedAt)
		out = append(out, a)
	}
	return out, rows.Err()
}

// ---------------- 抢购活动（管理员控制，执行逻辑外部接入） ----------------

func (s *Store) CreateCampaign(ctx context.Context, c *model.Campaign) (int64, error) {
	res, err := s.db.ExecContext(ctx,
		`INSERT INTO campaigns(name, status, config) VALUES(?, ?, ?)`,
		c.Name, c.Status, c.Config)
	if err != nil {
		return 0, fmt.Errorf("创建活动: %w", err)
	}
	id, _ := res.LastInsertId()
	return id, nil
}

func (s *Store) ListCampaigns(ctx context.Context) ([]model.Campaign, error) {
	rows, err := s.db.QueryContext(ctx,
		`SELECT id, name, status, config, created_at, updated_at FROM campaigns ORDER BY id DESC`)
	if err != nil {
		return nil, fmt.Errorf("查询活动: %w", err)
	}
	defer rows.Close()
	var out []model.Campaign
	for rows.Next() {
		var (
			c                    model.Campaign
			config               sql.NullString
			createdAt, updatedAt string
		)
		if err := rows.Scan(&c.ID, &c.Name, &c.Status, &config, &createdAt, &updatedAt); err != nil {
			return nil, fmt.Errorf("扫描活动: %w", err)
		}
		c.Config = config.String
		c.CreatedAt = parseTime(createdAt)
		c.UpdatedAt = parseTime(updatedAt)
		out = append(out, c)
	}
	return out, rows.Err()
}

// SetCampaignStatus 仅更新活动状态（供抢购引擎回写生命周期）。
func (s *Store) SetCampaignStatus(ctx context.Context, id int64, status string) error {
	res, err := s.db.ExecContext(ctx,
		`UPDATE campaigns SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, status, id)
	if err != nil {
		return fmt.Errorf("更新活动状态: %w", err)
	}
	return requireAffected(res)
}

func (s *Store) UpdateCampaign(ctx context.Context, c *model.Campaign) error {
	res, err := s.db.ExecContext(ctx,
		`UPDATE campaigns SET name = ?, status = ?, config = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
		c.Name, c.Status, c.Config, c.ID)
	if err != nil {
		return fmt.Errorf("更新活动: %w", err)
	}
	return requireAffected(res)
}

func (s *Store) DeleteCampaign(ctx context.Context, id int64) error {
	res, err := s.db.ExecContext(ctx, `DELETE FROM campaigns WHERE id = ?`, id)
	if err != nil {
		return fmt.Errorf("删除活动: %w", err)
	}
	return requireAffected(res)
}

// ---------------- 中奖记录 ----------------

// ListWinsByUser 查询某用户全部账号的中奖情况。
func (s *Store) ListWinsByUser(ctx context.Context, userID int64) ([]model.WinRecord, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT w.id, w.account_id, w.campaign_id, a.phone, c.name, w.status, w.prize, w.detail, w.checked_at, w.created_at
		FROM win_records w
		JOIN accounts a ON a.id = w.account_id
		JOIN campaigns c ON c.id = w.campaign_id
		WHERE a.user_id = ? ORDER BY w.id DESC`, userID)
	if err != nil {
		return nil, fmt.Errorf("查询中奖记录: %w", err)
	}
	defer rows.Close()
	return scanWins(rows)
}

// UpsertWin 管理端写入/更新某账号在某活动的中奖结果。
func (s *Store) UpsertWin(ctx context.Context, w *model.WinRecord) error {
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO win_records(account_id, campaign_id, status, prize, detail, checked_at)
		VALUES(?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
		ON CONFLICT(account_id, campaign_id) DO UPDATE SET
		    status=excluded.status, prize=excluded.prize, detail=excluded.detail, checked_at=CURRENT_TIMESTAMP`,
		w.AccountID, w.CampaignID, w.Status, w.Prize, w.Detail)
	if err != nil {
		return fmt.Errorf("写入中奖记录: %w", err)
	}
	return nil
}

func scanWins(rows *sql.Rows) ([]model.WinRecord, error) {
	var out []model.WinRecord
	for rows.Next() {
		var (
			w             model.WinRecord
			phone, camp   sql.NullString
			prize, detail sql.NullString
			checkedAt     sql.NullString
			createdAt     string
		)
		if err := rows.Scan(&w.ID, &w.AccountID, &w.CampaignID, &phone, &camp, &w.Status, &prize, &detail, &checkedAt, &createdAt); err != nil {
			return nil, fmt.Errorf("扫描中奖记录: %w", err)
		}
		w.Phone = maskPhone(phone.String)
		w.Campaign = camp.String
		w.Prize = prize.String
		w.Detail = detail.String
		if checkedAt.Valid {
			t := parseTime(checkedAt.String)
			w.CheckedAt = &t
		}
		w.CreatedAt = parseTime(createdAt)
		out = append(out, w)
	}
	return out, rows.Err()
}

func maskPhone(p string) string {
	if len(p) == 11 {
		return p[:3] + "****" + p[7:]
	}
	return p
}
