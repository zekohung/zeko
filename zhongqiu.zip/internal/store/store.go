// Package store 封装所有数据库读写。所有查询走 context，写操作按需事务化。
package store

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"zhongqiu/internal/model"
)

// 领域错误
var (
	ErrNotFound      = errors.New("记录不存在")
	ErrDuplicate     = errors.New("记录已存在")
	ErrCardInvalid   = errors.New("卡密无效或已被使用")
	ErrCardNotUnused = errors.New("卡密已被使用，无法删除")
)

// Store 是数据访问入口。
type Store struct {
	db *sql.DB
}

func New(db *sql.DB) *Store { return &Store{db: db} }

// ---------------- 用户 ----------------

// GetUserByUsername 按用户名查用户。
func (s *Store) GetUserByUsername(ctx context.Context, username string) (*model.User, error) {
	row := s.db.QueryRowContext(ctx,
		`SELECT id, username, password_hash, role, status, card_key, created_at FROM users WHERE username = ?`,
		username)
	return scanUser(row)
}

// GetUserByID 按 id 查用户。
func (s *Store) GetUserByID(ctx context.Context, id int64) (*model.User, error) {
	row := s.db.QueryRowContext(ctx,
		`SELECT id, username, password_hash, role, status, card_key, created_at FROM users WHERE id = ?`,
		id)
	return scanUser(row)
}

// ListUsers 列出全部用户（管理端）。
func (s *Store) ListUsers(ctx context.Context) ([]model.User, error) {
	rows, err := s.db.QueryContext(ctx,
		`SELECT id, username, password_hash, role, status, card_key, created_at FROM users ORDER BY id DESC`)
	if err != nil {
		return nil, fmt.Errorf("查询用户列表: %w", err)
	}
	defer rows.Close()
	var out []model.User
	for rows.Next() {
		u, err := scanUser(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *u)
	}
	return out, rows.Err()
}

// SetUserStatus 启用/禁用用户。
func (s *Store) SetUserStatus(ctx context.Context, id int64, status string) error {
	res, err := s.db.ExecContext(ctx, `UPDATE users SET status = ? WHERE id = ?`, status, id)
	if err != nil {
		return fmt.Errorf("更新用户状态: %w", err)
	}
	return requireAffected(res)
}

// CountAdmins 统计管理员数量（用于首次建库判断）。
func (s *Store) CountAdmins(ctx context.Context) (int, error) {
	var n int
	err := s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM users WHERE role = 'admin'`).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("统计管理员: %w", err)
	}
	return n, nil
}

// CreateAdmin 直接创建管理员（供首次初始化）。
func (s *Store) CreateAdmin(ctx context.Context, username, hash string) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO users(username, password_hash, role, status) VALUES(?, ?, 'admin', 'active')`,
		username, hash)
	if err != nil {
		return fmt.Errorf("创建管理员: %w", err)
	}
	return nil
}

// ---------------- 卡密 ----------------

// CreateCardKeys 批量插入卡密。
func (s *Store) CreateCardKeys(ctx context.Context, codes []string, note string) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("开启事务: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	stmt, err := tx.PrepareContext(ctx, `INSERT INTO card_keys(code, note) VALUES(?, ?)`)
	if err != nil {
		return fmt.Errorf("准备语句: %w", err)
	}
	defer stmt.Close()
	for _, code := range codes {
		if _, err := stmt.ExecContext(ctx, code, note); err != nil {
			return fmt.Errorf("插入卡密: %w", err)
		}
	}
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("提交事务: %w", err)
	}
	return nil
}

// ListCardKeys 列出卡密（含使用者用户名）。
func (s *Store) ListCardKeys(ctx context.Context) ([]model.CardKey, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT k.id, k.code, k.status, k.note, k.used_by, COALESCE(u.username, ''), k.created_at, k.used_at
		FROM card_keys k LEFT JOIN users u ON u.id = k.used_by
		ORDER BY k.id DESC`)
	if err != nil {
		return nil, fmt.Errorf("查询卡密: %w", err)
	}
	defer rows.Close()
	var out []model.CardKey
	for rows.Next() {
		var (
			k         model.CardKey
			usedBy    sql.NullInt64
			usedName  string
			createdAt string
			usedAt    sql.NullString
		)
		if err := rows.Scan(&k.ID, &k.Code, &k.Status, &k.Note, &usedBy, &usedName, &createdAt, &usedAt); err != nil {
			return nil, fmt.Errorf("扫描卡密: %w", err)
		}
		if usedBy.Valid {
			k.UsedBy = &usedBy.Int64
			k.UsedByName = usedName
		}
		k.CreatedAt = parseTime(createdAt)
		if usedAt.Valid {
			t := parseTime(usedAt.String)
			k.UsedAt = &t
		}
		out = append(out, k)
	}
	return out, rows.Err()
}

// DeleteCardKey 删除未使用的卡密。
func (s *Store) DeleteCardKey(ctx context.Context, id int64) error {
	var status string
	err := s.db.QueryRowContext(ctx, `SELECT status FROM card_keys WHERE id = ?`, id).Scan(&status)
	if errors.Is(err, sql.ErrNoRows) {
		return ErrNotFound
	}
	if err != nil {
		return fmt.Errorf("查卡密: %w", err)
	}
	if status != model.CardUnused {
		return ErrCardNotUnused
	}
	_, err = s.db.ExecContext(ctx, `DELETE FROM card_keys WHERE id = ?`, id)
	if err != nil {
		return fmt.Errorf("删除卡密: %w", err)
	}
	return nil
}

// RegisterWithCardKey 在一个事务里校验卡密、创建用户、标记卡密已用。
func (s *Store) RegisterWithCardKey(ctx context.Context, username, hash, code string) (*model.User, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, fmt.Errorf("开启事务: %w", err)
	}
	defer func() { _ = tx.Rollback() }()

	// 锁定并校验卡密
	var cardID int64
	var status string
	err = tx.QueryRowContext(ctx, `SELECT id, status FROM card_keys WHERE code = ?`, code).Scan(&cardID, &status)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrCardInvalid
	}
	if err != nil {
		return nil, fmt.Errorf("校验卡密: %w", err)
	}
	if status != model.CardUnused {
		return nil, ErrCardInvalid
	}

	// 用户名唯一
	var exists int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM users WHERE username = ?`, username).Scan(&exists); err != nil {
		return nil, fmt.Errorf("检查用户名: %w", err)
	}
	if exists > 0 {
		return nil, ErrDuplicate
	}

	res, err := tx.ExecContext(ctx,
		`INSERT INTO users(username, password_hash, role, status, card_key) VALUES(?, ?, 'user', 'active', ?)`,
		username, hash, code)
	if err != nil {
		return nil, fmt.Errorf("创建用户: %w", err)
	}
	uid, _ := res.LastInsertId()

	if _, err := tx.ExecContext(ctx,
		`UPDATE card_keys SET status = 'used', used_by = ?, used_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'unused'`,
		uid, cardID); err != nil {
		return nil, fmt.Errorf("标记卡密: %w", err)
	}

	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("提交事务: %w", err)
	}
	return &model.User{ID: uid, Username: username, Role: model.RoleUser, Status: model.StatusActive, CardKey: code}, nil
}

// ---------------- 辅助 ----------------

type scanner interface {
	Scan(dest ...any) error
}

func scanUser(sc scanner) (*model.User, error) {
	var (
		u         model.User
		cardKey   sql.NullString
		createdAt string
	)
	err := sc.Scan(&u.ID, &u.Username, &u.PasswordHash, &u.Role, &u.Status, &cardKey, &createdAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("扫描用户: %w", err)
	}
	u.CardKey = cardKey.String
	u.CreatedAt = parseTime(createdAt)
	return &u, nil
}

func requireAffected(res sql.Result) error {
	n, err := res.RowsAffected()
	if err != nil {
		return fmt.Errorf("影响行数: %w", err)
	}
	if n == 0 {
		return ErrNotFound
	}
	return nil
}

// parseTime 解析 SQLite 的时间文本（UTC）。
func parseTime(s string) time.Time {
	if s == "" {
		return time.Time{}
	}
	for _, layout := range []string{"2006-01-02 15:04:05", time.RFC3339, "2006-01-02T15:04:05Z"} {
		if t, err := time.Parse(layout, s); err == nil {
			return t.UTC()
		}
	}
	return time.Time{}
}
