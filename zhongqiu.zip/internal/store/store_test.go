package store

import (
	"context"
	"path/filepath"
	"testing"

	"zhongqiu/internal/db"
	"zhongqiu/internal/model"
)

// TestAccountTokenRoundTrip 验证账号票据/过期字段的写入、可续期列表、票据更新等 SQL。
func TestAccountTokenRoundTrip(t *testing.T) {
	dbPath := filepath.Join(t.TempDir(), "t.db")
	sqlDB, err := db.Open(dbPath)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	defer sqlDB.Close()
	st := New(sqlDB)
	ctx := context.Background()

	// 建卡密并注册用户
	if err := st.CreateCardKeys(ctx, []string{"K1"}, ""); err != nil {
		t.Fatalf("create card: %v", err)
	}
	usr, err := st.RegisterWithCardKey(ctx, "u1", "hash", "K1")
	if err != nil {
		t.Fatalf("register: %v", err)
	}
	u := usr.ID

	acc := &model.Account{
		UserID: u, Phone: "13800138000", GUID: "g1", OmgID: "o1", OpenID: "op1",
		VUserID: "111", AccessToken: "at", RefreshToken: "rt", VideoToken: "vt",
		Cookie: "c=1", Status: model.StatusActive, TokenIssuedAt: 1000, TokenExpire: 13800,
	}
	id, err := st.UpsertAccount(ctx, acc)
	if err != nil {
		t.Fatalf("upsert: %v", err)
	}

	// GetAccountFull
	full, err := st.GetAccountFull(ctx, id, u)
	if err != nil {
		t.Fatalf("getfull: %v", err)
	}
	if full.RefreshToken != "rt" || full.VideoToken != "vt" || full.VUserID != "111" ||
		full.GUID != "g1" || full.TokenExpire != 13800 {
		t.Fatalf("字段不匹配: %+v", full)
	}

	// 可续期列表应含该账号
	list, err := st.ListAccountsForRefresh(ctx)
	if err != nil {
		t.Fatalf("listrefresh: %v", err)
	}
	if len(list) != 1 || list[0].ID != id || list[0].RefreshToken != "rt" {
		t.Fatalf("可续期列表异常: %+v", list)
	}

	// 更新票据
	if err := st.UpdateAccountTokens(ctx, id, "op2", "at2", "rt2", "vt2", "c=2", 2000, 7200); err != nil {
		t.Fatalf("update tokens: %v", err)
	}
	full2, _ := st.GetAccountFull(ctx, id, u)
	if full2.VideoToken != "vt2" || full2.AccessToken != "at2" || full2.TokenExpire != 7200 || full2.TokenIssuedAt != 2000 {
		t.Fatalf("更新后字段不匹配: %+v", full2)
	}

	// 抢购轮次
	if err := st.SetAccountRounds(ctx, id, u, "2,4"); err != nil {
		t.Fatalf("set rounds: %v", err)
	}
	accs, _ := st.ListAccountsByUser(ctx, u)
	if len(accs) != 1 || model.RoundsToCSV(accs[0].GrabRounds) != "2,4" {
		t.Fatalf("轮次不匹配: %+v", accs)
	}
}
