-- 中秋央视频 数据库结构（SQLite）
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'user',
    status        TEXT NOT NULL DEFAULT 'active',
    card_key      TEXT DEFAULT '',
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS card_keys (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL UNIQUE,
    status     TEXT NOT NULL DEFAULT 'unused',
    note       TEXT DEFAULT '',
    used_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    used_at    DATETIME
);
CREATE INDEX IF NOT EXISTS idx_cardkeys_status ON card_keys(status);

CREATE TABLE IF NOT EXISTS accounts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    phone         TEXT NOT NULL,
    nickname      TEXT DEFAULT '',
    guid          TEXT DEFAULT '',
    device_id     TEXT DEFAULT '',
    omg_id        TEXT DEFAULT '',
    openid        TEXT DEFAULT '',
    vuserid       TEXT DEFAULT '',
    access_token  TEXT DEFAULT '',
    refresh_token TEXT DEFAULT '',
    video_token   TEXT DEFAULT '',
    cookie        TEXT DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'active',
    remark          TEXT DEFAULT '',
    grab_rounds     TEXT NOT NULL DEFAULT '1,2,3,4',
    token_issued_at INTEGER NOT NULL DEFAULT 0,
    token_expire    INTEGER NOT NULL DEFAULT 0,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, phone)
);
CREATE INDEX IF NOT EXISTS idx_accounts_user ON accounts(user_id);

CREATE TABLE IF NOT EXISTS campaigns (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'draft',
    config     TEXT DEFAULT '',
    start_at   DATETIME,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS win_records (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id  INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    status      TEXT NOT NULL DEFAULT 'pending',
    prize       TEXT DEFAULT '',
    detail      TEXT DEFAULT '',
    checked_at  DATETIME,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(account_id, campaign_id)
);
CREATE INDEX IF NOT EXISTS idx_wins_account ON win_records(account_id);
