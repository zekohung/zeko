// Package db 负责打开 SQLite 连接、建表与初始化管理员。
package db

import (
	"context"
	"database/sql"
	_ "embed"
	"fmt"
	"time"

	_ "modernc.org/sqlite" // 纯 Go 的 SQLite 驱动，无需 cgo
)

//go:embed schema.sql
var schema string

// Open 打开数据库并执行建表语句。
func Open(path string) (*sql.DB, error) {
	dsn := fmt.Sprintf("file:%s?_pragma=busy_timeout(5000)&_pragma=foreign_keys(1)", path)
	sqlDB, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, fmt.Errorf("打开数据库: %w", err)
	}
	// SQLite 写串行化，单连接避免 "database is locked"。
	sqlDB.SetMaxOpenConns(1)
	sqlDB.SetConnMaxLifetime(0)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := sqlDB.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("连接数据库: %w", err)
	}
	if _, err := sqlDB.ExecContext(ctx, schema); err != nil {
		return nil, fmt.Errorf("初始化表结构: %w", err)
	}
	migrate(ctx, sqlDB)
	return sqlDB, nil
}

// migrate 幂等补齐旧库缺失的列（SQLite 无 ADD COLUMN IF NOT EXISTS，重复执行报错则忽略）。
func migrate(ctx context.Context, sqlDB *sql.DB) {
	stmts := []string{
		`ALTER TABLE accounts ADD COLUMN grab_rounds TEXT NOT NULL DEFAULT '1,2,3,4'`,
		`ALTER TABLE accounts ADD COLUMN token_issued_at INTEGER NOT NULL DEFAULT 0`,
		`ALTER TABLE accounts ADD COLUMN token_expire INTEGER NOT NULL DEFAULT 0`,
	}
	for _, s := range stmts {
		_, _ = sqlDB.ExecContext(ctx, s) // 已存在则报 duplicate column，忽略
	}
}
