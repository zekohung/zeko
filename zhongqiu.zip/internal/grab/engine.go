package grab

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"zhongqiu/internal/eventlog"
)

// Account 参与抢购的账号（cookie 来自站内保存的登录态）。
type Account struct {
	ID     int64
	Name   string // 展示名（用户名/手机号），仅用于日志
	Cookie string
	Rounds []int // 用户选择参与的轮次(1..N)；空表示参与全部轮次
}

// allowsRound 判断账号是否参与某轮(1-based)。空 Rounds 视为全参与。
func (a Account) allowsRound(round int) bool {
	if len(a.Rounds) == 0 {
		return true
	}
	for _, r := range a.Rounds {
		if r == round {
			return true
		}
	}
	return false
}

// Recorder 抢购结果回写接口（由 store 实现）。
type Recorder interface {
	RecordWin(ctx context.Context, accountID, campaignID int64, status, prize, detail string) error
	SetCampaignStatus(ctx context.Context, campaignID int64, status string) error
}

// WonEntry 一条中奖记录（状态展示用）。
type WonEntry struct {
	AccountID int64  `json:"account_id"`
	Name      string `json:"name"`
	Prize     string `json:"prize"`
	Round     int    `json:"round"`
}

// Status 抢购任务实时状态快照。
type Status struct {
	Running   bool       `json:"running"`
	Round     int        `json:"round"`
	Accounts  int        `json:"accounts"`
	Attempts  int64      `json:"attempts"`
	Success   int64      `json:"success"`
	StartedAt time.Time  `json:"started_at"`
	Won       []WonEntry `json:"won"`
	Logs      []string   `json:"logs"`
}

// Engine 管理各活动的抢购任务。
type Engine struct {
	client *http.Client
	rec    Recorder
	mu     sync.Mutex
	jobs   map[int64]*job
}

// NewEngine 构造引擎，内置高并发连接池的 http.Client。
func NewEngine(rec Recorder) *Engine {
	tr := &http.Transport{
		MaxIdleConns:        1000,
		MaxIdleConnsPerHost: 500,
		MaxConnsPerHost:     0,
		IdleConnTimeout:     90 * time.Second,
		TLSHandshakeTimeout: 5 * time.Second,
	}
	return &Engine{
		client: &http.Client{Transport: tr}, // 逐请求用 context 控超时
		rec:    rec,
		jobs:   make(map[int64]*job),
	}
}

// Start 为某活动启动抢购任务（后台运行，立即返回）。已在运行则报错。
func (e *Engine) Start(campaignID int64, name string, cfg Config, accounts []Account) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if j, ok := e.jobs[campaignID]; ok && j.status().Running {
		return fmt.Errorf("该活动抢购已在运行")
	}
	if len(accounts) == 0 {
		return fmt.Errorf("没有可用账号（需存在带 cookie 的有效账号）")
	}
	ctx, cancel := context.WithCancel(context.Background())
	j := &job{
		engine:     e,
		campaignID: campaignID,
		name:       name,
		cfg:        cfg,
		accounts:   accounts,
		cancel:     cancel,
	}
	j.st.Running = true
	j.st.Accounts = len(accounts)
	j.st.StartedAt = time.Now()
	e.jobs[campaignID] = j
	go j.run(ctx)
	return nil
}

// TestCookie 用给定 cookie 打一次 prizes 接口，返回业务 code 与 msg，
// 用于测试该账号 cookie 能否正常发起抢购请求。code==SuccessCode 表示可用。
func (e *Engine) TestCookie(cfg Config, cookie string) (int, string, error) {
	if cookie == "" {
		return 0, "", fmt.Errorf("账号无 cookie")
	}
	u := "https://" + pick(cfg.PoolDomains) + cfg.APIBase + cfg.PrizesPath + "?act_id=" + cfg.ActID
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return 0, "", err
	}
	req.Header.Set("User-Agent", cfg.UserAgent)
	req.Header.Set("Accept", "application/json, text/plain, */*")
	req.Header.Set("Cache-Control", "no-cache")
	if cfg.Origin != "" {
		req.Header.Set("Origin", cfg.Origin)
	}
	if cfg.Referer != "" {
		req.Header.Set("Referer", cfg.Referer)
	}
	if cfg.XRequestedWith != "" {
		req.Header.Set("X-Requested-With", cfg.XRequestedWith)
	}
	req.Header.Set("Cookie", cookie)
	resp, err := e.client.Do(req)
	if err != nil {
		return 0, "", err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != 200 {
		return 0, "", fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	m := parseJSON(body)
	return toInt(m["code"]), toStr(m["msg"]), nil
}

// Stop 停止某活动的抢购任务。
func (e *Engine) Stop(campaignID int64) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	j, ok := e.jobs[campaignID]
	if !ok {
		return fmt.Errorf("该活动没有正在运行的抢购")
	}
	j.cancel()
	return nil
}

// Status 返回某活动的状态快照。
func (e *Engine) Status(campaignID int64) (Status, bool) {
	e.mu.Lock()
	j, ok := e.jobs[campaignID]
	e.mu.Unlock()
	if !ok {
		return Status{}, false
	}
	return j.status(), true
}

// ---------------- job ----------------

type job struct {
	engine     *Engine
	campaignID int64
	name       string
	cfg        Config
	accounts   []Account
	cancel     context.CancelFunc

	mu        sync.Mutex
	st        Status
	succeeded sync.Map // accountID -> struct{}
}

const maxLogs = 200

func (j *job) log(format string, args ...any) {
	line := time.Now().Format("15:04:05") + " " + fmt.Sprintf(format, args...)
	j.mu.Lock()
	j.st.Logs = append(j.st.Logs, line)
	if len(j.st.Logs) > maxLogs {
		j.st.Logs = j.st.Logs[len(j.st.Logs)-maxLogs:]
	}
	j.mu.Unlock()
}

// elog 写到本活动状态日志，同时推送到全局实时日志（里程碑事件用）。
func (j *job) elog(level, format string, args ...any) {
	msg := fmt.Sprintf(format, args...)
	j.log("%s", msg)
	eventlog.Emit(level, "抢购·"+j.name, msg)
}

func (j *job) status() Status {
	j.mu.Lock()
	defer j.mu.Unlock()
	s := j.st
	s.Attempts = atomic.LoadInt64(&j.st.Attempts)
	s.Success = atomic.LoadInt64(&j.st.Success)
	// 拷贝切片，避免外部读时并发修改
	s.Logs = append([]string(nil), j.st.Logs...)
	s.Won = append([]WonEntry(nil), j.st.Won...)
	return s
}

func (j *job) setRound(r int)    { j.mu.Lock(); j.st.Round = r; j.mu.Unlock() }
func (j *job) setRunning(v bool) { j.mu.Lock(); j.st.Running = v; j.mu.Unlock() }

func (j *job) run(ctx context.Context) {
	defer func() {
		j.setRunning(false)
		fctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = j.engine.rec.SetCampaignStatus(fctx, j.campaignID, "finished")
		cancel()
		j.elog(eventlog.LevelInfo, "抢购任务结束")
	}()

	j.elog(eventlog.LevelInfo, "抢购启动，账号数=%d，抢购并发=%d，扫描协程=%d，轮次=%d", len(j.accounts), j.cfg.Workers, j.cfg.ScanWorkers, j.cfg.Rounds)

	// 定时开始扫描
	if t, ok := j.cfg.ScanStartTime(); ok {
		j.log("将于 %s 开始扫描 pool（等待中）", t.Format("2006-01-02 15:04:05"))
		d := time.Until(t)
		select {
		case <-ctx.Done():
			j.log("等待期间已取消")
			return
		case <-time.After(d):
		}
		j.log("到达设定时间，开始扫描")
	}

	active := j.accounts
	if j.cfg.ValidateCK {
		active = j.validate(ctx)
		j.elog(eventlog.LevelInfo, "验号完成：有效 %d / 共 %d", len(active), len(j.accounts))
		if len(active) == 0 {
			j.log("无有效账号，结束")
			return
		}
	}

	for round := 0; round < j.cfg.Rounds; round++ {
		if ctx.Err() != nil {
			j.log("已取消，停止")
			return
		}
		j.setRound(round + 1)
		j.log("=== 第%d轮：监控活动开启 ===", round+1)
		poolID, finished := j.monitorPool(ctx, round)
		if ctx.Err() != nil {
			return
		}
		if finished {
			j.log("第%d轮已结束（跳过）", round+1)
			continue
		}
		if poolID == "" {
			j.log("第%d轮未获取到 pool_id", round+1)
			continue
		}
		j.elog(eventlog.LevelOK, "第%d轮开启（pool_id=%s），全员开抢", round+1, poolID)
		j.extreme(ctx, active, poolID, round+1)
	}
}

// validate 并发验号，返回有效账号。
func (j *job) validate(ctx context.Context) []Account {
	var (
		mu    sync.Mutex
		valid []Account
		wg    sync.WaitGroup
		sem   = make(chan struct{}, 20)
	)
	for _, a := range j.accounts {
		if ctx.Err() != nil {
			break
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(acc Account) {
			defer wg.Done()
			defer func() { <-sem }()
			if j.checkCK(ctx, acc) {
				mu.Lock()
				valid = append(valid, acc)
				mu.Unlock()
			}
		}(a)
	}
	wg.Wait()
	return valid
}

func (j *job) checkCK(ctx context.Context, acc Account) bool {
	u := j.url(pick(j.cfg.PoolDomains), j.cfg.PrizesPath, "")
	body, ok := j.doGet(ctx, u, acc.Cookie, 5*time.Second)
	if !ok {
		return false
	}
	m := parseJSON(body)
	return toInt(m["code"]) == j.cfg.SuccessCode
}

// monitorPool 用 ScanWorkers 个协程并发轮询，任一协程发现本轮开启即返回 pool_id；
// status==结束 返回 finished；取消/超时返回空。多协程可把 status→1 的检测延迟压到最小。
func (j *job) monitorPool(ctx context.Context, roundIndex int) (string, bool) {
	interval := time.Duration(j.cfg.PollIntervalMS) * time.Millisecond
	mctx, cancel := context.WithCancel(ctx)
	defer cancel()

	found := make(chan string, 1)
	fin := make(chan struct{}, 1)
	var once sync.Once
	var tries int64

	workers := j.cfg.ScanWorkers
	if workers < 1 {
		workers = 1
	}
	for w := 0; w < workers; w++ {
		go func(id int) {
			for {
				if mctx.Err() != nil {
					return
				}
				u := j.url(pick(j.cfg.PoolDomains), j.cfg.PoolPath, "")
				if body, ok := j.doGet(mctx, u, "", 2*time.Second); ok {
					m := parseJSON(body)
					if toInt(m["code"]) == j.cfg.SuccessCode {
						if pools := asSlice(dig(m, "data", "pools")); pools != nil && roundIndex < len(pools) {
							pd, _ := pools[roundIndex].(map[string]any)
							status := toInt(pd["status"])
							poolID := toStr(pd["pool_id"])
							if status == j.cfg.StatusOpen && poolID != "" {
								once.Do(func() { found <- poolID })
								return
							}
							if status == j.cfg.StatusFinished {
								once.Do(func() { fin <- struct{}{} })
								return
							}
						}
					}
				}
				if n := atomic.AddInt64(&tries, 1); id == 0 && n%250 == 0 {
					j.log("第%d轮扫描中…(累计%d次)", roundIndex+1, n)
				}
				select {
				case <-mctx.Done():
					return
				case <-time.After(interval):
				}
			}
		}(w)
	}

	var timeout <-chan time.Time
	if j.cfg.PollTimeoutSec > 0 {
		tm := time.NewTimer(time.Duration(j.cfg.PollTimeoutSec) * time.Second)
		defer tm.Stop()
		timeout = tm.C
	}
	select {
	case id := <-found:
		return id, false
	case <-fin:
		return "", true
	case <-timeout:
		j.log("第%d轮扫描超时", roundIndex+1)
		return "", false
	case <-ctx.Done():
		return "", false
	}
}

// extreme 极速抢购：账号×每号任务数，打乱后用固定并发数发射。
func (j *job) extreme(ctx context.Context, accounts []Account, poolID string, round int) {
	type task struct {
		acc   Account
		stagI int
	}
	var tasks []task
	joined := 0
	for _, a := range accounts {
		if _, done := j.succeeded.Load(a.ID); done {
			continue // 已中奖账号后续轮不再参与
		}
		if !a.allowsRound(round) {
			continue // 用户未勾选本轮
		}
		joined++
		for i := 0; i < j.cfg.TasksPerAccount; i++ {
			tasks = append(tasks, task{acc: a, stagI: i})
		}
	}
	if len(tasks) == 0 {
		j.log("第%d轮无参与账号（未勾选本轮或均已中）", round)
		return
	}
	j.log("第%d轮参与账号=%d", round, joined)
	rand.Shuffle(len(tasks), func(i, k int) { tasks[i], tasks[k] = tasks[k], tasks[i] })

	sem := make(chan struct{}, j.cfg.Workers)
	var wg sync.WaitGroup
	delay := time.Duration(j.cfg.RequestDelayMS) * time.Millisecond
	drawTO := time.Duration(j.cfg.DrawTimeoutMS) * time.Millisecond

	for _, t := range tasks {
		if ctx.Err() != nil {
			break
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(t task) {
			defer wg.Done()
			defer func() { <-sem }()
			if ctx.Err() != nil {
				return
			}
			if _, done := j.succeeded.Load(t.acc.ID); done {
				return
			}
			if delay > 0 && t.stagI > 0 {
				select {
				case <-ctx.Done():
					return
				case <-time.After(time.Duration(t.stagI) * delay):
				}
			}
			j.draw(ctx, t.acc, poolID, round, drawTO)
		}(t)
	}
	wg.Wait()
	j.log("第%d轮抢购结束", round)
}

func (j *job) draw(ctx context.Context, acc Account, poolID string, round int, timeout time.Duration) {
	if _, done := j.succeeded.Load(acc.ID); done {
		return
	}
	atomic.AddInt64(&j.st.Attempts, 1)
	u := j.url(pick(j.cfg.DrawDomains), j.cfg.DrawPath, "&pool_id="+poolID)
	body, ok := j.doGet(ctx, u, acc.Cookie, timeout)
	if !ok {
		return
	}
	m := parseJSON(body)
	if toInt(m["code"]) != j.cfg.SuccessCode {
		return
	}
	data, _ := m["data"].(map[string]any)
	if data == nil {
		return
	}
	// 首次成功才记录（LoadOrStore 保证原子）
	if _, loaded := j.succeeded.LoadOrStore(acc.ID, struct{}{}); loaded {
		return
	}
	atomic.AddInt64(&j.st.Success, 1)
	prize := toStr(dig(data, "prize", "prize_name"))
	if prize == "" {
		prize = "中奖"
	}
	j.mu.Lock()
	j.st.Won = append(j.st.Won, WonEntry{AccountID: acc.ID, Name: acc.Name, Prize: prize, Round: round})
	j.mu.Unlock()
	j.elog(eventlog.LevelOK, "🎉 %s 抢中：%s（第%d轮）", acc.Name, prize, round)

	rctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := j.engine.rec.RecordWin(rctx, acc.ID, j.campaignID, "won", prize, fmt.Sprintf("第%d轮", round)); err != nil {
		j.log("⚠️ 记录中奖失败 %s：%v", acc.Name, err)
	}
}

// url 拼接：https://{domain}{apibase}{path}?act_id={act}{extra}
func (j *job) url(domain, path, extra string) string {
	return "https://" + domain + j.cfg.APIBase + path + "?act_id=" + j.cfg.ActID + extra
}

func (j *job) doGet(ctx context.Context, url, cookie string, timeout time.Duration) ([]byte, bool) {
	rctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(rctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, false
	}
	req.Header.Set("User-Agent", j.cfg.UserAgent)
	req.Header.Set("Accept", "application/json, text/plain, */*")
	req.Header.Set("Cache-Control", "no-cache")
	if j.cfg.Origin != "" {
		req.Header.Set("Origin", j.cfg.Origin)
	}
	if j.cfg.Referer != "" {
		req.Header.Set("Referer", j.cfg.Referer)
	}
	if j.cfg.XRequestedWith != "" {
		req.Header.Set("X-Requested-With", j.cfg.XRequestedWith)
	}
	if cookie != "" {
		req.Header.Set("Cookie", cookie)
	}
	resp, err := j.engine.client.Do(req)
	if err != nil {
		return nil, false
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil || resp.StatusCode != http.StatusOK {
		return nil, false
	}
	return body, true
}

// ---------------- JSON 导航辅助 ----------------

func parseJSON(b []byte) map[string]any {
	var m map[string]any
	if json.Unmarshal(b, &m) != nil {
		return map[string]any{}
	}
	return m
}

func dig(m map[string]any, keys ...string) any {
	var cur any = m
	for _, k := range keys {
		cm, ok := cur.(map[string]any)
		if !ok {
			return nil
		}
		cur = cm[k]
	}
	return cur
}

func asSlice(v any) []any {
	s, _ := v.([]any)
	return s
}

func toInt(v any) int {
	switch n := v.(type) {
	case float64:
		return int(n)
	case int:
		return n
	case json.Number:
		i, _ := n.Int64()
		return int(i)
	}
	return 0
}

func toStr(v any) string {
	switch s := v.(type) {
	case string:
		return s
	case float64:
		return fmt.Sprintf("%v", s)
	}
	return ""
}

func pick(list []string) string {
	if len(list) == 0 {
		return ""
	}
	return list[rand.Intn(len(list))]
}
