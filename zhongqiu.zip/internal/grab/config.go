// Package grab 是配置驱动的央视频抢购引擎，逻辑对齐去年五粮液脚本：
// 验 ck → 轮询 pool 拿 pool_id → 并发打 draw → 记录中奖。
// 域名/路径/act_id/并发/轮次全部来自 campaign.config（JSON），便于每次活动只改配置。
package grab

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

// Config 抢购配置。缺省值对齐去年五粮液(cw26)，新活动通常只需改域名/路径/act_id。
type Config struct {
	APIBase     string   `json:"api_base"`     // 形如 ".yangshipin.cn/api/cw26/"
	ActID       string   `json:"act_id"`       // 活动 id，拼进 query
	PoolDomains []string `json:"pool_domains"` // 监控/验号用域名池
	DrawDomains []string `json:"draw_domains"` // 抢购用域名池
	PoolPath    string   `json:"pool_path"`    // 轮次查询路径
	DrawPath    string   `json:"draw_path"`    // 抽奖路径
	PrizesPath  string   `json:"prizes_path"`  // 验号/查奖路径

	Rounds          int    `json:"rounds"`            // 总轮次
	Workers         int    `json:"workers"`           // 抢购并发数（status→1 瞬间的爆发）
	TasksPerAccount int    `json:"tasks_per_account"` // 每账号请求数
	RequestDelayMS  int    `json:"request_delay_ms"`  // 单账号内阶梯延迟(ms)
	DrawTimeoutMS   int    `json:"draw_timeout_ms"`   // 抽奖请求超时(ms)
	ScanStartAt     string `json:"scan_start_at"`     // 几点开始扫描 pool（本地时间，空=立即）。支持 "2006-01-02 15:04:05" 或 "15:04"/"15:04:05"
	ScanWorkers     int    `json:"scan_workers"`      // 扫描 pool 的并发协程数（默认 5，配合 poll_interval 约 50 次/秒）
	PollIntervalMS  int    `json:"poll_interval_ms"`  // 每个扫描协程的轮询间隔(ms)
	PollTimeoutSec  int    `json:"poll_timeout_sec"`  // 单轮监控最长等待(s)，0=不限
	UserAgent       string `json:"user_agent"`
	Origin          string `json:"origin"`           // H5 请求头，防风控/CORS 校验
	Referer         string `json:"referer"`
	XRequestedWith  string `json:"x_requested_with"`
	ValidateCK      bool   `json:"validate_ck"` // 抢前是否验号

	// 响应语义（默认对齐 cw26；结构大改时再调解析代码）
	SuccessCode    int `json:"success_code"`
	StatusOpen     int `json:"status_open"`
	StatusFinished int `json:"status_finished"`
}

// apiDomains 返回 qw26 的 API 域名池 = 偶数 lottery02..lottery20。
// 抓包实证：St() 里 t=["02","04",...,"20"] 构造 /api/qw26/ base（pool/draw/my_prizes 均走此）；
// 奇数 lottery01/03.../19 是 COS 静态桶（/frontend、/backend），打 /api 会 404 NoSuchKey。
func apiDomains() []string {
	out := make([]string, 0, 10)
	for i := 2; i <= 20; i += 2 {
		out = append(out, fmt.Sprintf("lottery%02d", i))
	}
	return out
}

// DefaultConfig 返回 2026 中秋五粮液(qw26)默认配置，作为新活动模板。
// 依据 2026-09-25 抓包：域名 lottery01-20、base /api/qw26/、pool/draw/random/my/prizes、
// 状态 1=开抢 2=结束 3=未开始 4=已参与、Cookie 鉴权、H5 于 m.yangshipin.cn。
func DefaultConfig() Config {
	return Config{
		APIBase:     ".yangshipin.cn/api/qw26/",
		ActID:       "1",
		PoolDomains: apiDomains(),
		DrawDomains: apiDomains(),
		PoolPath:    "pool",
		DrawPath:    "draw/random",
		PrizesPath:  "my/prizes",

		Rounds:          4,
		Workers:         150,
		TasksPerAccount: 50,
		RequestDelayMS:  500,
		DrawTimeoutMS:   1500,
		ScanStartAt:     "",
		ScanWorkers:     5,
		PollIntervalMS:  100,
		PollTimeoutSec:  0,
		UserAgent:       "Mozilla/5.0 (Linux; Android 17; 25102RKBEC Build/CP2A.260605.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 yangshipin/v3.5.3.26910",
		Origin:         "https://m.yangshipin.cn",
		Referer:        "https://m.yangshipin.cn/",
		XRequestedWith: "com.cctv.yangshipin.app.androidp",
		ValidateCK:     true,

		SuccessCode:    1,
		StatusOpen:     1,
		StatusFinished: 2,
	}
}

// ParseConfig 从默认值出发合并用户 JSON（缺省项保留默认），并做安全钳制。
func ParseConfig(raw string) (Config, error) {
	cfg := DefaultConfig()
	raw = strings.TrimSpace(raw)
	if raw != "" {
		if err := json.Unmarshal([]byte(raw), &cfg); err != nil {
			return Config{}, fmt.Errorf("解析活动配置: %w", err)
		}
	}
	cfg.clamp()
	if err := cfg.validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

// clamp 限制参数在安全范围，避免误配导致资源打爆。
func (c *Config) clamp() {
	c.Rounds = clampInt(c.Rounds, 1, 20)
	c.Workers = clampInt(c.Workers, 1, 1000)
	c.ScanWorkers = clampInt(c.ScanWorkers, 1, 100)
	c.TasksPerAccount = clampInt(c.TasksPerAccount, 1, 500)
	c.RequestDelayMS = clampInt(c.RequestDelayMS, 0, 60000)
	c.DrawTimeoutMS = clampInt(c.DrawTimeoutMS, 200, 30000)
	c.PollIntervalMS = clampInt(c.PollIntervalMS, 50, 10000)
	c.PollTimeoutSec = clampInt(c.PollTimeoutSec, 0, 3600)
	if c.SuccessCode == 0 {
		c.SuccessCode = 1
	}
}

func (c *Config) validate() error {
	if !strings.Contains(c.APIBase, "/") {
		return fmt.Errorf("api_base 无效")
	}
	if len(c.PoolDomains) == 0 || len(c.DrawDomains) == 0 {
		return fmt.Errorf("pool_domains / draw_domains 不能为空")
	}
	if c.PoolPath == "" || c.DrawPath == "" {
		return fmt.Errorf("pool_path / draw_path 不能为空")
	}
	return nil
}

// ScanStartTime 解析开始扫描时间。返回 (时刻, 是否设置)。
// 支持完整日期时间与当天时钟；"15:04"/"15:04:05" 取当天，已过则视为立即（返回 ok=false）。
func (c Config) ScanStartTime() (time.Time, bool) {
	s := strings.TrimSpace(c.ScanStartAt)
	if s == "" {
		return time.Time{}, false
	}
	loc := time.Local
	for _, layout := range []string{"2006-01-02 15:04:05", "2006-01-02T15:04:05", "2006-01-02 15:04"} {
		if t, err := time.ParseInLocation(layout, s, loc); err == nil {
			return t, true
		}
	}
	now := time.Now()
	for _, layout := range []string{"15:04:05", "15:04"} {
		if t, err := time.ParseInLocation(layout, s, loc); err == nil {
			target := time.Date(now.Year(), now.Month(), now.Day(), t.Hour(), t.Minute(), t.Second(), 0, loc)
			if target.After(now) {
				return target, true
			}
			return time.Time{}, false // 当天时钟已过，立即开始
		}
	}
	return time.Time{}, false
}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
