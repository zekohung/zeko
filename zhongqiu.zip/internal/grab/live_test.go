package grab

import (
	"encoding/json"
	"io"
	"net/http"
	"os"
	"testing"
	"time"
)

// TestPoolLive 用默认(qw26)配置直连线上 pool 接口，验证域名/base/路径/解析正确。
// 仅在 ZQ_NET_TEST=1 时运行。pool 是公开接口，无需 cookie。
func TestPoolLive(t *testing.T) {
	if os.Getenv("ZQ_NET_TEST") != "1" {
		t.Skip("设置 ZQ_NET_TEST=1 运行联网测试")
	}
	cfg := DefaultConfig()
	domain := cfg.PoolDomains[0]
	url := "https://" + domain + cfg.APIBase + cfg.PoolPath + "?act_id=" + cfg.ActID
	t.Logf("GET %s", url)

	req, _ := http.NewRequest(http.MethodGet, url, nil)
	req.Header.Set("User-Agent", cfg.UserAgent)
	req.Header.Set("Origin", cfg.Origin)
	req.Header.Set("Referer", cfg.Referer)
	req.Header.Set("Accept", "application/json, text/plain, */*")

	resp, err := (&http.Client{Timeout: 8 * time.Second}).Do(req)
	if err != nil {
		t.Fatalf("请求失败: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	t.Logf("HTTP %d, body=%s", resp.StatusCode, string(body))

	var m map[string]any
	if err := json.Unmarshal(body, &m); err != nil {
		t.Fatalf("响应非 JSON: %v", err)
	}
	if toInt(m["code"]) != cfg.SuccessCode {
		t.Fatalf("code != %d，实际=%v", cfg.SuccessCode, m["code"])
	}
	pools := asSlice(dig(m, "data", "pools"))
	if len(pools) == 0 {
		t.Fatalf("未解析到 pools")
	}
	t.Logf("✅ code=1，pools 轮数=%d（当前应为未开始 status=3）", len(pools))
	for i, p := range pools {
		if pm, ok := p.(map[string]any); ok {
			t.Logf("  第%d轮 status=%v pool_id=%v", i+1, pm["status"], pm["pool_id"])
		}
	}
}
