// Package model 定义领域实体与它们的 JSON 序列化形态。
// 敏感字段（密码哈希、完整 token）不直接对用户端序列化。
package model

import (
	"sort"
	"strconv"
	"strings"
	"time"
)

// 角色常量
const (
	RoleUser  = "user"
	RoleAdmin = "admin"
)

// 通用状态
const (
	StatusActive   = "active"
	StatusDisabled = "disabled"
)

// 卡密状态
const (
	CardUnused = "unused"
	CardUsed   = "used"
)

// 中奖记录状态
const (
	WinPending = "pending" // 待开奖 / 未查询
	WinWon     = "won"     // 已中奖
	WinLost    = "lost"    // 未中奖
)

// User 网站用户（含管理员）。
type User struct {
	ID           int64     `json:"id"`
	Username     string    `json:"username"`
	PasswordHash string    `json:"-"`
	Role         string    `json:"role"`
	Status       string    `json:"status"`
	CardKey      string    `json:"card_key,omitempty"`
	CreatedAt    time.Time `json:"created_at"`
}

// CardKey 注册卡密，由管理员生成。
type CardKey struct {
	ID        int64      `json:"id"`
	Code      string     `json:"code"`
	Status    string     `json:"status"`
	Note      string     `json:"note,omitempty"`
	UsedBy    *int64     `json:"used_by,omitempty"`
	UsedByName string    `json:"used_by_name,omitempty"`
	CreatedAt time.Time  `json:"created_at"`
	UsedAt    *time.Time `json:"used_at,omitempty"`
}

// Account 用户提交的央视频账号（短信登录得到的票据）。
type Account struct {
	ID           int64     `json:"id"`
	UserID       int64     `json:"user_id"`
	OwnerName    string    `json:"owner_name,omitempty"` // 仅管理员总览时填充
	Phone        string    `json:"phone"`
	Nickname     string    `json:"nickname,omitempty"`
	GUID         string    `json:"guid,omitempty"`
	DeviceID     string    `json:"device_id,omitempty"`
	OmgID        string    `json:"omg_id,omitempty"`
	OpenID       string    `json:"openid,omitempty"`
	VUserID      string    `json:"vuserid,omitempty"`
	AccessToken  string    `json:"-"`
	RefreshToken string    `json:"-"`
	VideoToken   string    `json:"-"`
	Cookie       string    `json:"-"` // 完整 cookie 不下发给普通前端展示
	Status       string    `json:"status"`
	Remark        string   `json:"remark,omitempty"`
	GrabRounds    []int    `json:"grab_rounds"` // 用户选择参与抢购的轮次（1..N）
	TokenIssuedAt int64    `json:"-"`           // 票据签发/续期时间(unix)
	TokenExpire   int64    `json:"-"`           // 票据有效时长(秒，取 video_token)
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

// TokenRemaining 返回票据剩余秒数；无有效期信息返回 -1。
func (a Account) TokenRemaining() int64 {
	if a.TokenIssuedAt <= 0 || a.TokenExpire <= 0 {
		return -1
	}
	return a.TokenIssuedAt + a.TokenExpire - time.Now().Unix()
}

// Masked 返回可安全下发到前端的账号视图（隐藏完整 token / cookie）。
func (a Account) Masked() map[string]any {
	return map[string]any{
		"id":         a.ID,
		"user_id":    a.UserID,
		"owner_name": a.OwnerName,
		"phone":      maskPhone(a.Phone),
		"nickname":   a.Nickname,
		"vuserid":    a.VUserID,
		"status":      a.Status,
		"remark":      a.Remark,
		"grab_rounds": a.GrabRounds,
		"has_token":   a.VideoToken != "",
		"can_refresh": a.RefreshToken != "" && a.VideoToken != "" && a.VUserID != "",
		"token_remaining": a.TokenRemaining(),
		"created_at":  a.CreatedAt,
		"updated_at":  a.UpdatedAt,
	}
}

func maskPhone(p string) string {
	if len(p) == 11 {
		return p[:3] + "****" + p[7:]
	}
	return p
}

// RoundsToCSV 把轮次列表转为存库用的 CSV（如 [1,3] -> "1,3"）。
func RoundsToCSV(rounds []int) string {
	if len(rounds) == 0 {
		return ""
	}
	parts := make([]string, 0, len(rounds))
	for _, r := range rounds {
		parts = append(parts, strconv.Itoa(r))
	}
	return strings.Join(parts, ",")
}

// RoundsFromCSV 解析库里的 CSV 轮次为去重升序的 []int。
func RoundsFromCSV(s string) []int {
	seen := map[int]bool{}
	var out []int
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		if n, err := strconv.Atoi(p); err == nil && n > 0 && !seen[n] {
			seen[n] = true
			out = append(out, n)
		}
	}
	sort.Ints(out)
	return out
}

// Campaign 抢购活动（管理员控制，抢购执行逻辑由外部接入，此处仅登记与状态）。
type Campaign struct {
	ID        int64     `json:"id"`
	Name      string    `json:"name"`
	Status    string    `json:"status"`      // draft / running / finished
	Config    string    `json:"config"`      // 预留 JSON 配置，交由外部抢购程序解释
	StartAt   *time.Time `json:"start_at,omitempty"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// WinRecord 账号在某活动中的中奖情况，供用户查询。
type WinRecord struct {
	ID         int64      `json:"id"`
	AccountID  int64      `json:"account_id"`
	CampaignID int64      `json:"campaign_id"`
	Phone      string     `json:"phone,omitempty"`      // 查询结果附带（脱敏）
	Campaign   string     `json:"campaign,omitempty"`   // 活动名
	Status     string     `json:"status"`
	Prize      string     `json:"prize,omitempty"`
	Detail     string     `json:"detail,omitempty"`
	CheckedAt  *time.Time `json:"checked_at,omitempty"`
	CreatedAt  time.Time  `json:"created_at"`
}
