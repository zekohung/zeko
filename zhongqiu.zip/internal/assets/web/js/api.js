// 轻量 API 封装：自动附带 JWT，统一错误抛出。
const API = {
  token: localStorage.getItem('zq_token') || '',
  setToken(t) {
    this.token = t || '';
    if (t) localStorage.setItem('zq_token', t);
    else localStorage.removeItem('zq_token');
  },
  async req(method, path, body) {
    const headers = {};
    if (this.token) headers['Authorization'] = 'Bearer ' + this.token;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    let res;
    try {
      res = await fetch(path, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (e) {
      throw new Error('网络异常，请检查连接');
    }
    const text = await res.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch (e) { data = {}; }
    if (res.status === 401) {
      API.setToken('');
      throw new Error(data.error || '登录已失效');
    }
    if (!res.ok) throw new Error(data.error || ('请求失败 ' + res.status));
    return data.data;
  },
  get(p) { return this.req('GET', p); },
  post(p, b) { return this.req('POST', p, b); },
  put(p, b) { return this.req('PUT', p, b); },
  del(p) { return this.req('DELETE', p); },
};
