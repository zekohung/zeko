// 登录 / 卡密注册视图。
const AuthView = {
  emits: ['authed'],
  data() {
    return {
      mode: 'login', // login | register
      form: { username: '', password: '', card_key: '' },
      loading: false,
    };
  },
  methods: {
    async submit() {
      if (this.loading) return;
      const f = this.form;
      if (!f.username || !f.password) { notify('请填写用户名和密码', 'error'); return; }
      if (this.mode === 'register' && !f.card_key) { notify('请填写卡密', 'error'); return; }
      this.loading = true;
      try {
        const path = this.mode === 'login' ? '/api/auth/login' : '/api/auth/register';
        const body = this.mode === 'login'
          ? { username: f.username, password: f.password }
          : { username: f.username, password: f.password, card_key: f.card_key.trim() };
        const data = await API.post(path, body);
        API.setToken(data.token);
        notify(this.mode === 'login' ? '登录成功' : '注册成功', 'ok');
        this.$emit('authed', data.user);
      } catch (e) {
        notify(e.message, 'error');
      } finally {
        this.loading = false;
      }
    },
  },
  template: `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="auth-title">中秋央视频</div>
        <div class="auth-sub">账号管理与中奖查询平台</div>
        <div class="card">
          <div class="tabs" style="margin-top:0">
            <button class="tab" :class="{active: mode==='login'}" @click="mode='login'">登录</button>
            <button class="tab" :class="{active: mode==='register'}" @click="mode='register'">卡密注册</button>
          </div>
          <form @submit.prevent="submit">
            <div class="field">
              <label>用户名</label>
              <input class="input" v-model.trim="form.username" placeholder="3-32 位字母/数字/下划线" autocomplete="username">
            </div>
            <div class="field">
              <label>密码</label>
              <input class="input" type="password" v-model="form.password" placeholder="6-64 位" autocomplete="current-password">
            </div>
            <div class="field" v-if="mode==='register'">
              <label>卡密</label>
              <input class="input" v-model.trim="form.card_key" placeholder="请输入管理员发放的卡密">
              <div class="hint">注册需使用管理员发放的卡密，每个卡密仅可用一次。</div>
            </div>
            <button class="btn btn-block" :disabled="loading">
              {{ loading ? '处理中…' : (mode==='login' ? '登录' : '注册并登录') }}
            </button>
          </form>
        </div>
      </div>
    </div>`,
};
