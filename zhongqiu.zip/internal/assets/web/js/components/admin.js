// 管理员端：卡密管理 / 用户管理 / 账号总览 / 抢购管理。
const AdminDashboard = {
  data() {
    return {
      tab: 'cards',
      loading: false,
      cards: [],
      users: [],
      accounts: [],
      campaigns: [],
      // 生成卡密
      gen: { count: 10, note: '' },
      genResult: null,
      showGen: false,
      // 抢购活动编辑
      editing: null,
      showCampaign: false,
      // 删除确认
      confirm: { show: false, kind: '', id: 0 },
      // 抢购状态弹窗
      grab: { show: false, id: 0, name: '', data: null, timer: null },
      // 实时日志
      logs: [], logLast: 0, logTimer: null, autoScroll: true,
    };
  },
  beforeUnmount() {
    if (this.grab.timer) clearInterval(this.grab.timer);
    this.stopLogs();
  },
  mounted() { this.loadCards(); },
  methods: {
    switchTab(t) {
      this.stopLogs();
      this.tab = t;
      if (t === 'cards') this.loadCards();
      if (t === 'users') this.loadUsers();
      if (t === 'accounts') this.loadAccounts();
      if (t === 'campaigns') this.loadCampaigns();
      if (t === 'logs') this.startLogs();
    },
    startLogs() {
      this.stopLogs();
      this.pollLogs();
      this.logTimer = setInterval(() => this.pollLogs(), 2000);
    },
    stopLogs() { if (this.logTimer) { clearInterval(this.logTimer); this.logTimer = null; } },
    async pollLogs() {
      try {
        const d = await API.get('/api/admin/logs?since=' + this.logLast);
        if (d.entries && d.entries.length) {
          this.logs.push(...d.entries);
          if (this.logs.length > 500) this.logs = this.logs.slice(-500);
          if (this.autoScroll) this.$nextTick(() => { const b = this.$refs.logBox; if (b) b.scrollTop = b.scrollHeight; });
        }
        this.logLast = d.last_id || this.logLast;
      } catch (e) { /* 忽略瞬时错误 */ }
    },
    clearLogs() { this.logs = []; },
    logClass(lv) { return lv === 'ok' ? 'lg-ok' : (lv === 'warn' ? 'lg-warn' : (lv === 'error' ? 'lg-err' : 'lg-info')); },
    logTime(t) { return t ? new Date(t).toLocaleTimeString('zh-CN', { hour12: false }) : ''; },
    async loadCards() { await this.load('cards', '/api/admin/cardkeys'); },
    async loadUsers() { await this.load('users', '/api/admin/users'); },
    async loadAccounts() { await this.load('accounts', '/api/admin/accounts'); },
    async loadCampaigns() { await this.load('campaigns', '/api/admin/campaigns'); },
    async load(key, url) {
      this.loading = true;
      try { this[key] = (await API.get(url)) || []; }
      catch (e) { notify(e.message, 'error'); }
      finally { this.loading = false; }
    },
    async generate() {
      if (this.gen.count < 1 || this.gen.count > 500) { notify('数量需 1-500', 'error'); return; }
      try {
        const d = await API.post('/api/admin/cardkeys', { count: Number(this.gen.count), note: this.gen.note });
        this.genResult = d.codes;
        notify('已生成 ' + d.count + ' 个卡密', 'ok');
        this.loadCards();
      } catch (e) { notify(e.message, 'error'); }
    },
    copyCodes() {
      if (!this.genResult) return;
      copyText(this.genResult.join('\n')).then((ok) => {
        notify(ok ? '已复制到剪贴板' : '复制失败，请手动全选复制', ok ? 'ok' : 'error');
      });
    },
    closeGen() { this.showGen = false; this.genResult = null; this.gen = { count: 10, note: '' }; },
    async toggleUser(u) {
      const next = u.status === 'active' ? 'disabled' : 'active';
      try {
        await API.post('/api/admin/users/' + u.id + '/status', { status: next });
        notify('已更新', 'ok');
        this.loadUsers();
      } catch (e) { notify(e.message, 'error'); }
    },

    // ---- 抢购活动 ----
    blankEditing() {
      return {
        id: 0, name: '', status: 'draft', config: '',
        scanStartAt: '', scanWorkers: 5, workers: 150, rounds: 4, tasks: 50,
        showAdv: false,
      };
    },
    newCampaign() { this.editing = this.blankEditing(); this.showCampaign = true; },
    editCampaign(c) {
      const e = this.blankEditing();
      e.id = c.id; e.name = c.name; e.status = c.status; e.config = c.config;
      const o = this.parseCfg(c.config);
      if (o) {
        e.scanStartAt = this.toLocalInput(o.scan_start_at || '');
        e.scanWorkers = o.scan_workers || 5;
        e.workers = o.workers || 150;
        e.rounds = o.rounds || 4;
        e.tasks = o.tasks_per_account || 50;
      }
      this.editing = e;
      this.showCampaign = true;
    },
    parseCfg(s) { try { return s ? JSON.parse(s) : {}; } catch (e) { return null; } },
    toLocalInput(s) { return s ? s.replace(' ', 'T').slice(0, 16) : ''; },
    fromLocalInput(s) { return s ? s.replace('T', ' ') : ''; },
    async fillTemplate() {
      try {
        const t = await API.get('/api/admin/grab/template');
        this.editing.config = JSON.stringify(t, null, 2);
        notify('已填入默认接口配置（2026 中秋五粮液）', 'ok');
      } catch (e) { notify(e.message, 'error'); }
    },
    async saveCampaign() {
      const e = this.editing;
      if (!e.name.trim()) { notify('请填写活动名称', 'error'); return; }
      let obj = this.parseCfg(e.config);
      if (obj === null) { notify('高级接口配置 JSON 格式有误', 'error'); return; }
      try {
        if (!e.config || Object.keys(obj).length === 0) obj = await API.get('/api/admin/grab/template');
        obj.scan_start_at = this.fromLocalInput(e.scanStartAt);
        obj.scan_workers = Number(e.scanWorkers) || 5;
        obj.workers = Number(e.workers) || 150;
        obj.rounds = Number(e.rounds) || 4;
        obj.tasks_per_account = Number(e.tasks) || 50;
        const config = JSON.stringify(obj, null, 2);
        const body = { name: e.name, status: e.status || 'draft', config };
        if (e.id) await API.put('/api/admin/campaigns/' + e.id, body);
        else await API.post('/api/admin/campaigns', body);
        notify('已保存', 'ok');
        this.showCampaign = false;
        this.loadCampaigns();
      } catch (err) { notify(err.message, 'error'); }
    },
    async startGrab(c) {
      try {
        const d = await API.post('/api/admin/campaigns/' + c.id + '/grab/start', {});
        notify('抢购已启动，参与账号 ' + d.accounts + ' 个', 'ok');
        this.loadCampaigns();
        this.openStatus(c);
      } catch (e) { notify(e.message, 'error'); }
    },
    async stopGrab(c) {
      try {
        await API.post('/api/admin/campaigns/' + c.id + '/grab/stop', {});
        notify('已发送停止指令', 'ok');
      } catch (e) { notify(e.message, 'error'); }
    },
    openStatus(c) {
      if (this.grab.timer) clearInterval(this.grab.timer);
      this.grab = { show: true, id: c.id, name: c.name, data: null, timer: null };
      this.pollStatus();
      this.grab.timer = setInterval(() => this.pollStatus(), 1500);
    },
    async pollStatus() {
      try {
        const d = await API.get('/api/admin/campaigns/' + this.grab.id + '/grab/status');
        this.grab.data = d.exists ? d.status : null;
      } catch (e) { /* 忽略瞬时错误 */ }
    },
    closeStatus() {
      if (this.grab.timer) clearInterval(this.grab.timer);
      this.grab = { show: false, id: 0, name: '', data: null, timer: null };
    },
    cfgSummary(c) {
      const o = this.parseCfg(c.config);
      if (!o || !Object.keys(o).length) return '未配置';
      const parts = [];
      parts.push(o.scan_start_at ? ('⏰ ' + o.scan_start_at.slice(5, 16)) : '⏰ 立即');
      parts.push((o.rounds || 4) + ' 轮');
      parts.push((o.scan_workers || 5) + ' 线程');
      parts.push((o.workers || 150) + ' 并发');
      return parts.join('　');
    },
    askDelete(kind, id) { this.confirm = { show: true, kind, id }; },
    async doDelete() {
      const { kind, id } = this.confirm;
      try {
        if (kind === 'card') { await API.del('/api/admin/cardkeys/' + id); this.loadCards(); }
        if (kind === 'campaign') { await API.del('/api/admin/campaigns/' + id); this.loadCampaigns(); }
        notify('已删除', 'ok');
      } catch (e) { notify(e.message, 'error'); }
      finally { this.confirm.show = false; }
    },
    fmt(t) { return t ? new Date(t).toLocaleString('zh-CN') : '—'; },
    campBadge(s) { return s === 'running' ? 'badge win' : (s === 'finished' ? 'badge' : 'badge warn'); },
    campText(s) { return s === 'running' ? '抢购中' : (s === 'finished' ? '已结束' : '未开始'); },
  },
  template: `
  <div>
    <div class="tabs">
      <button class="tab" :class="{active: tab==='cards'}" @click="switchTab('cards')">卡密管理</button>
      <button class="tab" :class="{active: tab==='users'}" @click="switchTab('users')">用户管理</button>
      <button class="tab" :class="{active: tab==='accounts'}" @click="switchTab('accounts')">账号总览</button>
      <button class="tab" :class="{active: tab==='campaigns'}" @click="switchTab('campaigns')">抢购管理</button>
      <button class="tab" :class="{active: tab==='logs'}" @click="switchTab('logs')">实时日志</button>
    </div>

    <!-- 卡密管理 -->
    <div v-if="tab==='cards'">
      <div class="card">
        <div class="card-head">
          <div><h3>卡密</h3><div class="sub">生成后发放给用户用于注册，每个仅可用一次。</div></div>
          <div class="actions">
            <button class="btn" @click="showGen=true">生成卡密</button>
            <button class="btn ghost sm" @click="loadCards">刷新</button>
          </div>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>卡密</th><th>状态</th><th>使用者</th><th>备注</th><th>创建时间</th><th></th></tr></thead>
            <tbody>
              <tr v-for="c in cards" :key="c.id">
                <td data-label="卡密" class="mono">{{ c.code }}</td>
                <td data-label="状态"><span :class="c.status==='unused'?'badge ok':'badge'">{{ c.status==='unused'?'未使用':'已使用' }}</span></td>
                <td data-label="使用者">{{ c.used_by_name || '—' }}</td>
                <td data-label="备注">{{ c.note || '—' }}</td>
                <td data-label="创建时间" class="muted">{{ fmt(c.created_at) }}</td>
                <td data-label="操作" class="ta-right"><button v-if="c.status==='unused'" class="btn danger sm" @click="askDelete('card', c.id)">删除</button></td>
              </tr>
              <tr v-if="!cards.length"><td colspan="6" class="empty">暂无卡密</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- 用户管理 -->
    <div v-if="tab==='users'">
      <div class="card">
        <div class="card-head">
          <h3>用户（{{ users.length }}）</h3>
          <button class="btn ghost sm" @click="loadUsers">刷新</button>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>ID</th><th>用户名</th><th>角色</th><th>状态</th><th>注册时间</th><th></th></tr></thead>
            <tbody>
              <tr v-for="u in users" :key="u.id">
                <td data-label="ID">{{ u.id }}</td>
                <td data-label="用户名">{{ u.username }}</td>
                <td data-label="角色"><span class="badge">{{ u.role==='admin'?'管理员':'用户' }}</span></td>
                <td data-label="状态"><span :class="u.status==='active'?'badge ok':'badge off'">{{ u.status==='active'?'正常':'已禁用' }}</span></td>
                <td data-label="注册时间" class="muted">{{ fmt(u.created_at) }}</td>
                <td data-label="操作" class="ta-right">
                  <button v-if="u.role!=='admin'" class="btn ghost sm" @click="toggleUser(u)">{{ u.status==='active'?'禁用':'启用' }}</button>
                </td>
              </tr>
              <tr v-if="!users.length"><td colspan="6" class="empty">暂无用户</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- 账号总览 -->
    <div v-if="tab==='accounts'">
      <div class="card">
        <div class="card-head">
          <div><h3>账号总览（{{ accounts.length }}）</h3><div class="sub">全部用户提交的账号（手机号已脱敏）。</div></div>
          <button class="btn ghost sm" @click="loadAccounts">刷新</button>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>ID</th><th>所属用户</th><th>手机号</th><th>昵称</th><th>票据</th><th>状态</th><th>时间</th></tr></thead>
            <tbody>
              <tr v-for="a in accounts" :key="a.id">
                <td data-label="ID">{{ a.id }}</td>
                <td data-label="所属用户">{{ a.owner_name }}</td>
                <td data-label="手机号" class="mono">{{ a.phone }}</td>
                <td data-label="昵称">{{ a.nickname || '—' }}</td>
                <td data-label="票据"><span :class="a.has_token?'badge ok':'badge'">{{ a.has_token?'有效':'仅Cookie' }}</span></td>
                <td data-label="状态"><span :class="a.status==='active'?'badge ok':'badge off'">{{ a.status==='active'?'正常':'停用' }}</span></td>
                <td data-label="时间" class="muted">{{ fmt(a.created_at) }}</td>
              </tr>
              <tr v-if="!accounts.length"><td colspan="7" class="empty">暂无账号</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- 抢购管理 -->
    <div v-if="tab==='campaigns'">
      <div class="card">
        <div class="card-head">
          <div>
            <h3>抢购活动</h3>
            <div class="sub">新建活动 → 设置开始时间和火力 → 到点点「开始抢购」，全部有效账号自动参与，中奖自动回写。</div>
          </div>
          <div class="actions">
            <button class="btn" @click="newCampaign">＋ 新建活动</button>
            <button class="btn ghost sm" @click="loadCampaigns">刷新</button>
          </div>
        </div>
        <div class="legend">
          状态：<span class="badge warn">未开始</span> 已创建待启动
          <span class="badge win">抢购中</span> 正在扫描/抢购
          <span class="badge">已结束</span> 已停止或完成
        </div>
        <div class="cards-grid">
          <div class="camp-card" v-for="c in campaigns" :key="c.id">
            <div class="camp-top">
              <div class="camp-name">{{ c.name }}</div>
              <span :class="campBadge(c.status)">{{ campText(c.status) }}</span>
            </div>
            <div class="camp-cfg">{{ cfgSummary(c) }}</div>
            <div class="camp-meta">创建于 {{ fmt(c.created_at) }}</div>
            <div class="camp-actions">
              <button v-if="c.status!=='running'" class="btn sm" @click="startGrab(c)">开始抢购</button>
              <button v-else class="btn danger sm" @click="stopGrab(c)">停止</button>
              <button class="btn ghost sm" @click="openStatus(c)">实时状态</button>
              <button class="btn ghost sm" @click="editCampaign(c)">设置</button>
              <button class="btn ghost sm danger-text" @click="askDelete('campaign', c.id)">删除</button>
            </div>
          </div>
          <div v-if="!campaigns.length" class="empty" style="grid-column:1/-1">暂无活动，点「新建活动」开始</div>
        </div>
      </div>
    </div>

    <!-- 实时日志 -->
    <div v-if="tab==='logs'">
      <div class="card">
        <div class="card-head">
          <div>
            <h3>实时日志</h3>
            <div class="sub">每 2 秒自动刷新，展示登录、账号、续期、抢购全过程的关键事件。</div>
          </div>
          <div class="actions">
            <label class="chk"><input type="checkbox" v-model="autoScroll"> 自动滚动</label>
            <button class="btn ghost sm" @click="clearLogs">清屏</button>
          </div>
        </div>
        <div class="logbox" ref="logBox">
          <div v-for="l in logs" :key="l.id" class="logline">
            <span class="log-time">{{ logTime(l.time) }}</span>
            <span class="log-cat">{{ l.cat }}</span>
            <span :class="logClass(l.level)">{{ l.msg }}</span>
          </div>
          <div v-if="!logs.length" class="log-empty">暂无日志，等待事件…</div>
        </div>
      </div>
    </div>

    <!-- 生成卡密弹窗 -->
    <app-modal v-model:show="showGen" title="生成卡密" @update:show="v => { if(!v) closeGen(); }">
      <template v-if="!genResult">
        <div class="field"><label>数量（1-500）</label><input class="input" type="number" v-model="gen.count" min="1" max="500"></div>
        <div class="field"><label>备注（可选）</label><input class="input" v-model.trim="gen.note" placeholder="如：中秋首批"></div>
      </template>
      <template v-else>
        <div class="sub">已生成 {{ genResult.length }} 个卡密：</div>
        <div class="code-list"><div v-for="c in genResult" :key="c">{{ c }}</div></div>
      </template>
      <template #footer>
        <template v-if="!genResult">
          <button class="btn ghost" @click="closeGen">取消</button>
          <button class="btn" @click="generate">生成</button>
        </template>
        <template v-else>
          <button class="btn ghost" @click="copyCodes">复制全部</button>
          <button class="btn" @click="closeGen">完成</button>
        </template>
      </template>
    </app-modal>

    <!-- 活动设置弹窗（人性化） -->
    <app-modal v-model:show="showCampaign" :title="editing && editing.id ? '活动设置' : '新建活动'">
      <div v-if="editing">
        <div class="field">
          <label>活动名称</label>
          <input class="input" v-model.trim="editing.name" placeholder="如：中秋五粮液抢购">
        </div>
        <div class="grid2">
          <div class="field">
            <label>开始扫描时间</label>
            <input class="input" type="datetime-local" v-model="editing.scanStartAt">
            <div class="hint">留空 = 点「开始抢购」后立即扫描。设了时间就等到点自动开抢。</div>
          </div>
          <div class="field">
            <label>抢购轮数</label>
            <input class="input" type="number" v-model="editing.rounds" min="1" max="20">
            <div class="hint">活动共几轮（中秋五粮液是 4 轮）。</div>
          </div>
        </div>
        <div class="grid2">
          <div class="field">
            <label>扫描线程数</label>
            <input class="input" type="number" v-model="editing.scanWorkers" min="1" max="100">
            <div class="hint">用几个线程盯着开奖，越多检测越快。默认 5。</div>
          </div>
          <div class="field">
            <label>抢购并发数</label>
            <input class="input" type="number" v-model="editing.workers" min="1" max="1000">
            <div class="hint">开抢瞬间同时发包的火力。默认 150。</div>
          </div>
        </div>
        <div class="field">
          <label>每账号发包数</label>
          <input class="input" type="number" v-model="editing.tasks" min="1" max="500">
          <div class="hint">开抢瞬间每个账号连发多少次，提高命中率。默认 50。</div>
        </div>

        <div class="adv">
          <button class="adv-toggle" type="button" @click="editing.showAdv = !editing.showAdv">
            {{ editing.showAdv ? '▾' : '▸' }} 高级：接口配置（域名/路径，一般不用改）
          </button>
          <div v-if="editing.showAdv" class="adv-body">
            <div class="flex between" style="margin-bottom:6px">
              <span class="hint" style="margin:0">默认已是 2026 中秋五粮液接口</span>
              <button class="btn ghost sm" type="button" @click="fillTemplate">恢复默认</button>
            </div>
            <textarea class="input" v-model="editing.config" rows="7" style="font-family:monospace;font-size:12px" placeholder="点「恢复默认」填入接口配置，接口有变动再改这里"></textarea>
            <div class="hint">域名池、api_base（如 /api/qw26/）、act_id、接口路径。上面的开始时间/线程/并发/轮数保存时会自动写进这里。</div>
          </div>
        </div>
      </div>
      <template #footer>
        <button class="btn ghost" @click="showCampaign=false">取消</button>
        <button class="btn" @click="saveCampaign">保存</button>
      </template>
    </app-modal>

    <!-- 抢购实时状态弹窗 -->
    <app-modal :show="grab.show" :title="'实时状态 · ' + grab.name" @update:show="v => { if(!v) closeStatus(); }">
      <template v-if="grab.data">
        <div class="stat-row">
          <div class="stat"><div class="stat-v"><span :class="grab.data.running ? 'badge win' : 'badge'">{{ grab.data.running ? '运行中' : '已结束' }}</span></div><div class="stat-k">状态</div></div>
          <div class="stat"><div class="stat-v">第 {{ grab.data.round }} 轮</div><div class="stat-k">当前轮次</div></div>
          <div class="stat"><div class="stat-v">{{ grab.data.accounts }}</div><div class="stat-k">参与账号</div></div>
          <div class="stat"><div class="stat-v">{{ grab.data.attempts }}</div><div class="stat-k">已发请求</div></div>
          <div class="stat"><div class="stat-v" style="color:#067647;font-weight:700">{{ grab.data.success }}</div><div class="stat-k">中奖数</div></div>
        </div>
        <div v-if="grab.data.won && grab.data.won.length" class="mt">
          <div class="sub">中奖名单</div>
          <div class="code-list"><div v-for="(w,i) in grab.data.won" :key="i">🎉 {{ w.name }} · {{ w.prize }}（第{{ w.round }}轮）</div></div>
        </div>
        <div class="mt">
          <div class="sub">运行日志</div>
          <div class="code-list" style="max-height:240px">
            <div v-for="(l,i) in grab.data.logs" :key="i" class="muted">{{ l }}</div>
            <div v-if="!grab.data.logs || !grab.data.logs.length" class="muted">暂无日志</div>
          </div>
        </div>
      </template>
      <p v-else class="muted" style="margin:0">该活动当前没有抢购任务在运行。点「开始抢购」后可在此查看实时进度。</p>
      <template #footer>
        <button class="btn ghost" @click="closeStatus">关闭</button>
      </template>
    </app-modal>

    <app-confirm v-model:show="confirm.show" message="确定删除？此操作不可恢复。" @confirm="doDelete" />
  </div>`,
};
