// 通用复制：安全上下文用 Clipboard API，否则降级到 execCommand（兼容 HTTP 局域网访问）。
function fallbackCopy(text) {
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    ta.setAttribute('readonly', '');
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) { return false; }
}
function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
  }
  return Promise.resolve(fallbackCopy(text));
}

// 通用 UI 组件：弹窗、提示、确认框。全部用 Vue 组件实现。
const toastStore = Vue.reactive({ items: [] });
function notify(msg, type) {
  const id = Date.now() + Math.random();
  toastStore.items.push({ id, msg, type: type || 'info' });
  setTimeout(() => {
    toastStore.items = toastStore.items.filter((i) => i.id !== id);
  }, 3200);
}

// 弹窗：v-model:show 控制显示，具名插槽 footer。
const AppModal = {
  props: { show: Boolean, title: String },
  emits: ['update:show'],
  methods: {
    close() { this.$emit('update:show', false); },
  },
  template: `
    <transition name="fade">
      <div v-if="show" class="modal-overlay" @click.self="close">
        <div class="modal">
          <div class="modal-head">
            <h3>{{ title }}</h3>
            <button class="icon-btn" @click="close">×</button>
          </div>
          <div class="modal-body"><slot/></div>
          <div class="modal-foot" v-if="$slots.footer"><slot name="footer"/></div>
        </div>
      </div>
    </transition>`,
};

// 全局提示容器。
const AppToast = {
  setup() { return { toastStore }; },
  template: `
    <div class="toast-wrap">
      <transition-group name="slide">
        <div v-for="t in toastStore.items" :key="t.id" class="toast" :class="'toast-'+t.type">{{ t.msg }}</div>
      </transition-group>
    </div>`,
};

// 确认弹窗（用于删除等危险操作）。
const AppConfirm = {
  props: { show: Boolean, title: String, message: String },
  emits: ['update:show', 'confirm'],
  template: `
    <app-modal :show="show" :title="title || '确认操作'" @update:show="$emit('update:show', $event)">
      <p style="margin:0;color:#374151">{{ message }}</p>
      <template #footer>
        <button class="btn ghost" @click="$emit('update:show', false)">取消</button>
        <button class="btn danger" @click="$emit('confirm')">确认</button>
      </template>
    </app-modal>`,
};
