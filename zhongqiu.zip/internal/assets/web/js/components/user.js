// 用户端：账号管理 + 账号查询。
const UserDashboard = {
  data() {
    return {
      tab: 'accounts', // accounts | query
      accounts: [],
      wins: [],
      loading: false,
      // 短信登录流程
      sms: { phone: '', code: '', remark: '', sessionId: '', step: 1, sending: false, logging: false },
      // 手动提交
      manual: { phone: '', cookie: '', remark: '' },
      showManual: false,
      // 删除确认
      confirm: { show: false, id: 0 },
      roundsAll: [1, 2, 3, 4],
      testingId: 0,
    };
  },
  mounted() { this.loadAccounts(); },
  methods: {
    async loadAccounts() {
      this.loading = true;
      try { this.accounts = (await API.get('/api/accounts')) || []; }
      catch (e) { notify(e.message, 'error'); }
      finally { this.loading = false; }
    },
    async loadWins() {
      this.loading = true;
      try { this.wins = (await API.get('/api/query/wins')) || []; }
      catch (e) { notify(e.message, 'error'); }
      finally { this.loading = false; }
    },
    switchTab(t) {
      this.tab = t;
      if (t === 'query') this.loadWins();
      if (t === 'accounts') this.loadAccounts();
    },
    async sendCode() {
      if (!/^\d{11}$/.test(this.sms.phone)) { notify('请输入 11 位手机号', 'error'); return; }
      this.sms.sending = true;
      try {
        const d = await API.post('/api/accounts/sms/send', { phone: this.sms.phone });
        this.sms.sessionId = d.session_id;
        this.sms.step = 2;
        notify('验证码已发送，请查收短信', 'ok');
      } catch (e) { notify(e.message, 'error'); }
      finally { this.sms.sending = false; }
    },
    async smsLogin() {
      if (!this.sms.code) { notify('请输入验证码', 'error'); return; }
      this.sms.logging = true;
      try {
        await API.post('/api/accounts/sms/login', {
          session_id: this.sms.sessionId, code: this.sms.code.trim(), remark: this.sms.remark,
        });
        notify('账号登录成功，已保存', 'ok');
        this.sms = { phone: '', code: '', remark: '', sessionId: '', step: 1, sending: false, logging: false };
        this.loadAccounts();
      } catch (e) { notify(e.message, 'error'); }
      finally { this.sms.logging = false; }
    },
    resetSms() {
      this.sms = { phone: '', code: '', remark: '', sessionId: '', step: 1, sending: false, logging: false };
    },
    async submitManual() {
      if (!/^\d{11}$/.test(this.manual.phone)) { notify('请输入 11 位手机号', 'error'); return; }
      if (!this.manual.cookie.trim()) { notify('请填写 Cookie', 'error'); return; }
      try {
        await API.post('/api/accounts', {
          phone: this.manual.phone, cookie: this.manual.cookie.trim(), remark: this.manual.remark,
        });
        notify('账号已提交', 'ok');
        this.showManual = false;
        this.manual = { phone: '', cookie: '', remark: '' };
        this.loadAccounts();
      } catch (e) { notify(e.message, 'error'); }
    },
    askDelete(id) { this.confirm = { show: true, id }; },
    async doDelete() {
      try {
        await API.del('/api/accounts/' + this.confirm.id);
        notify('已删除', 'ok');
        this.loadAccounts();
      } catch (e) { notify(e.message, 'error'); }
      finally { this.confirm.show = false; }
    },
    fmtRemaining(sec) {
      if (sec === undefined || sec === null || sec < 0) return '—';
      if (sec <= 0) return '已过期';
      const m = Math.floor(sec / 60), h = Math.floor(m / 60);
      if (h > 0) return h + '时' + (m % 60) + '分';
      return m + '分';
    },
    remainClass(sec) {
      if (sec === undefined || sec === null || sec < 0) return 'muted';
      if (sec <= 0) return 'badge off';
      if (sec <= 600) return 'badge warn';
      return 'badge ok';
    },
    async refreshAccount(a) {
      try {
        await API.post('/api/accounts/' + a.id + '/refresh', {});
        notify('续期成功', 'ok');
        this.loadAccounts();
      } catch (e) { notify(e.message, 'error'); }
    },
    async testAccount(a) {
      if (this.testingId) return;
      this.testingId = a.id;
      try {
        const d = await API.post('/api/accounts/' + a.id + '/test', {});
        if (d.usable) notify('✅ 可正常抢购（接口返回 code=' + d.code + '）', 'ok');
        else notify('❌ 不可用：code=' + d.code + (d.msg ? '（' + d.msg + '）' : '') + '，建议先续期', 'error');
      } catch (e) { notify('测试失败：' + e.message, 'error'); }
      finally { this.testingId = 0; }
    },
    hasRound(a, n) { return (a.grab_rounds || []).includes(n); },
    async setAllRounds(a) {
      const arr = [...this.roundsAll];
      const old = a.grab_rounds;
      a.grab_rounds = arr;
      try { await API.post('/api/accounts/' + a.id + '/rounds', { rounds: arr }); notify('已设为全部轮次', 'ok'); }
      catch (e) { a.grab_rounds = old; notify(e.message, 'error'); }
    },
    async toggleRound(a, n) {
      const cur = new Set(a.grab_rounds || []);
      if (cur.has(n)) cur.delete(n); else cur.add(n);
      const arr = [...cur].sort((x, y) => x - y);
      if (arr.length === 0) { notify('每个账号至少参与一轮', 'error'); return; }
      const old = a.grab_rounds;
      a.grab_rounds = arr; // 乐观更新
      try {
        await API.post('/api/accounts/' + a.id + '/rounds', { rounds: arr });
      } catch (e) {
        a.grab_rounds = old;
        notify(e.message, 'error');
      }
    },
    winBadge(s) { return s === 'won' ? 'badge win' : (s === 'lost' ? 'badge off' : 'badge warn'); },
    winText(s) { return s === 'won' ? '已中奖' : (s === 'lost' ? '未中奖' : '待开奖'); },
    fmt(t) { return t ? new Date(t).toLocaleString('zh-CN') : '—'; },
  },
  template: `
  <div>
    <div class="tabs">
      <button class="tab" :class="{active: tab==='accounts'}" @click="switchTab('accounts')">账号管理</button>
      <button class="tab" :class="{active: tab==='query'}" @click="switchTab('query')">账号查询</button>
    </div>

    <!-- 账号管理 -->
    <div v-if="tab==='accounts'">
      <div class="grid2">
        <div class="card">
          <h3>短信登录添加账号</h3>
          <div class="sub">输入手机号获取验证码，登录后自动保存账号票据。</div>
          <template v-if="sms.step===1">
            <div class="field">
              <label>手机号</label>
              <input class="input" v-model.trim="sms.phone" maxlength="11" placeholder="11 位手机号">
            </div>
            <div class="field">
              <label>备注（可选）</label>
              <input class="input" v-model.trim="sms.remark" placeholder="便于识别，如：大号">
            </div>
            <button class="btn btn-block" :disabled="sms.sending" @click="sendCode">
              {{ sms.sending ? '发送中…' : '获取验证码' }}
            </button>
          </template>
          <template v-else>
            <div class="field">
              <label>验证码（发往 {{ sms.phone }}）</label>
              <input class="input" v-model.trim="sms.code" maxlength="8" placeholder="请输入短信验证码">
            </div>
            <div class="actions">
              <button class="btn" :disabled="sms.logging" @click="smsLogin">
                {{ sms.logging ? '登录中…' : '登录并保存' }}
              </button>
              <button class="btn ghost" @click="resetSms">重新发码</button>
            </div>
          </template>
        </div>

        <div class="card">
          <h3>其他方式</h3>
          <div class="sub">已有账号 Cookie 时可直接手动提交。</div>
          <button class="btn ghost btn-block" @click="showManual=true">手动提交账号（Cookie）</button>
          <div class="hint">抢购由管理员统一发起，你只需提交账号并在“账号查询”查看中奖情况。</div>
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3>我的账号（{{ accounts.length }}）</h3>
          <button class="btn ghost sm" @click="loadAccounts">刷新</button>
        </div>
        <div class="hint" style="margin-bottom:12px">「抢购轮次」勾选每个账号参与哪几轮（可单选/多选，点「全」快速全选）。<b>抢中一轮后该账号后续轮次自动不再参与</b>（4 轮只能中 1 次）。</div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>账号</th><th>抢购轮次</th><th>票据有效期</th><th>状态</th><th class="ta-right">操作</th></tr></thead>
            <tbody>
              <tr v-for="a in accounts" :key="a.id">
                <td data-label="账号">
                  <div class="acc-cell">
                    <span class="acc-phone mono">{{ a.phone }}</span>
                    <span class="acc-sub">{{ a.nickname || '未命名' }}<template v-if="a.remark"> · {{ a.remark }}</template></span>
                  </div>
                </td>
                <td data-label="抢购轮次">
                  <div class="round-picks">
                    <label v-for="n in roundsAll" :key="n" class="round-pick" :class="{on: hasRound(a,n)}">
                      <input type="checkbox" :checked="hasRound(a,n)" @change="toggleRound(a,n)"> {{ n }}
                    </label>
                    <button class="round-all" @click="setAllRounds(a)" title="全选四轮">全</button>
                  </div>
                </td>
                <td data-label="有效期">
                  <span v-if="a.has_token" :class="remainClass(a.token_remaining)">{{ fmtRemaining(a.token_remaining) }}</span>
                  <span v-else class="badge">仅Cookie</span>
                </td>
                <td data-label="状态"><span :class="a.status==='active' ? 'badge ok' : 'badge off'">{{ a.status==='active'?'正常':'停用' }}</span></td>
                <td data-label="操作" class="ta-right actions">
                  <button class="btn ghost sm" :disabled="testingId===a.id" @click="testAccount(a)">{{ testingId===a.id ? '测试中…' : '测试' }}</button>
                  <button v-if="a.can_refresh" class="btn ghost sm" @click="refreshAccount(a)">续期</button>
                  <button class="btn ghost sm danger-text" @click="askDelete(a.id)">删除</button>
                </td>
              </tr>
              <tr v-if="!accounts.length"><td colspan="5" class="empty">暂无账号，请先在上方添加</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- 账号查询 -->
    <div v-if="tab==='query'">
      <div class="card">
        <div class="flex between">
          <div><h3 style="margin:0">中奖查询</h3><div class="sub" style="margin:4px 0 0">展示你名下账号在各抢购活动的中奖情况。</div></div>
          <button class="btn ghost sm" @click="loadWins">刷新</button>
        </div>
        <div class="table-wrap mt">
          <table class="table">
            <thead><tr><th>手机号</th><th>活动</th><th>结果</th><th>奖品</th><th>说明</th><th>开奖时间</th></tr></thead>
            <tbody>
              <tr v-for="w in wins" :key="w.id">
                <td data-label="手机号" class="mono">{{ w.phone }}</td>
                <td data-label="活动">{{ w.campaign }}</td>
                <td data-label="结果"><span :class="winBadge(w.status)">{{ winText(w.status) }}</span></td>
                <td data-label="奖品">{{ w.prize || '—' }}</td>
                <td data-label="说明" class="muted">{{ w.detail || '—' }}</td>
                <td data-label="开奖时间" class="muted">{{ fmt(w.checked_at) }}</td>
              </tr>
              <tr v-if="!wins.length"><td colspan="6" class="empty">暂无中奖记录</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- 手动提交弹窗 -->
    <app-modal v-model:show="showManual" title="手动提交账号">
      <div class="field">
        <label>手机号</label>
        <input class="input" v-model.trim="manual.phone" maxlength="11" placeholder="11 位手机号">
      </div>
      <div class="field">
        <label>Cookie</label>
        <textarea class="input" v-model="manual.cookie" placeholder="粘贴完整登录态 Cookie"></textarea>
      </div>
      <div class="field">
        <label>备注（可选）</label>
        <input class="input" v-model.trim="manual.remark">
      </div>
      <template #footer>
        <button class="btn ghost" @click="showManual=false">取消</button>
        <button class="btn" @click="submitManual">提交</button>
      </template>
    </app-modal>

    <app-confirm v-model:show="confirm.show" message="确定删除该账号？此操作不可恢复。" @confirm="doDelete" />
  </div>`,
};
