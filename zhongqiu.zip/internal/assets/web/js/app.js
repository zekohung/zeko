// 根应用：管理登录态与视图路由（用户端 / 管理员端）。
const App = {
  data() {
    return { ready: false, user: null };
  },
  async mounted() {
    if (API.token) {
      try { this.user = await API.get('/api/auth/me'); }
      catch (e) { API.setToken(''); }
    }
    this.ready = true;
  },
  methods: {
    onAuthed(user) { this.user = user; },
    logout() { API.setToken(''); this.user = null; notify('已退出登录', 'ok'); },
  },
  template: `
    <div>
      <app-toast />
      <template v-if="ready">
        <auth-view v-if="!user" @authed="onAuthed" />
        <template v-else>
          <div class="topbar">
            <div class="container topbar-inner">
              <div class="brand"><span class="dot"></span> 中秋央视频</div>
              <div class="userbox">
                <span class="badge">{{ user.role==='admin' ? '管理员' : '用户' }}</span>
                <span>{{ user.username }}</span>
                <button class="btn ghost sm" @click="logout">退出</button>
              </div>
            </div>
          </div>
          <div class="container" style="padding-top:8px;padding-bottom:48px">
            <admin-dashboard v-if="user.role==='admin'" />
            <user-dashboard v-else />
          </div>
        </template>
      </template>
    </div>`,
};

const app = Vue.createApp(App);
app.component('app-modal', AppModal);
app.component('app-toast', AppToast);
app.component('app-confirm', AppConfirm);
app.component('auth-view', AuthView);
app.component('user-dashboard', UserDashboard);
app.component('admin-dashboard', AdminDashboard);
app.mount('#app');
