// Package assets 把前端静态资源嵌入二进制，便于单文件部署。
package assets

import (
	"embed"
	"io/fs"
)

//go:embed web
var embedded embed.FS

// WebFS 返回以 web 目录为根的文件系统。
func WebFS() fs.FS {
	sub, err := fs.Sub(embedded, "web")
	if err != nil {
		panic(err) // 编译期嵌入路径固定，出错说明构建异常
	}
	return sub
}
