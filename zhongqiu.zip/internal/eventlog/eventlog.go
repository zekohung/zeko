// Package eventlog 是全局内存事件日志（环形缓冲），供各模块写入、管理端实时读取。
package eventlog

import (
	"fmt"
	"sync"
	"time"
)

// Level 常量
const (
	LevelInfo = "info"
	LevelWarn = "warn"
	LevelErr  = "error"
	LevelOK   = "ok"
)

// Entry 一条日志。
type Entry struct {
	ID    int64     `json:"id"`
	Time  time.Time `json:"time"`
	Level string    `json:"level"`
	Cat   string    `json:"cat"`
	Msg   string    `json:"msg"`
}

const maxEntries = 1000

var (
	mu  sync.Mutex
	buf []Entry
	seq int64
)

// Emit 写入一条日志。
func Emit(level, cat, msg string) {
	mu.Lock()
	seq++
	e := Entry{ID: seq, Time: time.Now(), Level: level, Cat: cat, Msg: msg}
	buf = append(buf, e)
	if len(buf) > maxEntries {
		buf = buf[len(buf)-maxEntries:]
	}
	mu.Unlock()
}

func Info(cat, format string, a ...any) { Emit(LevelInfo, cat, fmt.Sprintf(format, a...)) }
func OK(cat, format string, a ...any)   { Emit(LevelOK, cat, fmt.Sprintf(format, a...)) }
func Warn(cat, format string, a ...any) { Emit(LevelWarn, cat, fmt.Sprintf(format, a...)) }
func Err(cat, format string, a ...any)  { Emit(LevelErr, cat, fmt.Sprintf(format, a...)) }

// Since 返回 id 之后的日志与最新 id（用于前端增量轮询）。since<=0 返回最近的一批。
func Since(id int64) ([]Entry, int64) {
	mu.Lock()
	defer mu.Unlock()
	last := seq
	if len(buf) == 0 {
		return []Entry{}, last
	}
	out := make([]Entry, 0, 64)
	for _, e := range buf {
		if e.ID > id {
			out = append(out, e)
		}
	}
	// 首次拉取（id<=0）只给最近 200 条，避免一次性过多
	if id <= 0 && len(out) > 200 {
		out = out[len(out)-200:]
	}
	return out, last
}
