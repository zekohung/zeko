// Command server 启动“中秋央视频”后端与前端。
package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"zhongqiu/internal/assets"
	"zhongqiu/internal/auth"
	"zhongqiu/internal/config"
	"zhongqiu/internal/db"
	"zhongqiu/internal/handler"
	"zhongqiu/internal/store"
)

func main() {
	slog.SetDefault(slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo})))

	cfg, err := config.Load()
	if err != nil {
		slog.Error("加载配置失败", "err", err)
		os.Exit(1)
	}

	sqlDB, err := db.Open(cfg.DBPath)
	if err != nil {
		slog.Error("初始化数据库失败", "err", err)
		os.Exit(1)
	}
	defer sqlDB.Close()

	st := store.New(sqlDB)
	if err := ensureAdmin(st, cfg); err != nil {
		slog.Error("初始化管理员失败", "err", err)
		os.Exit(1)
	}

	jm := auth.NewManager(cfg.JWTSecret, cfg.TokenTTLHours)
	srv := handler.NewServer(st, jm)
	root := srv.Routes(assets.WebFS())

	httpServer := &http.Server{
		Addr:              cfg.Addr,
		Handler:           root,
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       120 * time.Second,
	}

	go func() {
		slog.Info("服务启动", "addr", cfg.Addr, "db", cfg.DBPath)
		if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			slog.Error("服务异常退出", "err", err)
			os.Exit(1)
		}
	}()

	// 优雅关闭
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop
	slog.Info("正在关闭服务…")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(ctx); err != nil {
		slog.Error("关闭超时", "err", err)
	}
}

// ensureAdmin 首次启动时创建管理员账号。
func ensureAdmin(st *store.Store, cfg *config.Config) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	n, err := st.CountAdmins(ctx)
	if err != nil {
		return err
	}
	if n > 0 {
		return nil
	}
	pw := cfg.AdminPassword
	generated := false
	if pw == "" {
		buf := make([]byte, 8)
		_, _ = rand.Read(buf)
		pw = hex.EncodeToString(buf) // 16 位随机初始密码
		generated = true
	}
	hash, err := auth.HashPassword(pw)
	if err != nil {
		return err
	}
	if err := st.CreateAdmin(ctx, cfg.AdminUser, hash); err != nil {
		return err
	}
	if generated {
		slog.Warn("已创建初始管理员，请立即登录修改", "username", cfg.AdminUser, "password", pw)
	} else {
		slog.Info("已创建初始管理员", "username", cfg.AdminUser)
	}
	return nil
}
