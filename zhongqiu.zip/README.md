# 中秋央视频

央视频账号管理与中奖查询平台。Go 后端 + Vue3（免构建 CDN 本地内嵌）+ SQLite（纯 Go，零外部依赖）。

- **用户端**：卡密注册 → 提交央视频账号（站内短信登录 / 手动 Cookie）→ 查询中奖情况。
- **管理员端**：发放卡密、管理用户、账号总览、抢购活动管理（预留）、中奖结果录入。
- **抢购**：由管理员/外部程序控制，站内仅登记活动与回写中奖，抢购执行逻辑预留接口。

## 运行

```powershell
# 需要 Go 1.24+，无需 Node（Vue 已内嵌）
cd 中秋央视频
go run ./cmd/server
# 或编译：go build -o zq.exe ./cmd/server ; .\zq.exe
```

启动后访问 http://localhost:24041

首次启动自动创建管理员：
- 设了 `ZQ_ADMIN_PASSWORD` 则用该密码；
- 未设则生成随机初始密码并打印在启动日志（`已创建初始管理员 ... password=xxxx`），请立即登录。

## 环境变量

| 变量 | 默认 | 说明 |
|------|------|------|
| `ZQ_ADDR` | `:24041` | 监听地址 |
| `ZQ_DATA_DIR` | `data` | 数据目录（SQLite + JWT 密钥） |
| `ZQ_ADMIN_USER` | `admin` | 初始管理员账号 |
| `ZQ_ADMIN_PASSWORD` | 空 | 初始管理员密码（空则随机生成并打印） |
| `ZQ_JWT_SECRET` | 自动生成 | JWT 密钥（不设则在数据目录持久化一份） |
| `ZQ_TOKEN_TTL_HOURS` | `24` | 登录有效期（小时） |

## 目录结构

```
cmd/server/          入口（配置加载、建库、初始化管理员、优雅关闭）
internal/config/     配置与密钥
internal/db/         SQLite 打开与建表（schema.sql）
internal/model/      领域实体与脱敏视图
internal/store/      数据访问（用户/卡密/账号/活动/中奖，注册走事务）
internal/auth/       bcrypt 密码、JWT、鉴权中间件
internal/ysp/        央视频 JCE 协议 Go 移植（发码/登录/注册 guid，预留续期）
internal/handler/    HTTP 接口 + 路由 + 短信会话/限流
internal/assets/     前端静态资源（embed 进二进制）
  web/               index.html + css + js（Vue3 组件）
```

## 接口一览

公开：
- `POST /api/auth/register` `{username, password, card_key}`
- `POST /api/auth/login` `{username, password}`

需登录（`Authorization: Bearer <token>`）：
- `GET  /api/auth/me`
- `POST /api/accounts/sms/send` `{phone}` → 返回 `session_id`
- `POST /api/accounts/sms/login` `{session_id, code, remark}`
- `POST /api/accounts` `{phone, cookie, remark}`（手动提交）
- `GET  /api/accounts`
- `POST /api/accounts/{id}/rounds` `{rounds:[1,2,4]}`（设置参与轮次）
- `POST /api/accounts/{id}/refresh`（手动续期该账号 Cookie）
- `DELETE /api/accounts/{id}`
- `GET  /api/query/wins`

需管理员：
- `POST/GET /api/admin/cardkeys`，`DELETE /api/admin/cardkeys/{id}`
- `GET /api/admin/users`，`POST /api/admin/users/{id}/status` `{status}`
- `GET /api/admin/accounts`
- `GET/POST /api/admin/campaigns`，`PUT/DELETE /api/admin/campaigns/{id}`
- `POST /api/admin/wins` `{account_id, campaign_id, status, prize, detail}`

## 安全设计

- 密码 bcrypt 存储；登录话术统一，避免用户名枚举。
- JWT（HS256）签名校验，密钥持久化；中间件强制鉴权，管理员接口二次校验角色。
- 卡密注册在单事务内「校验未用 → 建用户 → 标记已用」，杜绝并发重用；已用卡密不可删除。
- 账号归属校验：普通用户只能读写/删除自己的账号。
- 账号 token/cookie 不下发前端展示，手机号列表统一脱敏。
- 请求体大小上限、发码按用户滑动窗口限流、基础安全响应头（nosniff / DENY / no-referrer）。

## 抢购（内置引擎，管理员控制）

内置抢购引擎，配置驱动。默认配置已对齐 **2026 中秋五粮液(qw26)**（2026-09-25 抓包实证）。

**流程**：到「开始扫描时间」→ 多协程高频扫描 `pool` → 某轮 `status==1` 且出现 `pool_id` 的瞬间 → 参与该轮的全部账号同时高并发打 `draw/random` → `code==1` 记为中奖并写回 `win_records`（用户在「账号查询」可见）。**任一账号抢中一轮后，后续轮次不再参与**（4 轮只能中 1 次，符合活动规则）。

**账号来源**：全部「状态正常且带 cookie」的账号；每个账号可由用户在自己页面**单选/多选参与哪几轮**（`grab_rounds`）。

**管理端接口**：
- `GET  /api/admin/grab/template` 默认配置模板
- `POST /api/admin/campaigns/{id}/grab/start` 用全部有效账号启动
- `POST /api/admin/campaigns/{id}/grab/stop` 停止
- `GET  /api/admin/campaigns/{id}/grab/status` 实时状态（轮次/请求数/中奖数/名单/日志）

用户端：`POST /api/accounts/{id}/rounds {rounds:[1,2,4]}` 设置账号参与轮次。

**实时日志**：管理端「实时日志」页每 2 秒轮询 `GET /api/admin/logs?since=<id>`（内存环形缓冲，增量返回），展示登录/账号/续期/抢购全过程的关键事件（分级：info/ok/warn/error）。

**活动配置 JSON**（存 `campaigns.config`；活动编辑页有「开始扫描时间/扫描协程数」专用控件，其余在 JSON）：

| 字段 | 说明 | 默认(qw26) |
|------|------|-----------|
| `api_base` | 接口前缀 | `.yangshipin.cn/api/qw26/` |
| `act_id` | 活动 id | `1` |
| `pool_domains` / `draw_domains` | API 域名池（**偶数** lottery，奇数是 COS 静态桶会 404） | `lottery02,04,…,20` |
| `pool_path` / `draw_path` / `prizes_path` | 三个接口路径 | `pool` / `draw/random` / `my/prizes` |
| `scan_start_at` | 几点开始扫描（本地时间，空=立即），如 `2026-09-26 20:00:00` | 空 |
| `scan_workers` | 扫描 pool 的并发协程数 | 5 |
| `rounds` / `workers` / `tasks_per_account` | 轮次 / 抢购并发 / 每号请求数 | 4 / 150 / 50 |
| `request_delay_ms` / `draw_timeout_ms` / `poll_interval_ms` | 阶梯延迟 / 抢超时 / 扫描间隔 | 500 / 1500 / 100 |
| `origin` / `referer` / `x_requested_with` / `user_agent` | H5 请求头（防风控/CORS） | m.yangshipin.cn 等 |
| `validate_ck` | 抢前是否验号 | true |
| `success_code` / `status_open` / `status_finished` | 响应语义码 | 1 / 1 / 2 |

**qw26 状态语义**（抓包实证）：`1`=开抢(可抽) `2`=结束 `3`=未开始 `4`=已参与/已中；鉴权为 Cookie（app 内 `withCredentials:true`）。

**每次新活动**：在活动「编辑」点「填入默认模板」，改 `api_base`、域名池、`act_id`、轮次、开始扫描时间即可。若响应 JSON 结构大改（`data.pools[].status/pool_id`、`data.prize.prize_name` 字段名变了），需同步改 `internal/grab/engine.go` 的解析。

> 也保留外部对接：外部程序可用管理员令牌调 `POST /api/admin/wins` 直接回写中奖。账号票据存于 `accounts` 表。

## Cookie 续期（NewRefreshToken 59987，已打通）

央视频短信登录协议移植自已验证的 Python 版。**Cookie 续期已端到端验证成功**：

- 关键：`RequestHead.token`（tag5）必须带 `LoginToken(keyType=9, value=vusession, uin=vuserid)`，否则服务端返回 `1002 checkInput failed`（这是之前卡住的原因）。
- `refresh_token` 长效，`access_token`(~2h)/`vusession`(~3.8h) 过期后用它换新票据，账号无需重新短信登录。
- **手动续期**：账号列表「续期」按钮 → `POST /api/accounts/{id}/refresh`，成功后 token/cookie 原位更新。
- **自动续期**：后台每 3 分钟扫描，对剩余有效期 ≤ 600s（或未知）的账号自动续期（对齐 App 的 RefreshTickTask）。
- 账号列表显示「有效期」，绿=充足 / 黄=即将过期 / 红=已过期。

原 Python 续期工具保留在项目根 `refresh_cookie.py`。
